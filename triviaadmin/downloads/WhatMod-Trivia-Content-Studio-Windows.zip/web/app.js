const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
let templates=[], acquirePoll=null, mediaPoll=null, latestItems=[], legacyJob=null;
let templateSelection=new Set(), templatesLoadedOnce=false;
const CATEGORY_ORDER=["Science","Technology","History","Geography","Animals","Space","Sports","Entertainment","Business"];
function toast(msg){const n=document.createElement('div');n.className='toast';n.textContent=msg;$('#toast-root').appendChild(n);setTimeout(()=>n.remove(),3200)}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}
async function api(path,opts={}){const r=await fetch(path,{...opts,headers:{'Content-Type':'application/json',...(opts.headers||{})}});let b={};try{b=await r.json()}catch{}if(!r.ok)throw new Error(b.error||`Request failed ${r.status}`);return b}
function downloadJson(filename,data){const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function fmtTime(sec){sec=Math.max(0,Number(sec||0));if(sec<60)return `${Math.round(sec)}s`;const m=Math.floor(sec/60),s=Math.round(sec%60);return `${m}m ${s}s`}

function updateTemplateSummary(){
  const cats=new Set(templates.filter(t=>templateSelection.has(t.id)).map(t=>t.category));
  $('#template-summary').textContent=`${templateSelection.size} selected · ${templates.length} generators · ${cats.size||new Set(templates.map(t=>t.category)).size} categories`;
}
function bindTemplateRows(){
  $$('#template-list input[type="checkbox"]').forEach(box=>box.onchange=()=>{box.checked?templateSelection.add(box.value):templateSelection.delete(box.value);updateTemplateSummary()});
  $$('[data-cat-toggle]').forEach(btn=>btn.onclick=()=>{const cat=btn.dataset.catToggle,rows=templates.filter(t=>t.category===cat && templateVisible(t)),all=rows.length&&rows.every(t=>templateSelection.has(t.id));rows.forEach(t=>all?templateSelection.delete(t.id):templateSelection.add(t.id));renderTemplates()});
}
function templateVisible(t){const q=String($('#template-filter')?.value||'').trim().toLowerCase();return !q||`${t.name} ${t.category} ${t.difficulty} ${t.note||''}`.toLowerCase().includes(q)}
function renderTemplates(){
  const groups={};for(const t of templates){if(!templateVisible(t))continue;(groups[t.category]??=[]).push(t)}
  const cats=[...new Set([...CATEGORY_ORDER,...Object.keys(groups)])].filter(c=>groups[c]?.length);
  $('#template-list').innerHTML=cats.length?cats.map(cat=>{
    const rows=groups[cat],all=rows.every(t=>templateSelection.has(t.id));
    return `<section class="template-group"><div class="template-group-head"><div><b>${esc(cat)}</b><small>${rows.length} generators</small></div><button class="micro" data-cat-toggle="${esc(cat)}">${all?'Clear category':'Select category'}</button></div><div class="template-grid">${rows.map(t=>`<label class="template ${t.recommended?'recommended':''}"><input type="checkbox" value="${esc(t.id)}" ${templateSelection.has(t.id)?'checked':''}><span><b>${esc(t.name)}</b><small>${esc(t.difficulty)} · next ${Number(t.offset||0).toLocaleString()}${t.note?` · ${esc(t.note)}`:''}</small></span>${t.recommended?'<em>REC</em>':''}</label>`).join('')}</div></section>`
  }).join(''):'<div class="empty">No generators match that filter.</div>';
  bindTemplateRows();updateTemplateSummary();
}
async function loadTemplates(){
  const body=await api('/api/templates');templates=body.templates||[];
  if(!templatesLoadedOnce){templateSelection=new Set(templates.filter(t=>t.recommended).map(t=>t.id));templatesLoadedOnce=true}
  else templateSelection=new Set([...templateSelection].filter(id=>templates.some(t=>t.id===id)));
  renderTemplates();
}
$('#template-filter').oninput=()=>renderTemplates();
$('#select-recommended').onclick=()=>{templateSelection=new Set(templates.filter(t=>t.recommended).map(t=>t.id));renderTemplates()};
$('#select-all').onclick=()=>{templates.filter(templateVisible).forEach(t=>templateSelection.add(t.id));renderTemplates()};
$('#clear-all').onclick=()=>{templates.filter(templateVisible).forEach(t=>templateSelection.delete(t.id));renderTemplates()};
$('#offset-mode').onchange=()=>{$('#custom-offset').disabled=$('#offset-mode').value!=='custom'};
$('#acquire').onclick=async()=>{try{const selected=[...templateSelection];if(!selected.length)return toast('Select at least one generator.');const requested=selected.length*Number($('#per-template').value);if(requested>4000&&!confirm(`This run requests up to ${requested.toLocaleString()} questions across ${selected.length} generators. It can take a while. Continue?`))return;await api('/api/acquire/start',{method:'POST',body:JSON.stringify({templates:selected,per_template:Number($('#per-template').value),offset_mode:$('#offset-mode').value,custom_offset:Number($('#custom-offset').value||0),workers:Number($('#acquire-workers').value||3)})});$('#acquire').disabled=true;$('#cancel-acquire').disabled=false;startAcquirePolling()}catch(e){toast(e.message)}};
$('#cancel-acquire').onclick=async()=>{try{await api('/api/acquire/cancel',{method:'POST',body:'{}'});toast('Stop requested. In-flight network calls can take a few seconds to exit.')}catch(e){toast(e.message)}};
$('#reset-offsets').onclick=async()=>{if(!confirm('Reset all local generator offsets back to 0? This does not delete anything from Supabase.'))return;try{await api('/api/content/reset-offsets',{method:'POST',body:'{}'});await loadTemplates();toast('Local offsets reset.')}catch(e){toast(e.message)}};
function startAcquirePolling(){clearInterval(acquirePoll);acquirePoll=setInterval(updateAcquire,650);updateAcquire()}
function renderAcquireEvents(events=[]){const box=$('#acquire-events');const rows=events.slice(-10).reverse();box.innerHTML=rows.length?rows.map(ev=>{const stage=ev.stage||'',bad=stage==='error'||ev.ok===false,good=stage==='done'&&ev.ok!==false;return `<div class="event ${bad?'bad':good?'good':''}"><span>${bad?'!':good?'✓':stage==='scan'?'↻':'•'}</span><div><b>${esc(ev.name||ev.template||'Generator')}</b><small>${esc(ev.message||'Working…')}${ev.seconds!=null?` · ${esc(ev.seconds)}s`:''}</small></div></div>`}).join(''):'<div class="event muted-event">No acquisition activity yet.</div>'}
async function updateAcquire(){try{
  const s=await api('/api/acquire/status'),pct=s.total_templates?Math.round(s.completed_templates/s.total_templates*100):0;
  $('#acquire-state').textContent=s.running?'RUNNING':(s.question_count?'READY':(s.errors?.length?'FINISHED WITH ERRORS':'IDLE'));
  $('#acquire-state').className=`pill ${s.running?'':'muted'}`;$('#acquire-bar').style.width=`${pct}%`;$('#acquired-count').textContent=Number(s.question_count||0).toLocaleString();
  const ev=s.events?.at(-1);let msg='Ready.';
  if(s.running)msg=ev?.message||`Running ${s.workers||3} acquisition workers · ${s.completed_templates}/${s.total_templates} generators complete`;
  else if(s.errors?.length)msg=`${Number(s.question_count||0).toLocaleString()} acquired · ${s.errors.length} generator error(s) · ${fmtTime(s.elapsed)}`;
  else if(s.question_count)msg=`${Number(s.question_count).toLocaleString()} questions ready · ${fmtTime(s.elapsed)}`;
  $('#acquire-message').textContent=msg;renderAcquireEvents(s.events||[]);
  $('#acquire').disabled=s.running;$('#cancel-acquire').disabled=!s.running;$('#resolve').disabled=s.running||!s.question_count;$('#export-package').disabled=!s.question_count;
  $('#package-summary').textContent=s.question_count?`${Number(s.question_count).toLocaleString()} questions ready${latestItems.length?` · ${latestItems.filter(x=>x.selected).length.toLocaleString()} images selected`:''}`:'Nothing ready yet.';
  if(s.question_count)await renderQuestionPreview();
  if(!s.running&&acquirePoll){clearInterval(acquirePoll);acquirePoll=null;await loadTemplates()}
}catch(e){console.error(e);$('#acquire-message').textContent=`Status error: ${e.message}`}}
async function renderQuestionPreview(){try{const b=await api('/api/acquire/questions'),items=b.questions||[];$('#question-preview').innerHTML=items.length?items.slice(0,160).map(q=>`<article><div><b>${esc(q.prompt)}</b><small>${esc(q.category)} · ${esc(q.difficulty)} · ${esc(q.canonical_key)}</small></div><strong>${esc(q.answer_numeric)} ${esc(q.unit||'')}</strong></article>`).join(''):'<div class="empty">No questions acquired.</div>'}catch(e){console.error(e)}}

$('#resolve').onclick=async()=>{try{await api('/api/content/resolve',{method:'POST',body:JSON.stringify({concurrency:Number($('#concurrency').value),probe_count:Number($('#probe-count').value)})});$('#resolve').disabled=true;$('#cancel-media').disabled=false;startMediaPolling()}catch(e){toast(e.message)}};
$('#cancel-media').onclick=async()=>{try{await api('/api/cancel',{method:'POST',body:'{}'});toast('Stop requested.')}catch(e){toast(e.message)}};
function startMediaPolling(){clearInterval(mediaPoll);mediaPoll=setInterval(updateMedia,650);updateMedia()}
async function updateMedia(){try{const s=await api('/api/status'),pct=s.total?Math.round(s.completed/s.total*100):0;$('#media-bar').style.width=`${pct}%`;$('#done').textContent=`${s.completed}/${s.total}`;$('#resolved').textContent=s.resolved;$('#missing').textContent=s.missing;$('#speed').textContent=`${Math.round((s.rate||0)*60)}/m`;$('#media-state').textContent=s.running?'RUNNING':(s.completed?'COMPLETE':'IDLE');$('#media-state').className=`pill ${s.running?'':'muted'}`;$('#media-message').textContent=s.error?`Error: ${s.error}`:s.running?`Resolving ${Math.min(s.completed+1,s.total)} of ${s.total} · ${pct}% complete`:s.completed?`${s.completed} questions processed. Review selections or export the package.`:'Acquire questions first.';$('#cancel-media').disabled=!s.running;$('#resolve').disabled=s.running;latestItems=s.items||[];renderResults();const ac=await api('/api/acquire/status');$('#resolve').disabled=s.running||!ac.question_count;$('#export-package').disabled=!ac.question_count;$('#package-summary').textContent=ac.question_count?`${Number(ac.question_count).toLocaleString()} questions · ${latestItems.filter(x=>x.selected).length.toLocaleString()} resolved images`:'';if(!s.running&&s.completed&&mediaPoll){clearInterval(mediaPoll);mediaPoll=null}}catch(e){console.error(e)}}
function renderResults(){const box=$('#result-list');if(!latestItems.length){box.innerHTML='<div class="empty">Resolved media will appear here.</div>';return}box.innerHTML=[...latestItems].reverse().map(item=>{const selected=item.selected?`${item.selected.provider}:${item.selected.provider_key}`:'',cands=(item.candidates||[]).slice(0,8);return `<article class="result"><div class="result-head"><div><h3>${esc(item.prompt||item.query)}</h3><small>${esc(item.query||'')}</small></div><span class="status ${selected?'ok':'miss'}">${selected?'RESOLVED':'NO SAFE IMAGE'}</span></div><div class="candidates">${cands.map(c=>{const key=`${c.provider}:${c.provider_key}`,sel=key===selected,src=c.thumbnail_url||c.image_url;return `<div class="candidate ${sel?'selected':''}" data-q="${esc(item.id)}" data-provider="${esc(c.provider)}" data-key="${esc(c.provider_key)}">${src?`<img src="${esc(src)}" alt="" referrerpolicy="no-referrer" onerror="this.outerHTML='<div class=&quot;fallback&quot;>Image failed</div>'">`:'<div class="fallback">No preview</div>'}<em>${sel?'SELECTED':c.auto_eligible?'SAFE':'REVIEW'}</em><div class="candidate-copy"><b>${esc(c.title||c.provider)}</b><small>${esc(c.license||'License unknown')}</small></div></div>`}).join('')}</div></article>`}).join('');$$('.candidate').forEach(el=>el.onclick=async()=>{try{await api('/api/select',{method:'POST',body:JSON.stringify({question_id:el.dataset.q,provider:el.dataset.provider,provider_key:el.dataset.key})});await updateMedia();toast('Selection changed for export.')}catch(e){toast(e.message)}})}

$('#export-package').onclick=async()=>{try{const data=await api('/api/content/package');if(!data.question_count)return toast('Acquire questions first.');downloadJson(`whatmod-trivia-content-package-${data.question_count}-${new Date().toISOString().replace(/[:.]/g,'-')}.json`,data);toast(`Exported ${data.question_count} questions in one content package.`)}catch(e){toast(e.message)}};

// Backward-compatible existing media-job flow.
function loadLegacy(text,name='job.json'){try{const d=JSON.parse(text);if(d.format!=='whatmod-trivia-media-job'||Number(d.version)!==1||!Array.isArray(d.questions))throw new Error('Not a WhatMod Trivia media job.');legacyJob=d;$('#job-meta').textContent=`${name} · ${d.questions.length.toLocaleString()} questions`;$('#start-legacy').disabled=!d.questions.length;toast(`Loaded ${d.questions.length} existing questions`)}catch(e){legacyJob=null;$('#start-legacy').disabled=true;toast(e.message)}}
$('#job-file').addEventListener('change',async e=>{const f=e.target.files?.[0];if(f)loadLegacy(await f.text(),f.name)});const dz=$('#drop-zone');['dragenter','dragover'].forEach(x=>dz.addEventListener(x,e=>{e.preventDefault();dz.classList.add('over')}));['dragleave','drop'].forEach(x=>dz.addEventListener(x,e=>{e.preventDefault();dz.classList.remove('over')}));dz.addEventListener('drop',async e=>{const f=e.dataTransfer.files?.[0];if(f)loadLegacy(await f.text(),f.name)});
$('#start-legacy').onclick=async()=>{if(!legacyJob)return;try{await api('/api/start',{method:'POST',body:JSON.stringify({job:legacyJob,concurrency:Number($('#concurrency').value),probe_count:Number($('#probe-count').value)})});$('#export-legacy').disabled=true;startMediaPolling()}catch(e){toast(e.message)}};
$('#export-legacy').onclick=async()=>{try{const data=await api('/api/results');downloadJson(`whatmod-trivia-media-results-${data.question_count}-${new Date().toISOString().replace(/[:.]/g,'-')}.json`,data)}catch(e){toast(e.message)}};

(async()=>{try{await loadTemplates();await updateAcquire();await updateMedia();$('#export-legacy').disabled=false}catch(e){toast(e.message)}})();
