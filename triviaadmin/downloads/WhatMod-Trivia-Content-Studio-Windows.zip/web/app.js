const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
let templates=[], acquirePoll=null, mediaPoll=null, categoryPoll=null, latestItems=[], legacyJob=null, topicPacks={starters:[],saved:[]}, currentTopicPreview=null, categoryDashboard=null, backendInfo={version:'legacy',capabilities:[]};
let templateSelection=new Set(), templatesLoadedOnce=false;
let liveConfig={configured:false}, liveDashboard=null, liveQuestionQuery={search:'',category:'',difficulty:'any',status:'active',offset:0,limit:50}, currentLiveQuestion=null;
const CATEGORY_ORDER=["Brainrot","General Gaming Knowledge","Internet Culture","Pop Culture","Movies & TV","Music","Food & Brands","General Knowledge","Science","Technology","History","Geography","Animals","Space","Sports","Entertainment","Business"];
function toast(msg){const n=document.createElement('div');n.className='toast';n.textContent=msg;$('#toast-root').appendChild(n);setTimeout(()=>n.remove(),3200)}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}
async function api(path,opts={}){const r=await fetch(path,{...opts,headers:{'Content-Type':'application/json',...(opts.headers||{})}});let b={};try{b=await r.json()}catch{}if(!r.ok){const e=new Error(b.error||`Request failed ${r.status}`);e.status=r.status;e.payload=b;throw e}return b}
function downloadJson(filename,data){const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function fmtTime(sec){sec=Math.max(0,Number(sec||0));if(sec<60)return `${Math.round(sec)}s`;const m=Math.floor(sec/60),s=Math.round(sec%60);return `${m}m ${s}s`}


function baseCategoryRow(category,known=false){return {category,total_count:known?0:null,active_count:known?0:null,easy_count:known?0:null,medium_count:known?0:null,hard_count:known?0:null,valid_photo_count:known?0:null,missing_photo_count:known?0:null,retired_count:known?0:null,terms:[category]}}
function completeCategoryRows(rows=[],known=true){
  const map=new Map(CATEGORY_ORDER.map(c=>[c,baseCategoryRow(c,known)]));
  for(const pack of (topicPacks.saved||[])){const name=String(pack?.category||'').trim();if(name&&!map.has(name))map.set(name,baseCategoryRow(name,known))}
  for(const row of (rows||[])){const name=String(row?.category||'').trim();if(!name)continue;map.set(name,{...baseCategoryRow(name,known),...(map.get(name)||{}),...row,category:name,terms:row.terms?.length?row.terms:(map.get(name)?.terms||[name])})}
  return [...map.values()].sort((a,b)=>{const ai=CATEGORY_ORDER.indexOf(a.category),bi=CATEGORY_ORDER.indexOf(b.category);if(ai>=0||bi>=0){if(ai<0)return 1;if(bi<0)return-1;return ai-bi}return a.category.localeCompare(b.category)});
}
function normalizeCategoryDashboard(payload){
  if(payload?.format==='whatmod-trivia-category-acquisition-job'&&Number(payload.version)===1){return {format:'whatmod-trivia-category-dashboard',version:1,generated_at:payload.generated_at||new Date().toISOString(),categories:[{category:payload.category,...(payload.current||{}),terms:payload.terms||[payload.category],job:payload}]}}
  if(payload?.format==='whatmod-trivia-category-dashboard'&&Number(payload.version)===1&&Array.isArray(payload.categories))return {...payload,categories:completeCategoryRows(payload.categories,true)};
  throw new Error('Not a WhatMod Trivia category snapshot/job.');
}
function localCategoryRows(){const map=new Map(completeCategoryRows([],false).map(r=>[r.category,r]));for(const t of templates){const r=map.get(t.category)||baseCategoryRow(t.category,false);if(t.difficulty==='easy')r.easy_generators=(r.easy_generators||0)+1;if(t.difficulty==='medium')r.medium_generators=(r.medium_generators||0)+1;if(t.difficulty==='hard')r.hard_generators=(r.hard_generators||0)+1;map.set(t.category,r)}return completeCategoryRows([...map.values()],false)}
function renderCategoryManager(){
  const rows=categoryDashboard?.categories?.length?categoryDashboard.categories:[];
  const box=$('#category-manager-grid');if(!box)return;
  box.innerHTML=rows.length?rows.map(r=>{const known=r.active_count!=null,active=Number(r.active_count||0),photos=Number(r.valid_photo_count||0),pct=known&&active?Math.round(photos/active*100):0,generators=templates.filter(t=>t.category===r.category).length,empty=known&&active===0;return `<article class="category-manager-card ${empty?'empty-category':''}"><div class="category-manager-title"><div><small>${known?(empty?'EMPTY LIVE BANK':'LIVE BANK'):'LOCAL CATEGORY'}</small><h3>${esc(r.category)}</h3></div><strong>${known?active.toLocaleString():'—'}</strong></div><div class="category-manager-counts">${known?`<span><b>${Number(r.easy_count||0).toLocaleString()}</b> easy</span><span><b>${Number(r.medium_count||0).toLocaleString()}</b> med</span><span><b>${Number(r.hard_count||0).toLocaleString()}</b> hard</span>`:`<span><b>${generators}</b> fixed generators</span><span><b>${generators?'＋':'✓'}</b> topic discovery fallback</span>`}</div>${known&&active?`<div class="category-manager-photo"><i style="width:${pct}%"></i></div><small>${pct}% photo coverage · ${Number(r.missing_photo_count||0).toLocaleString()} missing</small>`:known?`<div class="category-needs-hydration"><b>Needs questions</b><span>Players stay blocked until this category has active questions.</span></div>`:''}<div class="category-quick-controls"><select data-cat-count><option>25</option><option>50</option><option selected>100</option><option>250</option><option>500</option></select><select data-cat-audience><option value="mainstream">Mainstream</option><option value="balanced">Balanced</option><option value="deep">Deep cuts</option></select><select data-cat-focus><option value="smart">Smart difficulty</option><option value="balanced">Balanced</option><option value="easy">Easy</option><option value="medium">Medium</option><option value="hard">Hard</option></select></div><button class="btn primary ${empty?'urgent':''}" data-category-run="${esc(r.category)}">${empty?'Hydrate + Resolve Media':'Acquire + Resolve Media'}</button></article>`}).join(''):'<div class="empty">No category dashboard loaded.</div>';
  $$('[data-category-run]').forEach(btn=>btn.onclick=()=>startCategoryRun(btn.closest('.category-manager-card'),rows.find(x=>x.category===btn.dataset.categoryRun)));
}
async function loadCategoryDashboardFile(file){if(!file)return;try{categoryDashboard=normalizeCategoryDashboard(JSON.parse(await file.text()));$('#category-dashboard-meta').textContent=`Admin snapshot · ${categoryDashboard.categories.length} categories · ${categoryDashboard.generated_at?new Date(categoryDashboard.generated_at).toLocaleString():''}`;renderCategoryManager();toast('Category dashboard loaded.')}catch(e){toast(e.message)}}
async function sleep(ms){return new Promise(r=>setTimeout(r,ms))}
async function detectBackend(){
  try{backendInfo=await api('/api/version');const el=$('#category-dashboard-meta');if(el&&backendInfo?.version)el.dataset.backend=`v${backendInfo.version}`;return backendInfo}
  catch(e){backendInfo={version:'legacy',capabilities:[]};return backendInfo}
}
async function runCategoryCompatibility(row,count,audience,focus){
  const title=$('#category-run-title'),msg=$('#category-run-message'),state=$('#category-run-state'),bar=$('#category-run-bar'),exportBtn=$('#category-export-package');
  $('#category-run-panel').hidden=false;if(title)title.textContent=row.category;if(state){state.textContent='COMPAT MODE';state.className='pill'}if(exportBtn)exportBtn.disabled=true;
  if(msg)msg.textContent='Older Studio backend detected. Using compatibility acquisition…';if(bar)bar.style.width='8%';
  await api('/api/content/clear-package',{method:'POST',body:'{}'});
  const terms=(row.terms&&row.terms.length?row.terms:[row.category]).join(', ');
  const preview=await api('/api/topic/preview',{method:'POST',body:JSON.stringify({terms,category:row.category,audience,depth:250,include_numeric:true,include_identify:true})});
  const available=Number(preview.question_count||0);if(!available)throw new Error(`No usable ${row.category} question candidates were found. Try Balanced/Deep cuts or restart the newest Studio for fixed-generator support.`);
  const take=Math.min(count,available);if(msg)msg.textContent=`Compatibility mode found ${available.toLocaleString()} candidates. Acquiring ${take.toLocaleString()}…`;if(bar)bar.style.width='28%';
  await api('/api/topic/acquire',{method:'POST',body:JSON.stringify({preview_id:preview.preview_id,count:take,name:row.category})});
  if(msg)msg.textContent=`${take.toLocaleString()} acquired. Resolving media…`;if(bar)bar.style.width='40%';
  await api('/api/content/resolve',{method:'POST',body:JSON.stringify({concurrency:Number($('#concurrency')?.value||4),probe_count:Number($('#probe-count')?.value||4)})});
  const started=Date.now();while(Date.now()-started<45*60*1000){const m=await api('/api/status');const pct=m.total?Math.round(Number(m.completed||0)/Number(m.total)*100):0;if(bar)bar.style.width=`${40+Math.round(pct*.6)}%`;if(msg)msg.textContent=`Resolving media ${Number(m.completed||0).toLocaleString()} / ${Number(m.total||0).toLocaleString()}…`;if(!m.running&&Number(m.total||0)>0&&Number(m.completed||0)>=Number(m.total||0))break;await sleep(800)}
  if(state){state.textContent='READY';state.className='pill muted'}if(msg)msg.textContent=`Ready: ${take.toLocaleString()} ${row.category} questions acquired with media pass complete.`;if(bar)bar.style.width='100%';if(exportBtn)exportBtn.disabled=false;await updateAcquire();await updateMedia();
}
async function startCategoryRun(card,row){
  if(!row)return;const count=Number(card.querySelector('[data-cat-count]').value||100),audience=card.querySelector('[data-cat-audience]').value,focus=card.querySelector('[data-cat-focus]').value;
  if(!confirm(`Acquire up to ${count} new ${row.category} questions and immediately resolve their media? The current local package will be replaced.`))return;
  const payload={category:row.category,requested:count,audience,difficulty_focus:focus,current:row.current||row,terms:row.terms||[row.category],acquire_workers:Number($('#acquire-workers')?.value||3),media_workers:Number($('#concurrency')?.value||4),probe_count:Number($('#probe-count')?.value||4)};
  try{await api('/api/category/start',{method:'POST',body:JSON.stringify(payload)});$('#category-run-panel').hidden=false;$('#category-run-title').textContent=row.category;$('#category-export-package').disabled=true;startCategoryPolling()}
  catch(e){if(Number(e.status)===404){try{await runCategoryCompatibility(row,count,audience,focus);toast('Category run completed using compatibility mode. Restart the newest Studio before your next session for the full pipeline.')}catch(inner){toast(inner.message)}}else toast(e.message)}
}
function startCategoryPolling(){clearInterval(categoryPoll);categoryPoll=setInterval(updateCategoryRun,700);updateCategoryRun()}
async function updateCategoryRun(){try{const s=await api('/api/category/status'),media=s.media||{},ac=s.acquire||{};$('#category-run-state').textContent=s.running?String(s.stage||'RUNNING').toUpperCase():String(s.stage||'IDLE').toUpperCase();$('#category-run-state').className=`pill ${s.running?'':'muted'}`;$('#category-run-message').textContent=s.message||'Ready.';const pct=s.stage==='media'&&media.total?Math.round(Number(media.completed||0)/Number(media.total)*100):s.stage==='ready'?100:ac.total_templates?Math.round(Number(ac.completed_templates||0)/Number(ac.total_templates)*100):0;$('#category-run-bar').style.width=`${pct}%`;$('#category-cancel').disabled=!s.running;$('#category-export-package').disabled=s.stage!=='ready';const cp=$('#category-publish-live');if(cp)cp.disabled=s.stage!=='ready'||!liveConfig.configured;if(!s.running&&categoryPoll){clearInterval(categoryPoll);categoryPoll=null;await updateAcquire();await updateMedia()}}catch(e){if(Number(e.status)===404){clearInterval(categoryPoll);categoryPoll=null;$('#category-run-message').textContent='The local backend is older than this frontend. Use the newest V20 launcher or rerun the category to use compatibility mode.'}else console.error(e)}}

function closeTopicModal(){const m=$('#topic-modal');if(m)m.hidden=true}
function openTopicModal(pack=null){
  const m=$('#topic-modal');if(!m)return;
  currentTopicPreview=null;m.hidden=false;
  $('#topic-preview-results').hidden=true;$('#topic-search-status').textContent='Nothing searched yet.';
  if(pack){$('#topic-terms').value=(pack.terms||[]).join(', ');$('#topic-category').value=pack.category||pack.name||'General Knowledge';$('#topic-audience').value=pack.audience||'mainstream';$('#topic-pack-name').value=pack.name||pack.category||''}
  else{$('#topic-terms').value='';$('#topic-category').value='General Knowledge';$('#topic-audience').value=$('#audience-mode')?.value||'mainstream';$('#topic-pack-name').value=''}
}
function renderTopicPacks(){
  const starters=topicPacks.starters||[],saved=topicPacks.saved||[];
  $('#starter-topic-packs').innerHTML=starters.map(p=>`<button class="topic-chip" data-starter-topic="${esc(p.id)}"><b>${esc(p.name)}</b><small>${esc(p.description||'')}</small></button>`).join('')||'<span class="hint">No starter packs.</span>';
  $('#saved-topic-packs').innerHTML=saved.length?`<div class="saved-topic-head"><b>Saved topic packs</b><span>${saved.length} tracked locally</span></div><div class="saved-topic-grid">${saved.map(p=>`<article class="saved-topic"><div><b>${esc(p.name||p.category)}</b><small>${esc((p.terms||[]).join(' · '))}</small><span>${esc(p.category)} · index ${Number(p.index||0).toLocaleString()} · ${Number(p.acquired_total||0).toLocaleString()} acquired</span></div><div><button class="micro" data-topic-more="${esc(p.id)}">Find next</button><button class="micro danger-micro" data-topic-delete="${esc(p.id)}">Remove</button></div></article>`).join('')}</div>`:'';
  $$('[data-starter-topic]').forEach(b=>b.onclick=()=>openTopicModal(starters.find(x=>x.id===b.dataset.starterTopic)));
  $$('[data-topic-more]').forEach(b=>b.onclick=async()=>{try{b.disabled=true;b.textContent='Searching…';const r=await api('/api/topic/acquire-saved',{method:'POST',body:JSON.stringify({topic_id:b.dataset.topicMore,count:100,depth:150})});toast(r.added?`Added ${r.added} more questions.`:`No new usable questions found in this slice.`);await loadTopicPacks();await updateAcquire();}catch(e){toast(e.message)}finally{b.disabled=false;b.textContent='Find next'}});
  $$('[data-topic-delete]').forEach(b=>b.onclick=async()=>{if(!confirm('Remove this saved local topic pack? Already acquired questions remain in the current package.'))return;try{await api('/api/topic/delete-saved',{method:'POST',body:JSON.stringify({topic_id:b.dataset.topicDelete})});await loadTopicPacks();toast('Saved topic pack removed.')}catch(e){toast(e.message)}});
}
async function loadTopicPacks(){topicPacks=await api('/api/topic/packs');renderTopicPacks()}
function renderTopicPreview(r){
  currentTopicPreview=r;$('#topic-preview-results').hidden=false;
  $('#topic-count').textContent=Number(r.question_count||0).toLocaleString();$('#topic-numeric-count').textContent=Number(r.numeric_count||0).toLocaleString();$('#topic-identify-count').textContent=Number(r.identify_count||0).toLocaleString();$('#topic-entity-count').textContent=Number(r.entity_count||0).toLocaleString();
  $('#topic-acquire-count').max=Math.max(1,Number(r.question_count||1));$('#topic-acquire-count').value=Math.min(100,Math.max(1,Number(r.question_count||1)));
  $('#topic-pack-name').value=$('#topic-pack-name').value||r.category||'';
  $('#topic-preview-list').innerHTML=(r.questions||[]).length?(r.questions||[]).map(q=>`<article><div><b>${esc(q.prompt)}</b><small>${esc(q.question_type)} · ${esc(q.category)} · ${esc(q.difficulty)}</small></div><a href="${esc(q.source_url||'#')}" target="_blank" rel="noopener">source ↗</a></article>`).join(''):'<div class="empty">No usable question candidates found in this scan. Try Balanced/Deep cuts, broader terms, or a larger search depth.</div>';
  $('#topic-search-status').textContent=`${Number(r.question_count||0).toLocaleString()} candidates from ${Number(r.entity_count||0).toLocaleString()} usable source entities${r.has_more?' · more source results available':''}.`;
}

function updateTemplateSummary(){
  const cats=new Set(templates.filter(t=>templateSelection.has(t.id)).map(t=>t.category));
  $('#template-summary').textContent=`${templateSelection.size} selected · ${templates.length} generators · ${cats.size||new Set(templates.map(t=>t.category)).size} categories`;
}
function bindTemplateRows(){
  $$('#template-list input[type="checkbox"]').forEach(box=>box.onchange=()=>{box.checked?templateSelection.add(box.value):templateSelection.delete(box.value);updateTemplateSummary()});
  $$('[data-cat-toggle]').forEach(btn=>btn.onclick=()=>{const cat=btn.dataset.catToggle,rows=templates.filter(t=>t.category===cat && templateVisible(t)),all=rows.length&&rows.every(t=>templateSelection.has(t.id));rows.forEach(t=>all?templateSelection.delete(t.id):templateSelection.add(t.id));renderTemplates()});
}
function templateVisible(t){const q=String($('#template-filter')?.value||'').trim().toLowerCase();return !q||`${t.name} ${t.category} ${t.difficulty} ${t.note||''}`.toLowerCase().includes(q)}
function renderTemplates(){
  const groups={};for(const t of templates){if(!templateVisible(t))continue;(groups[t.category]??=[]).push(t)}
  const cats=[...new Set([...CATEGORY_ORDER,...Object.keys(groups)])].filter(c=>groups[c]?.length);
  $('#template-list').innerHTML=cats.length?cats.map(cat=>{
    const rows=groups[cat],all=rows.every(t=>templateSelection.has(t.id));
    return `<section class="template-group"><div class="template-group-head"><div><b>${esc(cat)}</b><small>${rows.length} generators</small></div><button class="micro" data-cat-toggle="${esc(cat)}">${all?'Clear category':'Select category'}</button></div><div class="template-grid">${rows.map(t=>`<label class="template ${t.recommended?'recommended':''}"><input type="checkbox" value="${esc(t.id)}" ${templateSelection.has(t.id)?'checked':''}><span><b>${esc(t.name)}</b><small>${esc(t.difficulty)} · next ${Number(t.offset||0).toLocaleString()}${t.note?` · ${esc(t.note)}`:''}</small></span>${t.recommended?'<em>REC</em>':''}</label>`).join('')}</div></section>`
  }).join(''):'<div class="empty">No generators match that filter.</div>';
  bindTemplateRows();updateTemplateSummary();
}
async function loadTemplates(){
  const body=await api('/api/templates');templates=body.templates||[];
  if(!templatesLoadedOnce){templateSelection=new Set(templates.filter(t=>t.recommended).map(t=>t.id));templatesLoadedOnce=true}
  else templateSelection=new Set([...templateSelection].filter(id=>templates.some(t=>t.id===id)));
  renderTemplates();
  if(categoryDashboard&&!categoryDashboard.categories?.length){categoryDashboard={format:'whatmod-trivia-category-dashboard',version:1,categories:localCategoryRows()};renderCategoryManager()}
}
$('#template-filter').oninput=()=>renderTemplates();
$('#select-recommended').onclick=()=>{templateSelection=new Set(templates.filter(t=>t.recommended).map(t=>t.id));renderTemplates()};
$('#select-all').onclick=()=>{templates.filter(templateVisible).forEach(t=>templateSelection.add(t.id));renderTemplates()};
$('#clear-all').onclick=()=>{templates.filter(templateVisible).forEach(t=>templateSelection.delete(t.id));renderTemplates()};
$('#offset-mode').onchange=()=>{$('#custom-offset').disabled=$('#offset-mode').value!=='custom'};
$('#acquire').onclick=async()=>{try{const selected=[...templateSelection];if(!selected.length)return toast('Select at least one generator.');const requested=selected.length*Number($('#per-template').value);if(requested>4000&&!confirm(`This run requests up to ${requested.toLocaleString()} questions across ${selected.length} generators. It can take a while. Continue?`))return;await api('/api/acquire/start',{method:'POST',body:JSON.stringify({templates:selected,per_template:Number($('#per-template').value),offset_mode:$('#offset-mode').value,custom_offset:Number($('#custom-offset').value||0),workers:Number($('#acquire-workers').value||3),audience:$('#audience-mode').value})});$('#acquire').disabled=true;$('#cancel-acquire').disabled=false;startAcquirePolling()}catch(e){toast(e.message)}};
$('#cancel-acquire').onclick=async()=>{try{await api('/api/acquire/cancel',{method:'POST',body:'{}'});toast('Stop requested. In-flight network calls can take a few seconds to exit.')}catch(e){toast(e.message)}};
$('#reset-offsets').onclick=async()=>{if(!confirm('Reset all local generator offsets back to 0? This does not delete anything from Supabase.'))return;try{await api('/api/content/reset-offsets',{method:'POST',body:'{}'});await loadTemplates();toast('Local offsets reset.')}catch(e){toast(e.message)}};
$('#open-topic-search').onclick=()=>openTopicModal();
$$('[data-close-topic]').forEach(x=>x.onclick=closeTopicModal);
$('#topic-preview').onclick=async()=>{try{
  const terms=$('#topic-terms').value.trim(),category=$('#topic-category').value.trim()||'General Knowledge';if(!terms)return toast('Enter a topic or search phrase.');
  const b=$('#topic-preview');b.disabled=true;b.textContent='Searching…';$('#topic-search-status').textContent='Searching Wikidata and checking usable facts…';
  const r=await api('/api/topic/preview',{method:'POST',body:JSON.stringify({terms,category,audience:$('#topic-audience').value,depth:Number($('#topic-depth').value||100),include_numeric:$('#topic-numeric').checked,include_identify:$('#topic-identify').checked})});renderTopicPreview(r);
}catch(e){$('#topic-search-status').textContent=`Search failed: ${e.message}`;toast(e.message)}finally{$('#topic-preview').disabled=false;$('#topic-preview').textContent='Search availability'}};
$('#topic-acquire').onclick=async()=>{try{if(!currentTopicPreview)return toast('Search availability first.');const count=Math.max(1,Math.min(Number($('#topic-acquire-count').value||1),Number(currentTopicPreview.question_count||0)));if(!count)return toast('No questions are available to acquire.');const b=$('#topic-acquire');b.disabled=true;b.textContent='Acquiring…';const r=await api('/api/topic/acquire',{method:'POST',body:JSON.stringify({preview_id:currentTopicPreview.preview_id,count,name:$('#topic-pack-name').value.trim()||currentTopicPreview.category})});toast(`Added ${r.added} questions to the current package.`);closeTopicModal();await loadTopicPacks();await updateAcquire();}catch(e){toast(e.message)}finally{$('#topic-acquire').disabled=false;$('#topic-acquire').textContent='Acquire into current package'}};
$('#clear-package').onclick=async()=>{if(!confirm('Clear the current local question/media package? Saved topic indexes are not affected.'))return;try{await api('/api/content/clear-package',{method:'POST',body:'{}'});latestItems=[];renderResults();await updateAcquire();toast('Current package cleared.')}catch(e){toast(e.message)}};
function startAcquirePolling(){clearInterval(acquirePoll);acquirePoll=setInterval(updateAcquire,650);updateAcquire()}
function renderAcquireEvents(events=[]){const box=$('#acquire-events');const rows=events.slice(-10).reverse();box.innerHTML=rows.length?rows.map(ev=>{const stage=ev.stage||'',bad=stage==='error'||ev.ok===false,good=stage==='done'&&ev.ok!==false;return `<div class="event ${bad?'bad':good?'good':''}"><span>${bad?'!':good?'✓':stage==='scan'?'↻':'•'}</span><div><b>${esc(ev.name||ev.template||'Generator')}</b><small>${esc(ev.message||'Working…')}${ev.seconds!=null?` · ${esc(ev.seconds)}s`:''}</small></div></div>`}).join(''):'<div class="event muted-event">No acquisition activity yet.</div>'}
async function updateAcquire(){try{
  const s=await api('/api/acquire/status'),pct=s.total_templates?Math.round(s.completed_templates/s.total_templates*100):0;
  $('#acquire-state').textContent=s.running?'RUNNING':(s.question_count?'READY':(s.errors?.length?'FINISHED WITH ERRORS':'IDLE'));
  $('#acquire-state').className=`pill ${s.running?'':'muted'}`;$('#acquire-bar').style.width=`${pct}%`;$('#acquired-count').textContent=Number(s.question_count||0).toLocaleString();
  const ev=s.events?.at(-1);let msg='Ready.';
  if(s.running)msg=ev?.message||`Running ${s.workers||3} acquisition workers · ${s.completed_templates}/${s.total_templates} generators complete`;
  else if(s.errors?.length)msg=`${Number(s.question_count||0).toLocaleString()} acquired · ${s.errors.length} generator error(s) · ${fmtTime(s.elapsed)}`;
  else if(s.question_count)msg=`${Number(s.question_count).toLocaleString()} questions ready · ${fmtTime(s.elapsed)}`;
  $('#acquire-message').textContent=msg;renderAcquireEvents(s.events||[]);
  $('#acquire').disabled=s.running;$('#cancel-acquire').disabled=!s.running;$('#resolve').disabled=s.running||!s.question_count;$('#export-package').disabled=!s.question_count;syncPublishButtons(Boolean(s.question_count));
  $('#package-summary').textContent=s.question_count?`${Number(s.question_count).toLocaleString()} questions ready${latestItems.length?` · ${latestItems.filter(x=>x.selected).length.toLocaleString()} images selected`:''}`:'Nothing ready yet.';
  if(s.question_count)await renderQuestionPreview();
  if(!s.running&&acquirePoll){clearInterval(acquirePoll);acquirePoll=null;await loadTemplates()}
}catch(e){console.error(e);$('#acquire-message').textContent=`Status error: ${e.message}`}}
async function renderQuestionPreview(){try{const b=await api('/api/acquire/questions'),items=b.questions||[];$('#question-preview').innerHTML=items.length?items.slice(0,160).map(q=>`<article><div><b>${esc(q.prompt)}</b><small>${esc(q.category)} · ${esc(q.difficulty)} · ${esc(q.canonical_key)}</small></div><strong>${q.question_type==='multiple_choice'?esc((q.options||[])[Number(q.correct_option||0)]||'MCQ'):`${esc(q.answer_numeric)} ${esc(q.unit||'')}`}</strong></article>`).join(''):'<div class="empty">No questions acquired.</div>'}catch(e){console.error(e)}}
async function generateFunVariants(){
  const btn=$('#generate-fun'),status=$('#fun-status');
  try{
    btn.disabled=true;btn.textContent='Generating…';
    const out=await api('/api/content/derive-fun',{method:'POST',body:JSON.stringify({count:Number($('#fun-count').value||25),style:'mixed'})});
    status.textContent=out.added?`Added ${Number(out.added).toLocaleString()} source-backed fun comparison questions · ${Number(out.package_total).toLocaleString()} total in package.`:'No compatible sourced numeric facts were found in the current package.';
    toast(out.added?`Added ${out.added} fun variants.`:'No compatible facts to transform.');
    await updateAcquire();
  }catch(e){status.textContent=`Could not generate variants: ${e.message}`;toast(e.message)}
  finally{btn.disabled=false;btn.textContent='Generate fun variants'}
}
$('#generate-fun').onclick=generateFunVariants;


$('#resolve').onclick=async()=>{try{await api('/api/content/resolve',{method:'POST',body:JSON.stringify({concurrency:Number($('#concurrency').value),probe_count:Number($('#probe-count').value)})});$('#resolve').disabled=true;$('#cancel-media').disabled=false;startMediaPolling()}catch(e){toast(e.message)}};
$('#cancel-media').onclick=async()=>{try{await api('/api/cancel',{method:'POST',body:'{}'});toast('Stop requested.')}catch(e){toast(e.message)}};
function startMediaPolling(){clearInterval(mediaPoll);mediaPoll=setInterval(updateMedia,650);updateMedia()}
async function updateMedia(){try{
  const s=await api('/api/status'),pct=s.total?Math.round(s.completed/s.total*100):0;
  $('#media-bar').style.width=`${pct}%`;$('#done').textContent=`${s.completed}/${s.total}`;$('#resolved').textContent=s.resolved;$('#missing').textContent=s.missing;$('#speed').textContent=`${Math.round((s.rate||0)*60)}/m`;
  $('#media-state').textContent=s.running?'RUNNING':(s.completed?'COMPLETE':'IDLE');$('#media-state').className=`pill ${s.running?'':'muted'}`;
  const mediaOnly=!!(s.job&&s.job.format==='whatmod-trivia-media-job'&&s.job.scope!=='local-acquired');
  $('#media-message').textContent=s.error?`Error: ${s.error}`:s.running?`Resolving ${Math.min(s.completed+1,s.total)} of ${s.total} · ${pct}% complete`:s.completed?`${s.completed} questions processed. ${mediaOnly?'Export the media results or a unified media-only content package.':'Review selections or export the package.'}`:'Acquire questions first or load a media-only job below.';
  $('#cancel-media').disabled=!s.running;latestItems=s.items||[];renderResults();
  const ac=await api('/api/acquire/status');
  $('#resolve').disabled=s.running||!ac.question_count;
  const hasAcquired=Number(ac.question_count||0)>0,hasResolvedMedia=Number(s.completed||0)>0&&latestItems.length>0;
  $('#export-package').disabled=!(hasAcquired||hasResolvedMedia);syncPublishButtons(hasAcquired||hasResolvedMedia);
  $('#export-legacy').disabled=!hasResolvedMedia;
  $('#package-summary').textContent=hasAcquired?`${Number(ac.question_count).toLocaleString()} questions · ${latestItems.filter(x=>x.selected).length.toLocaleString()} resolved images`:hasResolvedMedia?`${latestItems.length.toLocaleString()} existing questions · ${latestItems.filter(x=>x.selected).length.toLocaleString()} images selected · media-only package ready`:'';
  if(!s.running&&s.completed&&mediaPoll){clearInterval(mediaPoll);mediaPoll=null}
}catch(e){console.error(e)}}

function renderResults(){const box=$('#result-list');if(!latestItems.length){box.innerHTML='<div class="empty">Resolved media will appear here.</div>';return}box.innerHTML=[...latestItems].reverse().map(item=>{const selected=item.selected?`${item.selected.provider}:${item.selected.provider_key}`:'',cands=(item.candidates||[]).slice(0,8);return `<article class="result"><div class="result-head"><div><h3>${esc(item.prompt||item.query)}</h3><small>${esc(item.query||'')}</small></div><span class="status ${selected?'ok':'miss'}">${selected?'RESOLVED':'NO SAFE IMAGE'}</span></div><div class="candidates">${cands.map(c=>{const key=`${c.provider}:${c.provider_key}`,sel=key===selected,src=c.thumbnail_url||c.image_url;return `<div class="candidate ${sel?'selected':''}" data-q="${esc(item.id)}" data-provider="${esc(c.provider)}" data-key="${esc(c.provider_key)}">${src?`<img src="${esc(src)}" alt="" referrerpolicy="no-referrer" onerror="this.outerHTML='<div class=&quot;fallback&quot;>Image failed</div>'">`:'<div class="fallback">No preview</div>'}<em>${sel?'SELECTED':c.auto_eligible?'SAFE':'REVIEW'}</em><div class="candidate-copy"><b>${esc(c.title||c.provider)}</b><small>${esc(c.license||'License unknown')}</small></div></div>`}).join('')}</div></article>`}).join('');$$('.candidate').forEach(el=>el.onclick=async()=>{try{await api('/api/select',{method:'POST',body:JSON.stringify({question_id:el.dataset.q,provider:el.dataset.provider,provider_key:el.dataset.key})});await updateMedia();toast('Selection changed for export.')}catch(e){toast(e.message)}})}

$('#export-package').onclick=async()=>{try{const data=await api('/api/content/package');if(!data.question_count)return toast('Acquire questions or resolve a loaded media job first.');const kind=data.package_kind==='media_only'?'media-only-content':'content';downloadJson(`whatmod-trivia-${kind}-package-${data.question_count}-${new Date().toISOString().replace(/[:.]/g,'-')}.json`,data);toast(data.package_kind==='media_only'?`Exported ${data.question_count} resolved media records in a unified package.`:`Exported ${data.question_count} questions in one content package.`)}catch(e){toast(e.message)}};

// Backward-compatible existing media-job flow.
function loadLegacy(text,name='job.json'){try{const d=JSON.parse(text);if(d.format!=='whatmod-trivia-media-job'||Number(d.version)!==1||!Array.isArray(d.questions))throw new Error('Not a WhatMod Trivia media job.');legacyJob=d;$('#job-meta').textContent=`${name} · ${d.questions.length.toLocaleString()} questions`;$('#start-legacy').disabled=!d.questions.length;toast(`Loaded ${d.questions.length} existing questions`)}catch(e){legacyJob=null;$('#start-legacy').disabled=true;toast(e.message)}}
$('#job-file').addEventListener('change',async e=>{const f=e.target.files?.[0];if(f)loadLegacy(await f.text(),f.name)});const dz=$('#drop-zone');['dragenter','dragover'].forEach(x=>dz.addEventListener(x,e=>{e.preventDefault();dz.classList.add('over')}));['dragleave','drop'].forEach(x=>dz.addEventListener(x,e=>{e.preventDefault();dz.classList.remove('over')}));dz.addEventListener('drop',async e=>{const f=e.dataTransfer.files?.[0];if(f)loadLegacy(await f.text(),f.name)});
$('#start-legacy').onclick=async()=>{if(!legacyJob)return;try{await api('/api/start',{method:'POST',body:JSON.stringify({job:legacyJob,concurrency:Number($('#concurrency').value),probe_count:Number($('#probe-count').value)})});$('#export-legacy').disabled=true;$('#export-package').disabled=true;startMediaPolling()}catch(e){toast(e.message)}};
$('#export-legacy').onclick=async()=>{try{const data=await api('/api/results');downloadJson(`whatmod-trivia-media-results-${data.question_count}-${new Date().toISOString().replace(/[:.]/g,'-')}.json`,data)}catch(e){toast(e.message)}};


const categoryFile=$('#category-dashboard-file');if(categoryFile)categoryFile.onchange=e=>loadCategoryDashboardFile(e.target.files?.[0]);
const categoryDrop=$('#category-job-drop');if(categoryDrop){['dragenter','dragover'].forEach(t=>categoryDrop.addEventListener(t,e=>{e.preventDefault();categoryDrop.classList.add('over')}));['dragleave','drop'].forEach(t=>categoryDrop.addEventListener(t,e=>{e.preventDefault();categoryDrop.classList.remove('over')}));categoryDrop.addEventListener('drop',e=>{const f=e.dataTransfer?.files?.[0];if(f)loadCategoryDashboardFile(f)})}
const categoryLocal=$('#category-use-local');if(categoryLocal)categoryLocal.onclick=()=>{categoryDashboard={format:'whatmod-trivia-category-dashboard',version:1,categories:localCategoryRows()};$('#category-dashboard-meta').textContent=`All local player categories · ${CATEGORY_ORDER.length} built-ins · live Supabase population unknown`;renderCategoryManager()};
const categoryCancel=$('#category-cancel');if(categoryCancel)categoryCancel.onclick=async()=>{try{await api('/api/category/cancel',{method:'POST',body:'{}'});toast('Stop requested.')}catch(e){toast(e.message)}};
const categoryExport=$('#category-export-package');if(categoryExport)categoryExport.onclick=()=>$('#export-package').click();



// -----------------------------------------------------------------------------
// V22 Connected Studio
// -----------------------------------------------------------------------------
function setStudioView(view){
  $$('.studio-view').forEach(v=>v.hidden=v.id!==`${view}-view`);
  $$('[data-studio-view]').forEach(b=>b.classList.toggle('active',b.dataset.studioView===view));
  if(view==='live'&&liveConfig.configured)refreshLiveDashboard();
  if(view==='settings')loadSettingsUI();
  window.scrollTo({top:0,behavior:'smooth'});
}
$$('[data-studio-view]').forEach(b=>b.onclick=()=>setStudioView(b.dataset.studioView));
$$('[data-go-view]').forEach(b=>b.onclick=()=>setStudioView(b.dataset.goView));

function syncPublishButtons(hasPackage=null){
  const pub=$('#publish-live'),cat=$('#category-publish-live');
  const packageReady=hasPackage==null?!$('#export-package')?.disabled:Boolean(hasPackage);
  if(pub)pub.disabled=!liveConfig.configured||!packageReady;
  if(cat&&cat.disabled===false&&!liveConfig.configured)cat.disabled=true;
}
function renderConnectionPill(){
  const p=$('#live-connection-pill');if(!p)return;
  p.textContent=liveConfig.configured?'LIVE SUPABASE':'LOCAL MODE';p.classList.toggle('connected',!!liveConfig.configured);
}
async function loadSettingsUI(){
  try{liveConfig=await api('/api/settings');renderConnectionPill();const url=$('#settings-url'),key=$('#settings-key'),hint=$('#settings-key-hint'),st=$('#connection-status'),msg=$('#settings-message');
    if(url)url.value=liveConfig.supabase_url||'';if(key)key.value='';
    if(hint)hint.textContent=liveConfig.configured?`Saved key: ${liveConfig.key_masked} · ${liveConfig.secure_storage?'Windows DPAPI encrypted':'portable local storage'}`:'The saved key is never returned to this web page.';
    if(st){st.classList.toggle('connected',!!liveConfig.configured);st.querySelector('b').textContent=liveConfig.configured?'Supabase configured':'Not configured';st.querySelector('small').textContent=liveConfig.configured?`${liveConfig.supabase_url} · ${liveConfig.key_kind||'server key'}`:'Add your project connection below.'}
    if(msg&&liveConfig.last_test)msg.textContent=`Last test: ${liveConfig.last_test_ok?'connected':'failed'} · ${new Date(liveConfig.last_test).toLocaleString()}`;
    const dis=$('#live-disconnected'),con=$('#live-connected-content');if(dis)dis.hidden=!!liveConfig.configured;if(con)con.hidden=!liveConfig.configured;syncPublishButtons();return liveConfig;
  }catch(e){toast(e.message);return liveConfig}
}
$('#settings-save-test').onclick=async()=>{const b=$('#settings-save-test');try{b.disabled=true;b.textContent='Connecting…';const url=$('#settings-url').value.trim(),key=$('#settings-key').value.trim();await api('/api/settings/save',{method:'POST',body:JSON.stringify({supabase_url:url,secret_key:key})});const r=await api('/api/settings/test',{method:'POST',body:'{}'});$('#settings-message').textContent=r.message;toast('Live Supabase connected.');await loadSettingsUI();await refreshLiveDashboard();setStudioView('live')}catch(e){$('#settings-message').textContent=e.message;toast(e.message)}finally{b.disabled=false;b.textContent='Save + Test Connection'}};
$('#settings-test').onclick=async()=>{try{const r=await api('/api/settings/test',{method:'POST',body:'{}'});$('#settings-message').textContent=r.message;toast('Connection is healthy.');await loadSettingsUI()}catch(e){$('#settings-message').textContent=e.message;toast(e.message)}};
$('#settings-clear').onclick=async()=>{if(!confirm('Forget the saved Supabase connection on this PC?'))return;try{await api('/api/settings/clear',{method:'POST',body:'{}'});liveConfig={configured:false};liveDashboard=null;renderConnectionPill();await loadSettingsUI();toast('Supabase connection removed.')}catch(e){toast(e.message)}};

function renderLiveCategoryGrid(rows){
  const box=$('#live-category-grid');if(!box)return;
  box.innerHTML=(rows||[]).map(r=>{const active=Number(r.active_count||0),photos=Number(r.valid_photo_count||0),pct=active?Math.round(photos/active*100):0,empty=!active;return `<article class="category-manager-card ${empty?'empty-category':''}"><div class="category-manager-title"><div><small>${empty?'EMPTY · NEEDS QUESTIONS':'LIVE BANK'}</small><h3>${esc(r.category)}</h3></div><strong>${active.toLocaleString()}</strong></div><div class="category-manager-counts"><span><b>${Number(r.easy_count||0).toLocaleString()}</b> easy</span><span><b>${Number(r.medium_count||0).toLocaleString()}</b> med</span><span><b>${Number(r.hard_count||0).toLocaleString()}</b> hard</span></div>${active?`<div class="category-manager-photo"><i style="width:${pct}%"></i></div><small>${pct}% photo coverage · ${Number(r.missing_photo_count||0).toLocaleString()} missing</small>`:`<div class="category-needs-hydration"><b>Not playable yet</b><span>Hydrate this category before players can select it.</span></div>`}<div class="category-quick-controls"><select data-cat-count><option>25</option><option>50</option><option selected>100</option><option>250</option><option>500</option></select><select data-cat-audience><option value="mainstream">Mainstream</option><option value="balanced">Balanced</option><option value="deep">Deep cuts</option></select><select data-cat-focus><option value="smart">Smart difficulty</option><option value="balanced">Balanced</option><option value="easy">Easy</option><option value="medium">Medium</option><option value="hard">Hard</option></select></div><div class="live-card-actions"><button class="btn primary ${empty?'urgent':''}" data-live-hydrate="${esc(r.category)}">${empty?'Hydrate + Resolve':'Add + Resolve'}</button><button class="btn" data-live-view-category="${esc(r.category)}">Questions</button></div></article>`}).join('')||'<div class="empty">No categories returned from Supabase.</div>';
  $$('[data-live-hydrate]').forEach(btn=>btn.onclick=()=>{const row=rows.find(x=>x.category===btn.dataset.liveHydrate);setStudioView('build');categoryDashboard={format:'whatmod-trivia-category-dashboard',version:1,generated_at:new Date().toISOString(),categories:completeCategoryRows(rows,true)};renderCategoryManager();$('#category-dashboard-meta').textContent='LIVE Supabase snapshot · refreshed just now';setTimeout(()=>{const card=[...$$('#category-manager-grid .category-manager-card')].find(x=>x.querySelector('h3')?.textContent===row.category);if(card)startCategoryRun(card,row)},80)});
  $$('[data-live-view-category]').forEach(btn=>btn.onclick=()=>{liveQuestionQuery.category=btn.dataset.liveViewCategory;liveQuestionQuery.offset=0;$('#live-category-filter').value=liveQuestionQuery.category;loadLiveQuestions()});
}
function renderLiveOverview(o){const box=$('#live-overview');if(!box)return;box.innerHTML=`<div><span>ACTIVE QUESTIONS</span><b>${Number(o.active||0).toLocaleString()}</b></div><div><span>CATEGORIES</span><b>${Number(o.category_count||0).toLocaleString()}</b></div><div><span>MISSING PHOTOS</span><b>${Number(o.missing_photo||0).toLocaleString()}</b></div><div><span>RETIRED</span><b>${Number(o.retired||0).toLocaleString()}</b></div><div><span>TOTAL BANK</span><b>${Number(o.total||0).toLocaleString()}</b></div>`}
async function refreshLiveDashboard(){
  if(!liveConfig.configured)return;
  const b=$('#live-refresh');try{if(b){b.disabled=true;b.textContent='Refreshing…'};liveDashboard=await api('/api/live/dashboard');const rows=completeCategoryRows(liveDashboard.categories||[],true);renderLiveOverview(liveDashboard.overview||{});renderLiveCategoryGrid(rows);categoryDashboard={format:'whatmod-trivia-category-dashboard',version:1,generated_at:new Date().toISOString(),categories:rows};renderCategoryManager();$('#category-dashboard-meta').textContent=`LIVE Supabase · ${rows.length} categories · refreshed ${new Date().toLocaleTimeString()}`;const cf=$('#live-category-filter'),old=cf.value;cf.innerHTML='<option value="">All categories</option>'+rows.map(r=>`<option value="${esc(r.category)}">${esc(r.category)} (${Number(r.active_count||0).toLocaleString()})</option>`).join('');cf.value=old;await loadLiveQuestions();}catch(e){toast(e.message)}finally{if(b){b.disabled=false;b.textContent='Refresh Live Bank'}}
}
$('#live-refresh').onclick=refreshLiveDashboard;

async function loadLiveQuestions(){
  if(!liveConfig.configured)return;const q=new URLSearchParams({...liveQuestionQuery,limit:String(liveQuestionQuery.limit),offset:String(liveQuestionQuery.offset)});
  try{const out=await api('/api/live/questions?'+q.toString()),items=out.items||[],total=Number(out.total||0),box=$('#live-question-list');box.innerHTML=items.length?items.map(q=>`<article class="live-question-row ${q.is_active?'':'retired'}" data-live-qid="${esc(q.id)}"><div class="thumb">${q.image_url?`<img src="${esc(q.image_url)}" alt="" referrerpolicy="no-referrer" onerror="this.remove()">`:'NO IMG'}</div><div><h3>${esc(q.prompt)}</h3><div class="qtags"><span>${esc(q.category)}</span><span>${esc(q.difficulty)}</span><span>${esc(q.question_type)}</span>${q.content_locked?'<span>LOCKED</span>':''}</div><small>${esc(q.canonical_key||'manual')} · ${q.answer_numeric??q.answer_text??''} ${esc(q.unit||'')}</small></div><div class="state">${q.photo_disabled?'PHOTO OFF':q.is_active?'ACTIVE':'RETIRED'}</div></article>`).join(''):'<div class="empty">No questions match these filters.</div>';$$('[data-live-qid]').forEach(r=>r.onclick=()=>openLiveQuestion(r.dataset.liveQid));$('#live-page-label').textContent=total?`${Math.min(liveQuestionQuery.offset+1,total).toLocaleString()}–${Math.min(liveQuestionQuery.offset+liveQuestionQuery.limit,total).toLocaleString()} of ${total.toLocaleString()}`:'0 questions';$('#live-prev').disabled=liveQuestionQuery.offset<=0;$('#live-next').disabled=liveQuestionQuery.offset+liveQuestionQuery.limit>=total;}catch(e){toast(e.message)}
}
$('#live-question-filters').onsubmit=e=>{e.preventDefault();liveQuestionQuery={...liveQuestionQuery,search:$('#live-search').value.trim(),category:$('#live-category-filter').value,difficulty:$('#live-difficulty-filter').value,status:$('#live-status-filter').value,offset:0};loadLiveQuestions()};
$('#live-prev').onclick=()=>{liveQuestionQuery.offset=Math.max(0,liveQuestionQuery.offset-liveQuestionQuery.limit);loadLiveQuestions()};$('#live-next').onclick=()=>{liveQuestionQuery.offset+=liveQuestionQuery.limit;loadLiveQuestions()};

function syncLiveQuestionFields(){const t=$('#lq-type').value;$('#lq-num-wrap').hidden=t!=='numeric';$('#lq-unit-wrap').hidden=t!=='numeric';$('#lq-text-wrap').hidden=t!=='text';$('#lq-options-wrap').hidden=t!=='multiple_choice';$('#lq-correct-wrap').hidden=t!=='multiple_choice'}
$('#lq-type').onchange=syncLiveQuestionFields;
function closeLiveQuestion(){const m=$('#live-question-modal');if(m)m.hidden=true;currentLiveQuestion=null}
$$('[data-close-live-question]').forEach(b=>b.onclick=closeLiveQuestion);
async function openLiveQuestion(id=null){
  try{currentLiveQuestion=id?(await api('/api/live/question?id='+encodeURIComponent(id))).question:null;const q=currentLiveQuestion||{};$('#live-question-editor-title').textContent=id?'Edit live question':'Add live question';$('#lq-prompt').value=q.prompt||'';$('#lq-category').value=q.category||'General Knowledge';$('#lq-difficulty').value=q.difficulty||'medium';$('#lq-type').value=q.question_type||'numeric';$('#lq-context').value=q.context||'';$('#lq-answer-numeric').value=q.answer_numeric??'';$('#lq-unit').value=q.unit||'';$('#lq-answer-text').value=q.answer_text||'';$('#lq-options').value=Array.isArray(q.options)?q.options.join('\n'):'';$('#lq-correct').value=Number(q.correct_option??0)+1;$('#lq-explanation').value=q.explanation||'';$('#lq-source-url').value=q.source_url||'';$('#lq-media-query').value=q.media_query||'';$('#lq-retire').hidden=!id;$('#lq-retire').textContent=q.is_active===false?'Restore':'Retire';syncLiveQuestionFields();$('#live-question-modal').hidden=false;}catch(e){toast(e.message)}
}
$('#live-add-question').onclick=()=>openLiveQuestion(null);
$('#lq-save').onclick=async()=>{const b=$('#lq-save');try{b.disabled=true;b.textContent='Saving…';const t=$('#lq-type').value,payload={id:currentLiveQuestion?.id||null,prompt:$('#lq-prompt').value,category:$('#lq-category').value,difficulty:$('#lq-difficulty').value,question_type:t,context:$('#lq-context').value,unit:$('#lq-unit').value,answer_numeric:$('#lq-answer-numeric').value,answer_text:$('#lq-answer-text').value,options:$('#lq-options').value.split('\n').map(x=>x.trim()).filter(Boolean),correct_option:Math.max(0,Number($('#lq-correct').value||1)-1),explanation:$('#lq-explanation').value,source_url:$('#lq-source-url').value,media_query:$('#lq-media-query').value};const r=await api('/api/live/question/save',{method:'POST',body:JSON.stringify(payload)});toast(r.created?'Question added to live bank.':'Question updated.');closeLiveQuestion();await refreshLiveDashboard()}catch(e){toast(e.message)}finally{b.disabled=false;b.textContent='Save Question'}};
$('#lq-retire').onclick=async()=>{if(!currentLiveQuestion)return;const active=currentLiveQuestion.is_active===false;if(!confirm(active?'Restore this question to active rotation?':'Retire this question from active rotation?'))return;try{await api('/api/live/question/active',{method:'POST',body:JSON.stringify({id:currentLiveQuestion.id,active})});toast(active?'Question restored.':'Question retired.');closeLiveQuestion();await refreshLiveDashboard()}catch(e){toast(e.message)}};

async function publishCurrentPackage(){
  if(!liveConfig.configured)return toast('Connect Supabase in Settings first.');if(!confirm('Publish the current resolved package directly to the live Trivia bank?'))return;
  const buttons=[$('#publish-live'),$('#category-publish-live')].filter(Boolean);try{buttons.forEach(b=>{b.disabled=true;b.dataset.old=b.textContent;b.textContent='Publishing…'});const r=await api('/api/live/publish-current',{method:'POST',body:'{}'});toast(`Published: ${Number(r.created||0)} new · ${Number(r.updated||0)} updated · ${Number(r.media_published||0)} media.`);await refreshLiveDashboard();}catch(e){toast(e.message)}finally{buttons.forEach(b=>{b.textContent=b.dataset.old||'Publish to Live Bank';delete b.dataset.old});syncPublishButtons()}
}
$('#publish-live').onclick=publishCurrentPackage;$('#category-publish-live').onclick=publishCurrentPackage;

async function handleStudioFile(file){
  if(!file)return;try{const text=await file.text(),d=JSON.parse(text);if(d?.format==='whatmod-trivia-category-dashboard'||d?.format==='whatmod-trivia-category-acquisition-job'){await loadCategoryDashboardFile(file);setStudioView('build');return}if(d?.format==='whatmod-trivia-media-job'){loadLegacy(text,file.name);setStudioView('build');return}throw new Error('This Studio inbox currently accepts category snapshots/jobs and media-only jobs. Content packages are published from the current workspace or imported in Trivia Admin.')}catch(e){toast(e.message)}
}
const inbox=$('#studio-file-drop'),inboxInput=$('#studio-file-input');if(inbox&&inboxInput){inbox.onclick=()=>inboxInput.click();inboxInput.onchange=e=>handleStudioFile(e.target.files?.[0]);['dragenter','dragover'].forEach(t=>inbox.addEventListener(t,e=>{e.preventDefault();e.stopPropagation();inbox.classList.add('over')}));['dragleave','drop'].forEach(t=>inbox.addEventListener(t,e=>{e.preventDefault();e.stopPropagation();inbox.classList.remove('over')}));inbox.addEventListener('drop',e=>handleStudioFile(e.dataTransfer?.files?.[0]));}
// Global JSON drop fallback fixes Windows drag/drop when the pointer lands on nested controls.
document.addEventListener('dragover',e=>{if(e.dataTransfer?.types?.includes('Files'))e.preventDefault()});document.addEventListener('drop',e=>{if(!e.defaultPrevented&&e.dataTransfer?.files?.length){e.preventDefault();handleStudioFile(e.dataTransfer.files[0])}});


(async()=>{try{await Promise.all([loadTemplates(),loadTopicPacks(),detectBackend()]);await loadSettingsUI();await updateAcquire();await updateMedia();if(liveConfig.configured){await refreshLiveDashboard();setStudioView('live')}else setStudioView('build')}catch(e){toast(e.message)}})();
