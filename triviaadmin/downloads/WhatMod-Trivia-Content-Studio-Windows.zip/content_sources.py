import json, re, time, threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

API="https://www.wikidata.org/w/api.php"
USER_AGENT="WhatModTriviaContentStudio/3.0 (local admin utility; https://whatmod.com/trivia/)"
REQUEST_TIMEOUT=10
REQUEST_ATTEMPTS=2
SEARCH_PAGE=50
MAX_TEMPLATE_SECONDS=95
UNIT_CACHE={
    "Q11573":"m", "Q828224":"km", "Q174789":"mm", "Q174728":"cm", "Q3710":"ft", "Q218593":"in",
    "Q573":"days", "Q5151":"months", "Q23387":"weeks", "Q577":"years", "Q11574":"seconds",
    "Q21027105":"minutes", "Q25235":"minutes", "Q25224":"hours", "Q11570":"kg", "Q41803":"g",
    "1":""
}

# The acquisition engine deliberately uses broad, recognizable top-level categories that
# already exist in the Trivia UI. Each template is an independent generator and therefore
# has its own local cursor.
def T(id,name,category,difficulty,search,prop,kind,prompt,explanation,*,unit=None,minv=None,maxv=None,recommended=False,scan=7,note=""):
    return {"id":id,"name":name,"category":category,"difficulty":difficulty,"search":search,"prop":prop,"kind":kind,
            "prompt":prompt,"explanation":explanation,"unit":unit,"min":minv,"max":maxv,"recommended":recommended,
            "scan_multiplier":scan,"note":note}

def year_prompt(prefix):
    return lambda label,value,unit: prefix.format(label=label,value=value)

def year_explain(text):
    return lambda label,value,unit: text.format(label=label,value=value)

def metric_prompt(text):
    return lambda label,value,unit: text.format(label=label,value=value,unit=(unit or "units"))

def metric_explain(text):
    return lambda label,value,unit: text.format(label=label,value=format_number(value),unit=(unit or "units"))

TEMPLATES=[
  # ENTERTAINMENT
  T("film-release-year","Film release years","Entertainment","medium","haswbstatement:P31=Q11424","P577","year",
    year_prompt('In what year was the film “{label}” first released?'),year_explain('The earliest recorded release year for “{label}” is {value}.'),recommended=True),
  T("film-runtime","Film runtimes","Entertainment","medium","haswbstatement:P31=Q11424","P2047","quantity",
    metric_prompt('Approximately how long is the film “{label}”? (answer in {unit})'),metric_explain('Wikidata records a duration of about {value} {unit} for “{label}”.'),recommended=True),
  T("tv-release-year","TV series debut years","Entertainment","medium","haswbstatement:P31=Q5398426","P577","year",
    year_prompt('In what year did the television series “{label}” first premiere?'),year_explain('The earliest recorded release year for “{label}” is {value}.'),recommended=True),
  T("tv-episode-count","TV series episode counts","Entertainment","hard","haswbstatement:P31=Q5398426","P1113","quantity",
    metric_prompt('Approximately how many episodes does “{label}” have?'),metric_explain('Wikidata records about {value} episodes for “{label}”.'),unit="episodes",recommended=True),
  T("album-release-year","Album release years","Entertainment","medium","haswbstatement:P31=Q482994|P31=Q208569","P577","year",
    year_prompt('In what year was the album “{label}” released?'),year_explain('The earliest recorded release year for “{label}” is {value}.'),recommended=True),
  T("song-release-year","Song release years","Entertainment","medium","haswbstatement:P31=Q7366","P577","year",
    year_prompt('In what year was the song “{label}” released?'),year_explain('The earliest recorded release year for “{label}” is {value}.'),recommended=True),
  T("book-publication-year","Book publication years","Entertainment","medium","haswbstatement:P31=Q571","P577","year",
    year_prompt('In what year was “{label}” first published?'),year_explain('The earliest recorded publication year for “{label}” is {value}.')),
  T("book-page-count","Book page counts","Entertainment","hard","haswbstatement:P31=Q571","P1104","quantity",
    metric_prompt('Approximately how many pages are in “{label}”?'),metric_explain('Wikidata records about {value} pages for “{label}”.'),unit="pages"),
  T("actor-birth-year","Actor birth years","Entertainment","medium","haswbstatement:P31=Q5 haswbstatement:P106=Q33999","P569","year",
    year_prompt('In what year was actor {label} born?'),year_explain('Wikidata records {label}’s birth year as {value}.')),
  T("musician-birth-year","Musician birth years","Entertainment","medium","haswbstatement:P31=Q5 haswbstatement:P106=Q639669","P569","year",
    year_prompt('In what year was musician {label} born?'),year_explain('Wikidata records {label}’s birth year as {value}.')),

  # TECHNOLOGY
  T("video-game-release-year","Video game release years","Technology","medium","haswbstatement:P31=Q7889","P577","year",
    year_prompt('In what year was the video game “{label}” first released?'),year_explain('The earliest recorded release year for “{label}” is {value}.'),recommended=True),
  T("programming-language-year","Programming language inception years","Technology","hard","haswbstatement:P31=Q9143","P571","year",
    year_prompt('Around what year was the programming language {label} introduced?'),year_explain('Wikidata records {label}’s inception year as {value}.'),recommended=True),
  T("operating-system-release","Operating system release years","Technology","medium","haswbstatement:P31=Q9135","P577","year",
    year_prompt('In what year was the operating system {label} first released?'),year_explain('The earliest recorded release year for {label} is {value}.')),
  T("website-inception","Website launch years","Technology","medium","haswbstatement:P31=Q35127","P571","year",
    year_prompt('In what year was the website {label} established?'),year_explain('Wikidata records {label}’s inception year as {value}.')),
  T("software-release","Software release years","Technology","hard","haswbstatement:P31=Q7397","P577","year",
    year_prompt('In what year was {label} first released?'),year_explain('The earliest recorded release year for {label} is {value}.')),
  T("aircraft-first-flight","Aircraft first-flight years","Technology","hard","haswbstatement:P31=Q11436","P606","year",
    year_prompt('In what year did {label} make its first flight?'),year_explain('Wikidata records {label}’s first-flight year as {value}.'),recommended=True),
  T("aircraft-wingspan","Aircraft wingspans","Technology","hard","haswbstatement:P31=Q11436","P2050","quantity",
    metric_prompt('What is the approximate wingspan of {label}? (answer in {unit})'),metric_explain('Wikidata records a wingspan of about {value} {unit} for {label}.')),
  T("aircraft-length","Aircraft lengths","Technology","hard","haswbstatement:P31=Q11436","P2043","quantity",
    metric_prompt('Approximately how long is {label}? (answer in {unit})'),metric_explain('Wikidata records a length of about {value} {unit} for {label}.')),

  # BUSINESS
  T("business-inception-year","Company founding years","Business","medium","haswbstatement:P31=Q4830453","P571","year",
    year_prompt('In what year was {label} founded or established?'),year_explain('Wikidata records {label}’s inception year as {value}.'),recommended=True),
  T("business-employees","Company employee counts","Business","hard","haswbstatement:P31=Q4830453","P1128","quantity",
    metric_prompt('Approximately how many employees does {label} have?'),metric_explain('Wikidata records approximately {value} employees for {label}.'),unit="employees",recommended=True),
  T("university-inception","University founding years","Business","hard","haswbstatement:P31=Q3918","P571","year",
    year_prompt('In what year was {label} founded?'),year_explain('Wikidata records {label}’s inception year as {value}.')),
  T("museum-inception","Museum founding years","Business","hard","haswbstatement:P31=Q33506","P571","year",
    year_prompt('In what year was {label} established?'),year_explain('Wikidata records {label}’s inception year as {value}.')),
  T("hospital-inception","Hospital founding years","Business","hard","haswbstatement:P31=Q16917","P571","year",
    year_prompt('In what year was {label} established?'),year_explain('Wikidata records {label}’s inception year as {value}.')),
  T("newspaper-inception","Newspaper founding years","Business","hard","haswbstatement:P31=Q11032","P571","year",
    year_prompt('In what year was the newspaper “{label}” established?'),year_explain('Wikidata records “{label}” as beginning in {value}.')),

  # HISTORY
  T("person-birth-year","Notable people birth years","History","medium","haswbstatement:P31=Q5","P569","year",
    year_prompt('In what year was {label} born?'),year_explain('Wikidata records {label}’s birth year as {value}.'),recommended=True),
  T("person-death-year","Notable people death years","History","medium","haswbstatement:P31=Q5","P570","year",
    year_prompt('In what year did {label} die?'),year_explain('Wikidata records {label}’s death year as {value}.')),
  T("scientist-birth-year","Scientists’ birth years","History","hard","haswbstatement:P31=Q5 haswbstatement:P106=Q901","P569","year",
    year_prompt('In what year was scientist {label} born?'),year_explain('Wikidata records {label}’s birth year as {value}.')),
  T("battle-year","Battle dates","History","hard","haswbstatement:P31=Q178561","P585","year",
    year_prompt('In what year did the Battle of {label} occur?'),year_explain('Wikidata records the event year as {value}.'),scan=10),

  # GEOGRAPHY
  T("city-population","City populations","Geography","medium","haswbstatement:P31=Q515","P1082","quantity",
    metric_prompt('Approximately how many people live in {label}?'),metric_explain('Wikidata records a population of about {value} for {label}.'),unit="people",recommended=True),
  T("city-elevation","City elevations","Geography","hard","haswbstatement:P31=Q515","P2044","quantity",
    metric_prompt('Approximately how high above sea level is {label}? (answer in {unit})'),metric_explain('Wikidata records an elevation of about {value} {unit} for {label}.')),
  T("country-population","Country populations","Geography","medium","haswbstatement:P31=Q6256","P1082","quantity",
    metric_prompt('Approximately what is the population of {label}?'),metric_explain('Wikidata records a population of about {value} for {label}.'),unit="people",recommended=True),
  T("country-area","Country land areas","Geography","medium","haswbstatement:P31=Q6256","P2046","quantity",
    metric_prompt('Approximately what area does {label} cover? (answer in {unit})'),metric_explain('Wikidata records an area of about {value} {unit} for {label}.')),
  T("island-area","Island areas","Geography","hard","haswbstatement:P31=Q23442","P2046","quantity",
    metric_prompt('Approximately what area does {label} cover? (answer in {unit})'),metric_explain('Wikidata records an area of about {value} {unit} for {label}.')),
  T("lake-area","Lake areas","Geography","hard","haswbstatement:P31=Q23397","P2046","quantity",
    metric_prompt('Approximately what is the surface area of {label}? (answer in {unit})'),metric_explain('Wikidata records an area of about {value} {unit} for {label}.')),
  T("river-length","River lengths","Geography","medium","haswbstatement:P31=Q4022","P2043","quantity",
    metric_prompt('Approximately how long is {label}? (answer in {unit})'),metric_explain('Wikidata records a length of about {value} {unit} for {label}.'),recommended=True),
  T("mountain-elevation","Mountain elevations","Geography","medium","haswbstatement:P31=Q8502","P2044","quantity",
    metric_prompt('Approximately how high above sea level is {label}? (answer in {unit})'),metric_explain('Wikidata records an elevation of about {value} {unit} for {label}.'),recommended=True),
  T("building-height","Building heights","Geography","hard","haswbstatement:P31=Q41176","P2048","quantity",
    metric_prompt('Approximately how tall is {label}? (answer in {unit})'),metric_explain('Wikidata records a height of about {value} {unit} for {label}.')),
  T("skyscraper-height","Skyscraper heights","Geography","medium","haswbstatement:P31=Q11303","P2048","quantity",
    metric_prompt('Approximately how tall is {label}? (answer in {unit})'),metric_explain('Wikidata records a height of about {value} {unit} for {label}.'),recommended=True),
  T("bridge-length","Bridge lengths","Geography","hard","haswbstatement:P31=Q12280","P2043","quantity",
    metric_prompt('Approximately how long is {label}? (answer in {unit})'),metric_explain('Wikidata records a length of about {value} {unit} for {label}.')),
  T("airport-elevation","Airport elevations","Geography","hard","haswbstatement:P31=Q1248784","P2044","quantity",
    metric_prompt('Approximately how high above sea level is {label}? (answer in {unit})'),metric_explain('Wikidata records an elevation of about {value} {unit} for {label}.')),

  # SPORTS
  T("stadium-capacity","Stadium capacities","Sports","medium","haswbstatement:P31=Q483110","P1083","quantity",
    metric_prompt('Approximately how many people can {label} hold?'),metric_explain('Wikidata records a maximum capacity of about {value} for {label}.'),unit="people",recommended=True),
  T("sports-club-inception","Sports club founding years","Sports","medium","haswbstatement:P31=Q847017","P571","year",
    year_prompt('In what year was {label} founded?'),year_explain('Wikidata records {label}’s inception year as {value}.')),
  T("football-club-inception","Football club founding years","Sports","medium","haswbstatement:P31=Q476028","P571","year",
    year_prompt('In what year was {label} founded?'),year_explain('Wikidata records {label}’s inception year as {value}.'),recommended=True),
  T("athlete-birth-year","Athlete birth years","Sports","medium","haswbstatement:P31=Q5 haswbstatement:P106=Q2066131","P569","year",
    year_prompt('In what year was athlete {label} born?'),year_explain('Wikidata records {label}’s birth year as {value}.')),

  # SCIENCE
  T("element-atomic-number","Chemical element atomic numbers","Science","easy","haswbstatement:P31=Q11344","P1086","quantity",
    metric_prompt('What is the atomic number of {label}?'),metric_explain('The atomic number of {label} is {value}.'),unit="",recommended=True,scan=4),
  T("element-discovery-year","Chemical element discovery years","Science","hard","haswbstatement:P31=Q11344","P575","year",
    year_prompt('Around what year was {label} discovered?'),year_explain('Wikidata records {label}’s discovery year as {value}.'),scan=6),
  T("element-melting-point","Chemical element melting points","Science","hard","haswbstatement:P31=Q11344","P2101","quantity",
    metric_prompt('Approximately what is the melting point of {label}? (answer in {unit})'),metric_explain('Wikidata records a melting point of about {value} {unit} for {label}.'),scan=6),
  T("element-boiling-point","Chemical element boiling points","Science","hard","haswbstatement:P31=Q11344","P2102","quantity",
    metric_prompt('Approximately what is the boiling point of {label}? (answer in {unit})'),metric_explain('Wikidata records a boiling point of about {value} {unit} for {label}.'),scan=6),

  # SPACE
  T("planet-orbital-period","Planet orbital periods","Space","medium","haswbstatement:P31=Q634","P2146","quantity",
    metric_prompt('Approximately how long is {label}’s orbital period? (answer in {unit})'),metric_explain('Wikidata records an orbital period of about {value} {unit} for {label}.'),recommended=True,scan=5),
  T("planet-diameter","Planet diameters","Space","medium","haswbstatement:P31=Q634","P2386","quantity",
    metric_prompt('Approximately what is the diameter of {label}? (answer in {unit})'),metric_explain('Wikidata records a diameter of about {value} {unit} for {label}.'),scan=5),
  T("exoplanet-discovery-year","Exoplanet discovery years","Space","hard","haswbstatement:P31=Q44559","P575","year",
    year_prompt('In what year was the exoplanet {label} discovered?'),year_explain('Wikidata records {label}’s discovery year as {value}.'),scan=8),
  T("exoplanet-orbital-period","Exoplanet orbital periods","Space","hard","haswbstatement:P31=Q44559","P2146","quantity",
    metric_prompt('Approximately how long is {label}’s orbital period? (answer in {unit})'),metric_explain('Wikidata records an orbital period of about {value} {unit} for {label}.'),scan=8),

  # ANIMALS — sparse on Wikidata, so these are opt-in and aggressively bounded.
  T("animal-life-expectancy","Animal life expectancies","Animals","hard","haswbstatement:P31=Q16521","P2250","quantity",
    metric_prompt('Approximately what is the life expectancy of {label}? (answer in {unit})'),metric_explain('Wikidata records a life expectancy of about {value} {unit} for {label}.'),scan=18,note="Sparse data"),
  T("animal-gestation","Animal gestation periods","Animals","hard","haswbstatement:P31=Q16521","P3063","quantity",
    metric_prompt('Approximately how long is the gestation period of {label}? (answer in {unit})'),metric_explain('Wikidata records a gestation period of about {value} {unit} for {label}.'),scan=18,note="Sparse data"),
  T("animal-wingspan","Animal wingspans","Animals","hard","haswbstatement:P31=Q16521","P2050","quantity",
    metric_prompt('Approximately what is the wingspan of {label}? (answer in {unit})'),metric_explain('Wikidata records a wingspan of about {value} {unit} for {label}.'),scan=18,note="Sparse data"),
  T("animal-litter-size","Animal litter sizes","Animals","hard","haswbstatement:P31=Q16521","P7725","quantity",
    metric_prompt('About how many young are typically in a litter for {label}?'),metric_explain('Wikidata records a litter size of about {value} for {label}.'),unit="young",scan=18,note="Sparse data"),
  T("animal-incubation","Animal egg incubation periods","Animals","hard","haswbstatement:P31=Q16521","P7770","quantity",
    metric_prompt('Approximately how long is the egg incubation period for {label}? (answer in {unit})'),metric_explain('Wikidata records an incubation period of about {value} {unit} for {label}.'),scan=18,note="Sparse data")
]

TEMPLATE_MAP={x["id"]:x for x in TEMPLATES}

def format_number(v):
    try:
        n=float(v)
        if abs(n)>=1_000_000:return f"{n:,.0f}"
        return f"{n:,.4f}".rstrip("0").rstrip(".")
    except:return str(v)

def api_json(params,timeout=REQUEST_TIMEOUT,attempts=REQUEST_ATTEMPTS):
    params=dict(params);params.setdefault("format","json");params.setdefault("formatversion","2")
    url=API+"?"+urlencode(params)
    last=None
    for attempt in range(attempts):
        try:
            req=Request(url,headers={"Accept":"application/json","User-Agent":USER_AGENT})
            with urlopen(req,timeout=timeout) as r:
                return json.loads(r.read().decode("utf-8","replace"))
        except HTTPError as e:
            last=e
            if e.code in (429,500,502,503,504) and attempt+1<attempts:
                time.sleep(0.8*(2**attempt));continue
            raise
        except (URLError,TimeoutError,OSError,ValueError) as e:
            last=e
            if attempt+1<attempts:
                time.sleep(0.6*(2**attempt));continue
            raise
    raise last

def search_qids(search,offset,limit=SEARCH_PAGE):
    body=api_json({"action":"query","list":"search","srsearch":search,"srnamespace":"0","srlimit":str(min(50,max(1,limit))),"sroffset":str(max(0,offset))})
    rows=(body.get("query") or {}).get("search") or []
    qids=[str(x.get("title") or "") for x in rows if re.fullmatch(r"Q\d+",str(x.get("title") or ""))]
    nxt=(body.get("continue") or {}).get("sroffset")
    return qids,(int(nxt) if nxt is not None else None)

def fetch_entities(qids):
    if not qids:return {}
    out={}
    for i in range(0,len(qids),50):
        ids=qids[i:i+50]
        body=api_json({"action":"wbgetentities","ids":"|".join(ids),"props":"labels|claims|sitelinks","languages":"en","languagefallback":"1","sitefilter":"enwiki"})
        out.update(body.get("entities") or {})
    return out

def fetch_unit_labels(qids):
    missing=[q for q in sorted(set(qids)) if q and q not in UNIT_CACHE]
    for i in range(0,len(missing),50):
        ids=missing[i:i+50]
        try:
            body=api_json({"action":"wbgetentities","ids":"|".join(ids),"props":"labels","languages":"en","languagefallback":"1"})
            for qid,ent in (body.get("entities") or {}).items():
                label=((ent.get("labels") or {}).get("en") or {}).get("value")
                if label:UNIT_CACHE[qid]=str(label)
        except Exception:
            pass
    return {q:UNIT_CACHE.get(q,q) for q in qids}

def label_of(ent,qid):
    label=((ent.get("labels") or {}).get("en") or {}).get("value")
    return str(label or qid).strip()

def qualifier_year(statement):
    qs=statement.get("qualifiers") or {}
    for prop in ("P585","P580","P577","P571"):
        vals=qs.get(prop) or []
        for s in vals:
            val=(s.get("datavalue") or {}).get("value")
            if isinstance(val,dict) and val.get("time"):
                m=re.match(r"^([+-]?\d+)-",str(val["time"]))
                if m:
                    try:return int(m.group(1))
                    except:pass
    return -999999

def claim_candidates(ent,prop):
    claims=(ent.get("claims") or {}).get(prop) or []
    claims=[x for x in claims if x.get("rank")!="deprecated" and ((x.get("mainsnak") or {}).get("snaktype")=="value")]
    return sorted(claims,key=lambda s:(2 if s.get("rank")=="preferred" else 1,qualifier_year(s)),reverse=True)

def parse_time(statement):
    val=((statement.get("mainsnak") or {}).get("datavalue") or {}).get("value")
    if not isinstance(val,dict):return None
    m=re.match(r"^([+-]?\d+)-",str(val.get("time") or ""))
    if not m:return None
    try:return int(m.group(1))
    except:return None

def parse_quantity(statement):
    val=((statement.get("mainsnak") or {}).get("datavalue") or {}).get("value")
    if isinstance(val,dict) and "amount" in val:
        try:amount=float(str(val.get("amount")).replace("+",""))
        except:return None,None
        unit=str(val.get("unit") or "1")
        m=re.search(r"/(Q\d+)$",unit)
        return amount,(m.group(1) if m else ("1" if unit=="1" else None))
    if isinstance(val,(int,float)):return float(val),"1"
    try:return float(val),"1"
    except:return None,None

def choose_value(template,ent):
    claims=claim_candidates(ent,template["prop"])
    if not claims:return None,None
    if template["kind"]=="year":
        years=[parse_time(c) for c in claims];years=[y for y in years if y is not None]
        if not years:return None,None
        # Release/inception/discovery questions are most useful with the earliest recorded date.
        v=min(years)
        if v<1 or v>3000:return None,None
        return v,"year"
    for c in claims:
        v,u=parse_quantity(c)
        if v is None:continue
        if template.get("min") is not None and v<float(template["min"]):continue
        if template.get("max") is not None and v>float(template["max"]):continue
        return v,u
    return None,None

def make_question(template,qid,ent,value,unit_label):
    label=label_of(ent,qid)
    unit=template.get("unit") if template.get("unit") is not None else unit_label
    unit=str(unit or "")
    canonical=f"wikidata:{template['id']}:{qid}"
    return {
      "id":canonical,"canonical_key":canonical,"category":template["category"],"difficulty":template["difficulty"],
      "question_type":"numeric","prompt":template["prompt"](label,value,unit),"context":None,"unit":unit,
      "options":None,"answer_numeric":value,"answer_text":None,"correct_option":None,
      "explanation":template["explanation"](label,value,unit),"source_url":f"https://www.wikidata.org/wiki/{qid}",
      "source_type":"wikidata","source_entity_id":qid,"media_query":label
    }

def fetch_template(template_id,limit,offset,progress=None,cancel=None):
    template=TEMPLATE_MAP[template_id]
    target=max(1,int(limit));cursor=max(0,int(offset));out=[];seen=set();scanned=0
    max_scan=max(150,target*int(template.get("scan_multiplier") or 7))
    started=time.monotonic();exhausted=False
    while len(out)<target and scanned<max_scan and not exhausted:
        if cancel and cancel():break
        if time.monotonic()-started>MAX_TEMPLATE_SECONDS:
            raise TimeoutError(f"Template exceeded {MAX_TEMPLATE_SECONDS}s safety limit after scanning {scanned} Wikidata items")
        want=min(SEARCH_PAGE,max_scan-scanned)
        if progress:progress({"stage":"search","template":template_id,"name":template["name"],"count":len(out),"scanned":scanned,"offset":cursor,"message":f"Searching {template['name']} · {len(out)}/{target} ready"})
        qids,next_cursor=search_qids(template["search"],cursor,want)
        if not qids:
            exhausted=True;break
        entities=fetch_entities(qids)
        unit_ids=set();pending=[]
        for qid in qids:
            if cancel and cancel():break
            ent=entities.get(qid) or {}
            # English-Wikipedia coverage is our quality gate: it removes most obscure/placeholder entities.
            if "enwiki" not in (ent.get("sitelinks") or {}):continue
            value,unit_qid=choose_value(template,ent)
            if value is None:continue
            canonical=f"wikidata:{template_id}:{qid}"
            if canonical in seen:continue
            seen.add(canonical);pending.append((qid,ent,value,unit_qid))
            if unit_qid and unit_qid!="1":unit_ids.add(unit_qid)
        labels=fetch_unit_labels(unit_ids) if unit_ids else {}
        for qid,ent,value,unit_qid in pending:
            unit_label=labels.get(unit_qid,UNIT_CACHE.get(unit_qid,"")) if unit_qid else ""
            out.append(make_question(template,qid,ent,value,unit_label))
            if len(out)>=target:break
        scanned+=len(qids)
        if progress:progress({"stage":"scan","template":template_id,"name":template["name"],"count":len(out),"scanned":scanned,"offset":cursor,"message":f"{template['name']}: {len(out)}/{target} usable from {scanned} scanned"})
        if next_cursor is None or next_cursor<=cursor:exhausted=True
        else:cursor=next_cursor
    return out,cursor,scanned

def acquire(selected,per_template,offsets,progress=None,cancel=None,max_workers=3):
    selected=[x for x in selected if x in TEMPLATE_MAP]
    jobs=[(tid,max(0,int(offsets.get(tid,0)))) for tid in selected]
    results=[];errors=[];new_offsets=dict(offsets);lock=threading.Lock();completed=0

    def emit(done,total,event):
        if progress:progress(done,total,event)

    def one(job):
        tid,offset=job;tmpl=TEMPLATE_MAP[tid];t0=time.monotonic()
        emit(0,len(jobs),{"stage":"start","template":tid,"name":tmpl["name"],"count":0,"scanned":0,"offset":offset,"message":f"Starting {tmpl['name']}"})
        rows,next_offset,scanned=fetch_template(tid,per_template,offset,
            progress=lambda ev: emit(-1,len(jobs),ev),cancel=cancel)
        return tid,offset,rows,next_offset,scanned,time.monotonic()-t0

    with ThreadPoolExecutor(max_workers=max(1,min(int(max_workers or 3),4,len(jobs) or 1))) as ex:
        futures={ex.submit(one,j):j for j in jobs}
        for fut in as_completed(futures):
            tid,offset=futures[fut];tmpl=TEMPLATE_MAP[tid]
            try:
                _,_,rows,next_offset,scanned,duration=fut.result()
                results.extend(rows);new_offsets[tid]=max(offset+1,int(next_offset or offset+per_template))
                event={"stage":"done","template":tid,"name":tmpl["name"],"ok":True,"count":len(rows),"scanned":scanned,"offset":offset,"seconds":round(duration,1),"message":f"{tmpl['name']}: {len(rows)} acquired from {scanned} scanned"}
            except Exception as e:
                errors.append({"template":tid,"name":tmpl["name"],"error":str(e)})
                event={"stage":"error","template":tid,"name":tmpl["name"],"ok":False,"count":0,"offset":offset,"error":str(e),"message":f"{tmpl['name']} failed: {e}"}
            with lock:completed+=1;done=completed
            emit(done,len(jobs),event)
            if cancel and cancel():
                for f in futures:f.cancel()
                break
    dedup={q["canonical_key"]:q for q in results}
    return list(dedup.values()),new_offsets,errors
