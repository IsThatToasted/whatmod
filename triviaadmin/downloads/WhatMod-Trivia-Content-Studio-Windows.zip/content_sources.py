import json, re, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urlencode
from urllib.request import Request, urlopen

WDQS="https://query.wikidata.org/sparql"
USER_AGENT="WhatModTriviaContentStudio/1.0 (local admin utility; https://whatmod.com/trivia/)"

TEMPLATES=[
  {"id":"film-release-year","name":"Film release years","category":"Entertainment","difficulty":"medium","unit":"year","kind":"year","min":-5000,"max":3000,
   "query":lambda limit,offset:f'''SELECT ?item ?itemLabel (MIN(?date) AS ?value) WHERE {{
  ?item wdt:P31 wd:Q11424; wdt:P577 ?date; wikibase:sitelinks ?sitelinks.
  FILTER(?sitelinks >= 8)
  SERVICE wikibase:label {{ bd:serviceParam wikibase:language "en". }}
}} GROUP BY ?item ?itemLabel ORDER BY ?item LIMIT {limit} OFFSET {offset}''',
   "prompt":lambda label:f'In what year was the film “{label}” first released?',
   "explanation":lambda label,value:f'The earliest release date recorded for “{label}” corresponds to {value}.'},
  {"id":"video-game-release-year","name":"Video game release years","category":"Technology","difficulty":"medium","unit":"year","kind":"year","min":-5000,"max":3000,
   "query":lambda limit,offset:f'''SELECT ?item ?itemLabel (MIN(?date) AS ?value) WHERE {{
  ?item wdt:P31 wd:Q7889; wdt:P577 ?date; wikibase:sitelinks ?sitelinks.
  FILTER(?sitelinks >= 5)
  SERVICE wikibase:label {{ bd:serviceParam wikibase:language "en". }}
}} GROUP BY ?item ?itemLabel ORDER BY ?item LIMIT {limit} OFFSET {offset}''',
   "prompt":lambda label:f'In what year was the video game “{label}” first released?',
   "explanation":lambda label,value:f'The earliest release date recorded for “{label}” corresponds to {value}.'},
  {"id":"person-birth-year","name":"Notable people birth years","category":"History","difficulty":"hard","unit":"year","kind":"year","min":-5000,"max":3000,
   "query":lambda limit,offset:f'''SELECT ?item ?itemLabel (MIN(?date) AS ?value) WHERE {{
  ?item wdt:P31 wd:Q5; wdt:P569 ?date; wikibase:sitelinks ?sitelinks.
  FILTER(?sitelinks >= 25)
  SERVICE wikibase:label {{ bd:serviceParam wikibase:language "en". }}
}} GROUP BY ?item ?itemLabel ORDER BY ?item LIMIT {limit} OFFSET {offset}''',
   "prompt":lambda label:f'In what year was {label} born?',
   "explanation":lambda label,value:f'Wikidata records {label}’s birth year as {value}.'},
  {"id":"business-inception-year","name":"Company founding years","category":"Business","difficulty":"hard","unit":"year","kind":"year","min":-5000,"max":3000,
   "query":lambda limit,offset:f'''SELECT ?item ?itemLabel (MIN(?date) AS ?value) WHERE {{
  ?item wdt:P571 ?date; wikibase:sitelinks ?sitelinks.
  ?item wdt:P31 ?type. VALUES ?type {{ wd:Q4830453 wd:Q783794 wd:Q43229 }}
  FILTER(?sitelinks >= 8)
  SERVICE wikibase:label {{ bd:serviceParam wikibase:language "en". }}
}} GROUP BY ?item ?itemLabel ORDER BY ?item LIMIT {limit} OFFSET {offset}''',
   "prompt":lambda label:f'In what year was {label} founded or established?',
   "explanation":lambda label,value:f'Wikidata records {label}’s inception year as {value}.'},
  {"id":"mountain-elevation","name":"Mountain elevations","category":"Geography","difficulty":"medium","unit":"m","kind":"numeric","min":-500,"max":10000,
   "query":lambda limit,offset:f'''SELECT ?item ?itemLabel (SAMPLE(?amount) AS ?value) WHERE {{
  ?item wdt:P31 wd:Q8502; p:P2044 ?statement; wikibase:sitelinks ?sitelinks.
  ?statement psv:P2044 ?valueNode. ?valueNode wikibase:quantityAmount ?amount; wikibase:quantityUnit wd:Q11573.
  FILTER(?sitelinks >= 4)
  SERVICE wikibase:label {{ bd:serviceParam wikibase:language "en". }}
}} GROUP BY ?item ?itemLabel ORDER BY ?item LIMIT {limit} OFFSET {offset}''',
   "prompt":lambda label:f'Approximately how many meters above sea level is {label}?',
   "explanation":lambda label,value:f'Wikidata records an elevation of about {format_number(value)} meters for {label}.'},
  {"id":"building-height","name":"Building heights","category":"Geography","difficulty":"hard","unit":"m","kind":"numeric","min":2,"max":1200,
   "query":lambda limit,offset:f'''SELECT ?item ?itemLabel (SAMPLE(?amount) AS ?value) WHERE {{
  ?item wdt:P31 wd:Q41176; p:P2048 ?statement; wikibase:sitelinks ?sitelinks.
  ?statement psv:P2048 ?valueNode. ?valueNode wikibase:quantityAmount ?amount; wikibase:quantityUnit wd:Q11573.
  FILTER(?sitelinks >= 5)
  SERVICE wikibase:label {{ bd:serviceParam wikibase:language "en". }}
}} GROUP BY ?item ?itemLabel ORDER BY ?item LIMIT {limit} OFFSET {offset}''',
   "prompt":lambda label:f'Approximately how tall is {label}, in meters?',
   "explanation":lambda label,value:f'Wikidata records a height of about {format_number(value)} meters for {label}.'}
]

TEMPLATE_MAP={x["id"]:x for x in TEMPLATES}

def format_number(v):
    try:return f"{float(v):,.2f}".rstrip("0").rstrip(".")
    except:return str(v)

def qid(uri):
    m=re.search(r"/(Q\d+)$",str(uri or ""));return m.group(1) if m else None

def parse_value(template,raw):
    if template["kind"]=="year":
        m=re.match(r"^([+-]?\d{1,6})-",str(raw or ""))
        if not m:return None
        v=int(m.group(1))
    else:
        try:v=float(raw)
        except:return None
    if v<template["min"] or v>template["max"]:return None
    return v

def wdqs(query,timeout=45,attempts=3):
    url=WDQS+"?"+urlencode({"format":"json","query":query})
    last=None
    for attempt in range(attempts):
        try:
            req=Request(url,headers={"Accept":"application/sparql-results+json","User-Agent":USER_AGENT})
            with urlopen(req,timeout=timeout) as r:
                return (json.loads(r.read().decode("utf-8","replace")).get("results") or {}).get("bindings") or []
        except Exception as e:
            last=e
            if attempt+1<attempts:time.sleep(min(6,1.2*(2**attempt)))
    raise last

def fetch_template(template_id,limit,offset):
    template=TEMPLATE_MAP[template_id]
    rows=wdqs(template["query"](limit,offset))
    out=[];seen=set()
    for row in rows:
        entity=qid((row.get("item") or {}).get("value"));label=str((row.get("itemLabel") or {}).get("value") or "").strip()
        value=parse_value(template,(row.get("value") or {}).get("value"))
        if not entity or not label or value is None:continue
        canonical=f"wikidata:{template_id}:{entity}"
        if canonical in seen:continue
        seen.add(canonical)
        out.append({
          "id":canonical,"canonical_key":canonical,"category":template["category"],"difficulty":template["difficulty"],
          "question_type":"numeric","prompt":template["prompt"](label),"context":None,"unit":template["unit"],"options":None,
          "answer_numeric":value,"answer_text":None,"correct_option":None,"explanation":template["explanation"](label,value),
          "source_url":f"https://www.wikidata.org/wiki/{entity}","source_type":"wikidata","source_entity_id":entity,
          "media_query":label
        })
    return out

def acquire(selected,per_template,offsets,progress=None,cancel=None,max_workers=2):
    selected=[x for x in selected if x in TEMPLATE_MAP]
    jobs=[]
    for tid in selected:
        jobs.append((tid,max(0,int(offsets.get(tid,0)))))
    results=[];errors=[];new_offsets=dict(offsets)
    def one(job):
        tid,offset=job
        rows=fetch_template(tid,per_template,offset)
        return tid,offset,rows
    with ThreadPoolExecutor(max_workers=max(1,min(max_workers,2,len(jobs) or 1))) as ex:
        futures={ex.submit(one,j):j for j in jobs}
        done=0
        for fut in as_completed(futures):
            if cancel and cancel():break
            tid,offset=futures[fut]
            try:
                _,_,rows=fut.result();results.extend(rows);new_offsets[tid]=offset+per_template
                msg={"template":tid,"ok":True,"count":len(rows),"offset":offset}
            except Exception as e:
                errors.append({"template":tid,"error":str(e)});msg={"template":tid,"ok":False,"count":0,"offset":offset,"error":str(e)}
            done+=1
            if progress:progress(done,len(jobs),msg)
    # Canonical de-dupe across selected templates.
    dedup={q["canonical_key"]:q for q in results}
    return list(dedup.values()),new_offsets,errors
