#!/usr/bin/env python3
import json, re, time, threading, webbrowser, uuid, html, socket, os
from concurrent.futures import ThreadPoolExecutor, as_completed
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlencode, urlparse
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from content_sources import TEMPLATES, acquire as acquire_questions

HOST="127.0.0.1"
PORT=8767
ROOT=Path(__file__).resolve().parent
WEB=ROOT/"web"
USER_AGENT="WhatModTriviaContentStudio/2.0 (local admin utility)"
COMMONS_API="https://commons.wikimedia.org/w/api.php"
WIKIPEDIA_API="https://en.wikipedia.org/w/api.php"
OPENVERSE_API="https://api.openverse.org/v1/images/"
MAX_QUESTION_WORKERS=8

CONTENT_STATE_FILE=ROOT/"content_studio_state.json"

def load_local_state():
    try:
        body=json.loads(CONTENT_STATE_FILE.read_text(encoding="utf-8"))
        return body if isinstance(body,dict) else {}
    except Exception:
        return {}

def save_local_state(data):
    tmp=CONTENT_STATE_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data,indent=2),encoding="utf-8")
    tmp.replace(CONTENT_STATE_FILE)

LOCAL_STATE=load_local_state()
LOCAL_STATE.setdefault("offsets",{})
ACQUIRE={
  "running":False,"cancel":False,"total_templates":0,"completed_templates":0,"questions":[],"errors":[],
  "events":[],"started_at":None,"finished_at":None,"per_template":100,"selected":[],"offset_mode":"continue"
}

STATE_LOCK=threading.RLock()
STATE={
  "running":False,"cancel":False,"total":0,"completed":0,"resolved":0,"missing":0,
  "started_at":None,"finished_at":None,"items":[],"job":None,"error":None,
  "concurrency":4,"probe_count":4
}

def clean(v):
    return re.sub(r"\s+"," ",html.unescape(re.sub(r"<[^>]*>"," ",str(v or "")))).strip()

def safe_http(v):
    try:
        s=str(v or "").strip()
        if not s: return None
        u=urlparse(s)
        if u.scheme not in ("http","https"): return None
        if u.scheme=="http":
            s="https://"+u.netloc+u.path+(("?"+u.query) if u.query else "")
        return s
    except Exception:
        return None

def fetch_json(url, timeout=18, attempts=3):
    last=None
    for attempt in range(attempts):
        try:
            req=Request(url,headers={"User-Agent":USER_AGENT,"Accept":"application/json"})
            with urlopen(req,timeout=timeout) as r:
                return json.loads(r.read().decode("utf-8","replace"))
        except HTTPError as e:
            last=e
            if e.code in (429,500,502,503,504):
                time.sleep(min(4,0.6*(2**attempt)))
                continue
            raise
        except Exception as e:
            last=e
            if attempt+1<attempts:
                time.sleep(min(3,0.45*(2**attempt)))
                continue
            raise
    raise last

def tokens(s):
    return {x for x in re.findall(r"[a-z0-9]+",str(s or "").lower()) if len(x)>1}

def overlap_score(query,title):
    q=tokens(query); t=tokens(title)
    if not q or not t:return 0
    return round(42*len(q&t)/max(1,len(q)))

def aspect_bonus(w,h):
    try:
        w=float(w or 0);h=float(h or 0)
        if w<=0 or h<=0:return 0
        r=w/h
        if 1.15<=r<=2.0:return 14
        if .85<=r<=2.3:return 8
        return 0
    except:return 0

def size_bonus(w,h):
    try:
        m=min(float(w or 0),float(h or 0))
        if m>=900:return 10
        if m>=600:return 7
        if m>=350:return 4
        return 0
    except:return 0

def openverse_auto_eligible(license_code):
    s=str(license_code or "").lower().strip().replace("cc ","").replace(" ","-")
    return s in {"cc0","pdm","public-domain","by","by-sa"}

def ext(meta,key):
    try:return clean((meta.get(key) or {}).get("value"))
    except:return ""

def heuristic_query(q):
    mq=clean(q.get("media_query"))
    if mq:return mq
    alt=clean(q.get("image_alt"))
    if alt:return alt
    prompt=clean(q.get("prompt"))
    # Strip common estimation framing without pretending to understand every question.
    prompt=re.sub(r"^(approximately|about|roughly)\s+","",prompt,flags=re.I)
    prompt=re.sub(r"^(how many|how much|in what year did|what year did)\s+","",prompt,flags=re.I)
    prompt=re.sub(r"\?$","",prompt)
    return prompt[:140]

def search_commons(query,per_source=10):
    p={
      "action":"query","format":"json","formatversion":"2","generator":"search",
      "gsrsearch":query,"gsrnamespace":"6","gsrlimit":str(per_source),
      "prop":"imageinfo","iiprop":"url|extmetadata","iiurlwidth":"1200",
      "iiextmetadatafilter":"Artist|Credit|LicenseShortName|LicenseUrl|ImageDescription|ObjectName"
    }
    body=fetch_json(COMMONS_API+"?"+urlencode(p))
    out=[]
    for page in (body.get("query") or {}).get("pages") or []:
        info=(page.get("imageinfo") or [None])[0]
        if not info: continue
        m=info.get("extmetadata") or {}
        image=safe_http(info.get("url"));thumb=safe_http(info.get("thumburl") or info.get("url"));source=safe_http(info.get("descriptionurl"))
        if not(image and thumb and source):continue
        title=ext(m,"ObjectName") or str(page.get("title") or "").replace("File:","")
        creator=ext(m,"Artist") or ext(m,"Credit") or "Wikimedia Commons contributor"
        lic=ext(m,"LicenseShortName") or "Wikimedia Commons license"
        w=info.get("thumbwidth") or info.get("width");h=info.get("thumbheight") or info.get("height")
        out.append({
          "provider":"wikimedia","provider_key":str(page.get("pageid") or page.get("title")),
          "title":clean(title),"image_url":image,"thumbnail_url":thumb,"source_url":source,
          "creator":clean(creator),"creator_url":None,"license":clean(lic),
          "license_url":safe_http((m.get("LicenseUrl") or {}).get("value")),"width":w,"height":h,
          "score":112+overlap_score(query,title)+aspect_bonus(w,h)+size_bonus(w,h),
          "auto_eligible":True,"is_available":True,"metadata":{"commons_title":page.get("title")}
        })
    return out

def search_wikipedia_lead(query,per_source=6):
    p={"action":"query","format":"json","formatversion":"2","generator":"search","gsrsearch":query,
       "gsrnamespace":"0","gsrlimit":str(min(per_source,6)),"prop":"pageimages","piprop":"name|thumbnail","pithumbsize":"1200"}
    body=fetch_json(WIKIPEDIA_API+"?"+urlencode(p))
    leads=[]
    for page in (body.get("query") or {}).get("pages") or []:
        if page.get("pageimage"):
            leads.append({"article":page.get("title"),"file":"File:"+page["pageimage"]})
    if not leads:return []
    cp={"action":"query","format":"json","formatversion":"2","prop":"imageinfo","iiprop":"url|extmetadata","iiurlwidth":"1200",
        "iiextmetadatafilter":"Artist|Credit|LicenseShortName|LicenseUrl|ObjectName","titles":"|".join(x["file"] for x in leads)}
    cb=fetch_json(COMMONS_API+"?"+urlencode(cp))
    amap={x["file"].replace("_"," "):x["article"] for x in leads}
    out=[]
    for page in (cb.get("query") or {}).get("pages") or []:
        info=(page.get("imageinfo") or [None])[0]
        if not info:continue
        m=info.get("extmetadata") or {}
        image=safe_http(info.get("url"));thumb=safe_http(info.get("thumburl") or info.get("url"));source=safe_http(info.get("descriptionurl"))
        if not(image and thumb and source):continue
        article=amap.get(str(page.get("title") or "").replace("_"," "),query)
        title=ext(m,"ObjectName") or str(page.get("title") or "").replace("File:","")
        creator=ext(m,"Artist") or ext(m,"Credit") or "Wikimedia Commons contributor"
        lic=ext(m,"LicenseShortName") or "Wikimedia Commons license"
        w=info.get("thumbwidth") or info.get("width");h=info.get("thumbheight") or info.get("height")
        out.append({
          "provider":"wikipedia","provider_key":str(page.get("pageid") or page.get("title")),
          "title":clean(title),"image_url":image,"thumbnail_url":thumb,"source_url":source,
          "creator":clean(creator),"creator_url":None,"license":clean(lic),
          "license_url":safe_http((m.get("LicenseUrl") or {}).get("value")),"width":w,"height":h,
          "score":132+overlap_score(query,article)+aspect_bonus(w,h)+size_bonus(w,h),
          "auto_eligible":True,"is_available":True,
          "metadata":{"wikipedia_article":article,"commons_title":page.get("title")}
        })
    return out

def search_openverse(query,per_source=10):
    body=fetch_json(OPENVERSE_API+"?"+urlencode({"q":query,"page_size":str(per_source)}))
    out=[]
    for item in body.get("results") or []:
        if item.get("is_sensitive") or item.get("sensitivity"):continue
        image=safe_http(item.get("url"));thumb=safe_http(item.get("thumbnail") or item.get("url"));source=safe_http(item.get("foreign_landing_url") or item.get("detail_url"))
        if not(image and thumb and source):continue
        lic=clean(" ".join(str(x) for x in [item.get("license"),item.get("license_version")] if x))
        eligible=openverse_auto_eligible(item.get("license"))
        w=item.get("width");h=item.get("height")
        score=88+overlap_score(query,item.get("title") or "")+aspect_bonus(w,h)+size_bonus(w,h)+(10 if eligible else -35)-(50 if item.get("watermarked") else 0)
        out.append({
          "provider":"openverse","provider_key":str(item.get("id") or item.get("foreign_identifier") or item.get("url")),
          "title":clean(item.get("title") or query),"image_url":image,"thumbnail_url":thumb,"source_url":source,
          "creator":clean(item.get("creator") or "Unknown creator"),"creator_url":safe_http(item.get("creator_url")),
          "license":lic or None,"license_url":safe_http(item.get("license_url") or (item.get("meta_data") or {}).get("license_url")),
          "width":w,"height":h,"score":score,"auto_eligible":eligible,"is_available":True,
          "metadata":{"source":item.get("source"),"provider":item.get("provider"),"openverse_id":item.get("id"),"watermarked":bool(item.get("watermarked"))}
        })
    return out

def legacy_candidate(q,query):
    image=safe_http(q.get("image_url"))
    if not image:return None
    source=safe_http(q.get("image_source_url"))
    provider=q.get("media_provider") or ("wikimedia" if source and "commons.wikimedia.org" in source else "legacy")
    commons=provider=="wikimedia" or (source and "commons.wikimedia.org" in source)
    return {
      "provider":provider,"provider_key":"current:"+str(q.get("id")),"title":clean(q.get("image_alt") or query or q.get("prompt")),
      "image_url":image,"thumbnail_url":image,"source_url":source,"creator":clean(q.get("image_attribution")) or None,
      "creator_url":None,"license":clean(q.get("image_license")) or None,"license_url":safe_http(q.get("image_license_url")),
      "width":None,"height":None,"score":145 if commons else 100,
      "auto_eligible":bool(commons or openverse_auto_eligible(q.get("image_license"))),"is_available":True,"metadata":{"legacy":True}
    }

def probe(candidate):
    url=candidate.get("thumbnail_url") or candidate.get("image_url")
    if not url:return False
    try:
        req=Request(url,headers={"User-Agent":USER_AGENT,"Accept":"image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8","Range":"bytes=0-32767"})
        with urlopen(req,timeout=10) as r:
            typ=(r.headers.get("content-type") or "").lower()
            final=urlparse(r.geturl()).path.lower()
            return (200<=getattr(r,"status",200)<400) and (typ.startswith("image/") or re.search(r"\.(jpg|jpeg|png|webp|gif|svg)$",final))
    except Exception:
        return False

def resolve_one(q,probe_count=4):
    query=heuristic_query(q)
    errors=[]
    candidates=[]
    legacy=legacy_candidate(q,query)
    if legacy:candidates.append(legacy)
    with ThreadPoolExecutor(max_workers=3) as ex:
        futs={
          ex.submit(search_wikipedia_lead,query):"Wikipedia",
          ex.submit(search_commons,query):"Commons",
          ex.submit(search_openverse,query):"Openverse"
        }
        for fut,label in list(futs.items()):
            try:candidates.extend(fut.result())
            except Exception as e:errors.append(f"{label}: {e}")
    rejected={(str(x.get("provider")),str(x.get("provider_key"))) for x in (q.get("rejected_candidates") or [])}
    dedup={}
    for c in candidates:
        key=(str(c.get("provider")),str(c.get("provider_key")))
        if key in rejected:continue
        old=dedup.get(key)
        if old is None or float(c.get("score") or 0)>float(old.get("score") or 0):dedup[key]=c
    compact=sorted(dedup.values(),key=lambda x:float(x.get("score") or 0),reverse=True)[:12]
    top=compact[:max(1,min(int(probe_count or 4),8))]
    with ThreadPoolExecutor(max_workers=min(8,len(top) or 1)) as ex:
        probe_futs={ex.submit(probe,c):c for c in top}
        for fut,c in probe_futs.items():
            try:c["is_available"]=bool(fut.result())
            except:c["is_available"]=False
            if not c["is_available"]:c["score"]=float(c.get("score") or 0)-120
    for c in compact[len(top):]:
        c["is_available"]=False
    compact=sorted(compact,key=lambda x:float(x.get("score") or 0),reverse=True)
    selected=next((c for c in compact if c.get("auto_eligible") and c.get("is_available")),None)
    return {
      "id":q.get("id"),"prompt":q.get("prompt"),"query":query,
      "status":"resolved" if selected else "missing","selection_mode":"auto",
      "selected":{"provider":selected.get("provider"),"provider_key":selected.get("provider_key")} if selected else None,
      "candidates":compact,"errors":errors
    }

def acquire_cancelled():
    with STATE_LOCK:return bool(ACQUIRE["cancel"])

def acquire_progress(done,total,event):
    with STATE_LOCK:
        ACQUIRE["completed_templates"]=done
        ACQUIRE["events"].append(event)
        ACQUIRE["events"]=ACQUIRE["events"][-30:]

def run_acquisition(selected,per_template,offset_mode,custom_offset=0):
    try:
        with STATE_LOCK:
            ACQUIRE.update({"running":True,"cancel":False,"total_templates":len(selected),"completed_templates":0,"questions":[],"errors":[],"events":[],"started_at":time.time(),"finished_at":None,"per_template":per_template,"selected":selected,"offset_mode":offset_mode})
        if offset_mode=="zero":offsets={tid:0 for tid in selected}
        elif offset_mode=="custom":offsets={tid:max(0,int(custom_offset or 0)) for tid in selected}
        else:offsets={tid:int((LOCAL_STATE.get("offsets") or {}).get(tid,0) or 0) for tid in selected}
        questions,new_offsets,errors=acquire_questions(selected,per_template,offsets,progress=acquire_progress,cancel=acquire_cancelled,max_workers=2)
        with STATE_LOCK:
            ACQUIRE["questions"]=questions;ACQUIRE["errors"]=errors;ACQUIRE["running"]=False;ACQUIRE["finished_at"]=time.time()
            if not ACQUIRE["cancel"] and offset_mode=="continue":
                LOCAL_STATE["offsets"].update({k:int(v) for k,v in new_offsets.items()});save_local_state(LOCAL_STATE)
    except Exception as e:
        with STATE_LOCK:
            ACQUIRE["running"]=False;ACQUIRE["finished_at"]=time.time();ACQUIRE["errors"].append({"error":str(e)})

def acquire_status():
    with STATE_LOCK:
        return {
          "running":ACQUIRE["running"],"cancel":ACQUIRE["cancel"],"total_templates":ACQUIRE["total_templates"],
          "completed_templates":ACQUIRE["completed_templates"],"question_count":len(ACQUIRE["questions"]),
          "errors":list(ACQUIRE["errors"]),"events":list(ACQUIRE["events"]),"started_at":ACQUIRE["started_at"],
          "finished_at":ACQUIRE["finished_at"],"selected":list(ACQUIRE["selected"]),"per_template":ACQUIRE["per_template"]
        }

def template_payload():
    offsets=LOCAL_STATE.get("offsets") or {}
    return {"templates":[{"id":t["id"],"name":t["name"],"category":t["category"],"difficulty":t["difficulty"],"offset":int(offsets.get(t["id"],0) or 0)} for t in TEMPLATES]}

def content_media_job():
    with STATE_LOCK:
        questions=[dict(q) for q in ACQUIRE.get("questions") or []]
    return {"format":"whatmod-trivia-media-job","version":1,"job_id":str(uuid.uuid4()),"scope":"local-acquired","exported_at":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),"question_count":len(questions),"questions":questions}

def content_package_payload():
    with STATE_LOCK:
        questions=[dict(q) for q in ACQUIRE.get("questions") or []]
        media_items=list(STATE.get("items") or [])
    by_id={str(x.get("id")):x for x in media_items}
    packed=[]
    for q in questions:
        row=dict(q);media=by_id.get(str(q.get("id")))
        row["media"]=media if media else {"id":q.get("id"),"query":heuristic_query(q),"status":"not_resolved","selection_mode":"auto","selected":None,"candidates":[],"errors":[]}
        row.pop("id",None)
        packed.append(row)
    return {
      "format":"whatmod-trivia-content-package","version":1,"package_id":str(uuid.uuid4()),
      "generated_at":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),"question_count":len(packed),
      "media_resolved":sum(1 for q in packed if (q.get("media") or {}).get("selected")),
      "source":"WhatMod Trivia Content Studio","questions":packed
    }

def reset_state(job,concurrency,probe_count):
    with STATE_LOCK:
        STATE.update({
          "running":True,"cancel":False,"total":len(job.get("questions") or []),"completed":0,"resolved":0,"missing":0,
          "started_at":time.time(),"finished_at":None,"items":[],"job":job,"error":None,
          "concurrency":concurrency,"probe_count":probe_count
        })

def run_job(job,concurrency,probe_count):
    try:
        questions=job.get("questions") or []
        reset_state(job,concurrency,probe_count)
        with ThreadPoolExecutor(max_workers=concurrency) as ex:
            futs={ex.submit(resolve_one,q,probe_count):q for q in questions}
            for fut in as_completed(futs):
                with STATE_LOCK:
                    if STATE["cancel"]:break
                q=futs[fut]
                try:res=fut.result()
                except Exception as e:
                    res={"id":q.get("id"),"prompt":q.get("prompt"),"query":heuristic_query(q),"status":"error","selection_mode":"auto","selected":None,"candidates":[],"errors":[str(e)]}
                with STATE_LOCK:
                    STATE["items"].append(res)
                    STATE["completed"]+=1
                    if res.get("status")=="resolved":STATE["resolved"]+=1
                    else:STATE["missing"]+=1
        with STATE_LOCK:
            STATE["running"]=False;STATE["finished_at"]=time.time()
    except Exception as e:
        with STATE_LOCK:
            STATE["running"]=False;STATE["finished_at"]=time.time();STATE["error"]=str(e)

def status_payload():
    with STATE_LOCK:
        items=STATE["items"][-250:]
        elapsed=(time.time()-(STATE["started_at"] or time.time())) if STATE["started_at"] else 0
        rate=(STATE["completed"]/elapsed) if elapsed>0 else 0
        return {
          "running":STATE["running"],"cancel":STATE["cancel"],"total":STATE["total"],"completed":STATE["completed"],
          "resolved":STATE["resolved"],"missing":STATE["missing"],"error":STATE["error"],"elapsed":elapsed,
          "rate":rate,"items":items
        }

def result_payload():
    with STATE_LOCK:
        job=STATE.get("job") or {}
        items=list(STATE.get("items") or [])
        return {
          "format":"whatmod-trivia-media-results","version":1,
          "source_job_id":job.get("job_id"),"resolved_at":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),
          "question_count":len(items),
          "stats":{"resolved":sum(1 for x in items if x.get("selected")),"missing":sum(1 for x in items if not x.get("selected"))},
          "questions":items
        }

class Handler(SimpleHTTPRequestHandler):
    def translate_path(self,path):
        raw=path.split("?",1)[0]
        if raw=="/":raw="/index.html"
        return str(WEB/raw.lstrip("/"))
    def log_message(self,fmt,*args):pass
    def send_json(self,obj,status=200):
        data=json.dumps(obj).encode()
        self.send_response(status);self.send_header("Content-Type","application/json");self.send_header("Content-Length",str(len(data)));self.end_headers();self.wfile.write(data)
    def read_json(self):
        n=int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n).decode("utf-8")) if n else {}
    def do_GET(self):
        if self.path.startswith("/api/status"):return self.send_json(status_payload())
        if self.path.startswith("/api/results"):return self.send_json(result_payload())
        if self.path.startswith("/api/templates"):return self.send_json(template_payload())
        if self.path.startswith("/api/acquire/status"):return self.send_json(acquire_status())
        if self.path.startswith("/api/acquire/questions"):
            with STATE_LOCK:return self.send_json({"questions":list(ACQUIRE.get("questions") or [])[:500]})
        if self.path.startswith("/api/content/package"):return self.send_json(content_package_payload())
        return super().do_GET()
    def do_POST(self):
        try:
            body=self.read_json()
            if self.path=="/api/acquire/start":
                selected=[str(x) for x in (body.get("templates") or [])]
                allowed={t["id"] for t in TEMPLATES};selected=[x for x in selected if x in allowed]
                if not selected:return self.send_json({"error":"Select at least one question template."},400)
                with STATE_LOCK:
                    if ACQUIRE["running"]:return self.send_json({"error":"Question acquisition is already running."},409)
                per=max(5,min(250,int(body.get("per_template") or 100)))
                mode=str(body.get("offset_mode") or "continue")
                if mode not in ("continue","zero","custom"):mode="continue"
                custom=max(0,int(body.get("custom_offset") or 0))
                threading.Thread(target=run_acquisition,args=(selected,per,mode,custom),daemon=True).start()
                return self.send_json({"ok":True,"templates":len(selected),"requested":len(selected)*per})
            if self.path=="/api/acquire/cancel":
                with STATE_LOCK:ACQUIRE["cancel"]=True
                return self.send_json({"ok":True})
            if self.path=="/api/content/resolve":
                with STATE_LOCK:
                    if STATE["running"]:return self.send_json({"error":"Media resolution is already running."},409)
                    if not ACQUIRE.get("questions"):return self.send_json({"error":"Acquire questions first."},400)
                job=content_media_job()
                concurrency=max(1,min(MAX_QUESTION_WORKERS,int(body.get("concurrency") or 4)))
                probes=max(1,min(8,int(body.get("probe_count") or 4)))
                threading.Thread(target=run_job,args=(job,concurrency,probes),daemon=True).start()
                return self.send_json({"ok":True,"total":len(job.get("questions") or [])})
            if self.path=="/api/content/reset-offsets":
                LOCAL_STATE["offsets"]={};save_local_state(LOCAL_STATE)
                return self.send_json({"ok":True})
            if self.path=="/api/start":
                job=body.get("job") or {}
                if job.get("format")!="whatmod-trivia-media-job" or int(job.get("version") or 0)!=1:
                    return self.send_json({"error":"Invalid WhatMod Trivia media job file."},400)
                with STATE_LOCK:
                    if STATE["running"]:return self.send_json({"error":"A resolver job is already running."},409)
                concurrency=max(1,min(MAX_QUESTION_WORKERS,int(body.get("concurrency") or 4)))
                probes=max(1,min(8,int(body.get("probe_count") or 4)))
                threading.Thread(target=run_job,args=(job,concurrency,probes),daemon=True).start()
                return self.send_json({"ok":True,"total":len(job.get("questions") or [])})
            if self.path=="/api/cancel":
                with STATE_LOCK:STATE["cancel"]=True
                return self.send_json({"ok":True})
            if self.path=="/api/select":
                qid=str(body.get("question_id") or "");provider=str(body.get("provider") or "");key=str(body.get("provider_key") or "")
                with STATE_LOCK:
                    item=next((x for x in STATE["items"] if str(x.get("id"))==qid),None)
                    if not item:return self.send_json({"error":"Question result not found."},404)
                    cand=next((c for c in item.get("candidates") or [] if str(c.get("provider"))==provider and str(c.get("provider_key"))==key),None)
                    if not cand:return self.send_json({"error":"Candidate not found."},404)
                    item["selected"]={"provider":provider,"provider_key":key};item["selection_mode"]="manual";item["status"]="resolved"
                return self.send_json({"ok":True})
            return self.send_json({"error":"Not found"},404)
        except Exception as e:
            return self.send_json({"error":str(e)},500)

def find_port(preferred):
    for p in range(preferred,preferred+20):
        with socket.socket() as s:
            try:s.bind((HOST,p));return p
            except OSError:pass
    raise RuntimeError("No free local port found.")

if __name__=="__main__":
    port=find_port(PORT)
    server=ThreadingHTTPServer((HOST,port),Handler)
    url=f"http://{HOST}:{port}/"
    print("WhatMod Trivia Local Content Studio")
    print("Acquires questions + resolves media locally. No Supabase credentials are used.")
    print("Open:",url)
    threading.Timer(0.8,lambda:webbrowser.open(url)).start()
    try:server.serve_forever()
    except KeyboardInterrupt:pass
