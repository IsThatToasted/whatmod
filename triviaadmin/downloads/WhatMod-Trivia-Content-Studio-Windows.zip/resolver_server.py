#!/usr/bin/env python3
import json, re, time, threading, webbrowser, uuid, html, socket, os, math, base64, ctypes
from concurrent.futures import ThreadPoolExecutor, as_completed
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlencode, urlparse, parse_qs, quote
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from content_sources import TEMPLATES, acquire as acquire_questions, preview_topic, normalize_terms, topic_id_for, derive_fun_questions

HOST="127.0.0.1"
PORT=8767
STUDIO_VERSION="22.0"
STUDIO_CAPABILITIES=["category_pipeline","topic_discovery","media_resolver","content_package","fun_variants","category_catalog","live_supabase","live_questions","direct_publish","settings"]
ROOT=Path(__file__).resolve().parent
WEB=ROOT/"web"
USER_AGENT="WhatModTriviaContentStudio/3.0 (local admin utility)"
COMMONS_API="https://commons.wikimedia.org/w/api.php"
WIKIPEDIA_API="https://en.wikipedia.org/w/api.php"
OPENVERSE_API="https://api.openverse.org/v1/images/"
MAX_QUESTION_WORKERS=8

CONTENT_STATE_FILE=ROOT/"content_studio_state.json"
SETTINGS_FILE=ROOT/"content_studio_settings.json"

def load_local_state():
    try:
        body=json.loads(CONTENT_STATE_FILE.read_text(encoding="utf-8"))
        return body if isinstance(body,dict) else {}
    except Exception:
        return {}

def save_local_state(data):
    tmp=CONTENT_STATE_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data,indent=2),encoding="utf-8")
    tmp.replace(CONTENT_STATE_FILE)



# -----------------------------------------------------------------------------
# V21 live Supabase connection
# The browser UI never receives the saved secret key. On Windows it is encrypted
# with DPAPI for the current Windows user before being written to disk.
# -----------------------------------------------------------------------------
class _DATA_BLOB(ctypes.Structure):
    _fields_=[("cbData",ctypes.c_ulong),("pbData",ctypes.POINTER(ctypes.c_ubyte))]

def _dpapi_encrypt(text):
    raw=(text or "").encode("utf-8")
    if os.name!="nt":
        return {"mode":"portable-base64","value":base64.b64encode(raw).decode("ascii")}
    try:
        buf=ctypes.create_string_buffer(raw)
        ib=_DATA_BLOB(len(raw),ctypes.cast(buf,ctypes.POINTER(ctypes.c_ubyte)))
        ob=_DATA_BLOB()
        ok=ctypes.windll.crypt32.CryptProtectData(ctypes.byref(ib),None,None,None,None,0,ctypes.byref(ob))
        if not ok: raise ctypes.WinError()
        enc=ctypes.string_at(ob.pbData,ob.cbData)
        ctypes.windll.kernel32.LocalFree(ob.pbData)
        return {"mode":"windows-dpapi","value":base64.b64encode(enc).decode("ascii")}
    except Exception:
        return {"mode":"portable-base64","value":base64.b64encode(raw).decode("ascii")}

def _dpapi_decrypt(spec):
    if not isinstance(spec,dict): return ""
    try: raw=base64.b64decode(spec.get("value") or "")
    except Exception:return ""
    if spec.get("mode")=="windows-dpapi" and os.name=="nt":
        try:
            buf=ctypes.create_string_buffer(raw)
            ib=_DATA_BLOB(len(raw),ctypes.cast(buf,ctypes.POINTER(ctypes.c_ubyte)))
            ob=_DATA_BLOB()
            ok=ctypes.windll.crypt32.CryptUnprotectData(ctypes.byref(ib),None,None,None,None,0,ctypes.byref(ob))
            if not ok:raise ctypes.WinError()
            dec=ctypes.string_at(ob.pbData,ob.cbData)
            ctypes.windll.kernel32.LocalFree(ob.pbData)
            return dec.decode("utf-8")
        except Exception:return ""
    try:return raw.decode("utf-8")
    except Exception:return ""

def _load_settings_raw():
    try:
        d=json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        return d if isinstance(d,dict) else {}
    except Exception:return {}

def _save_settings_raw(d):
    tmp=SETTINGS_FILE.with_suffix('.tmp')
    tmp.write_text(json.dumps(d,indent=2),encoding='utf-8')
    tmp.replace(SETTINGS_FILE)

def _normalize_project_url(v):
    s=str(v or '').strip().rstrip('/')
    if s and not s.startswith(('http://','https://')):s='https://'+s
    u=urlparse(s) if s else None
    if not u or u.scheme not in ('http','https') or not u.netloc: return ''
    return f"{u.scheme}://{u.netloc}"

def live_credentials():
    d=_load_settings_raw();url=_normalize_project_url(d.get('supabase_url'))
    key=_dpapi_decrypt(d.get('secret'))
    return url,key,d

def settings_payload():
    url,key,d=live_credentials()
    secure=(d.get('secret') or {}).get('mode')=='windows-dpapi'
    masked=''
    if key: masked=(key[:8]+'…'+key[-5:]) if len(key)>16 else '••••••••'
    return {"configured":bool(url and key),"supabase_url":url,"key_masked":masked,"secure_storage":secure,
            "storage_mode":(d.get('secret') or {}).get('mode'),"saved_at":d.get('saved_at'),"last_test":d.get('last_test'),
            "last_test_ok":bool(d.get('last_test_ok')),"key_kind":('secret' if key.startswith('sb_secret_') else 'legacy_service_role' if key.startswith('eyJ') else 'unknown') if key else None}

def save_live_settings(url,key):
    url=_normalize_project_url(url);key=str(key or '').strip()
    if not url:raise ValueError('Enter a valid Supabase project URL.')
    if not key:raise ValueError('Enter a Supabase secret/service-role key.')
    if key.startswith('sb_publishable_') or key.startswith('anon'):
        raise ValueError('Use a server-side Supabase Secret key or legacy service_role key, not the publishable/anon key.')
    d={"supabase_url":url,"secret":_dpapi_encrypt(key),"saved_at":time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),"last_test":None,"last_test_ok":False}
    _save_settings_raw(d);return settings_payload()

def _sb_headers(prefer=None):
    url,key,_=live_credentials()
    if not (url and key):raise ValueError('Connect Supabase in Settings first.')
    h={"apikey":key,"Accept":"application/json","Content-Type":"application/json"}
    # Legacy service_role keys are JWTs. New sb_secret keys authenticate through apikey.
    if key.startswith('eyJ'):h['Authorization']='Bearer '+key
    if prefer:h['Prefer']=prefer
    return url,h

def sb_request(method,path,query=None,body=None,prefer=None,return_headers=False,timeout=30):
    base,headers=_sb_headers(prefer)
    url=base+path
    if query:
        if isinstance(query,str):qs=query
        else:qs=urlencode(query,doseq=True,safe='(),.*')
        url+='?'+qs
    payload=None if body is None else json.dumps(body).encode('utf-8')
    req=Request(url,data=payload,headers=headers,method=method)
    try:
        with urlopen(req,timeout=timeout) as r:
            raw=r.read().decode('utf-8','replace')
            out=json.loads(raw) if raw.strip() else None
            return (out,dict(r.headers.items())) if return_headers else out
    except HTTPError as e:
        raw=e.read().decode('utf-8','replace') if hasattr(e,'read') else ''
        try:msg=(json.loads(raw) or {}).get('message') or (json.loads(raw) or {}).get('error') or raw
        except Exception:msg=raw
        raise RuntimeError(f"Supabase {e.code}: {msg or e.reason}")
    except URLError as e:raise RuntimeError(f"Could not reach Supabase: {e.reason}")

def test_live_connection():
    out=sb_request('GET','/rest/v1/questions',query='select=id&limit=1')
    d=_load_settings_raw();d['last_test']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());d['last_test_ok']=True;_save_settings_raw(d)
    return {"ok":True,"message":"Connected to the live Trivia database.","sample_rows":len(out or [])}

def _fetch_all(table,select='*',extra=''):
    rows=[];offset=0;page=1000
    while True:
        q=f"select={quote(select,safe=',()*')}&limit={page}&offset={offset}"
        if extra:q+='&'+extra.lstrip('&')
        batch=sb_request('GET',f'/rest/v1/{table}',query=q) or []
        rows.extend(batch)
        if len(batch)<page:break
        offset+=page
        if offset>100000:break
    return rows

def live_category_rows():
    try:
        rows=sb_request('POST','/rest/v1/rpc/content_studio_category_population_v22',body={})
        if isinstance(rows,list) and rows:
            return rows
    except Exception:
        pass
    try:catalog=_fetch_all('trivia_category_catalog','category,sort_order,enabled,user_selectable,default_terms','enabled=eq.true&order=sort_order.asc,category.asc')
    except Exception:catalog=[]
    qs=_fetch_all('questions','id,category,difficulty,is_active,image_url,media_review_status,photo_disabled')
    by={}
    for c in catalog:
        name=str(c.get('category') or '').strip()
        if name:by[name]={"category":name,"sort_order":int(c.get('sort_order') or 1000),"terms":c.get('default_terms') or [name],"total_count":0,"active_count":0,"easy_count":0,"medium_count":0,"hard_count":0,"valid_photo_count":0,"missing_photo_count":0,"retired_count":0}
    for q in qs:
        name=str(q.get('category') or '').strip() or 'General Knowledge'
        r=by.setdefault(name,{"category":name,"sort_order":1000,"terms":[name],"total_count":0,"active_count":0,"easy_count":0,"medium_count":0,"hard_count":0,"valid_photo_count":0,"missing_photo_count":0,"retired_count":0})
        r['total_count']+=1
        if q.get('is_active'):
            r['active_count']+=1
            d=str(q.get('difficulty') or '').lower()
            if d in ('easy','medium','hard'):r[d+'_count']+=1
            valid=bool(str(q.get('image_url') or '').strip()) and str(q.get('media_review_status') or 'unreviewed') not in ('rejected','none') and not bool(q.get('photo_disabled'))
            if valid:r['valid_photo_count']+=1
            else:r['missing_photo_count']+=1
        else:r['retired_count']+=1
    return sorted(by.values(),key=lambda r:(r.get('sort_order',1000),r['category'].lower()))

def live_dashboard_payload():
    rows=live_category_rows();active=sum(int(x.get('active_count') or 0) for x in rows);total=sum(int(x.get('total_count') or 0) for x in rows);missing=sum(int(x.get('missing_photo_count') or 0) for x in rows)
    return {"connected":True,"categories":rows,"overview":{"total":total,"active":active,"retired":max(0,total-active),"missing_photo":missing,"category_count":len(rows)},"settings":settings_payload()}

def _qs_value(params,key,default=''):
    return (params.get(key) or [default])[0]

def live_questions_payload(params):
    search=str(_qs_value(params,'search','')).strip();category=str(_qs_value(params,'category','')).strip();difficulty=str(_qs_value(params,'difficulty','any')).strip();status=str(_qs_value(params,'status','active')).strip()
    limit=max(1,min(200,int(_qs_value(params,'limit','50') or 50)));offset=max(0,int(_qs_value(params,'offset','0') or 0))
    parts=['select=*',f'limit={limit}',f'offset={offset}','order=updated_at.desc.nullslast,created_at.desc']
    if category:parts.append('category=eq.'+quote(category,safe=''))
    if difficulty in ('easy','medium','hard'):parts.append('difficulty=eq.'+difficulty)
    if status=='active':parts.append('is_active=eq.true')
    elif status=='retired':parts.append('is_active=eq.false')
    elif status=='photo_disabled':parts.append('photo_disabled=eq.true')
    if search:
        term=quote('*'+search.replace(',',' ')+'*',safe='* ')
        parts.append('or='+quote(f'(prompt.ilike.{term},canonical_key.ilike.{term},media_query.ilike.{term})',safe='(),.*%'))
    data,headers=sb_request('GET','/rest/v1/questions',query='&'.join(parts),prefer='count=exact',return_headers=True)
    cr=headers.get('Content-Range') or headers.get('content-range') or ''
    try:total=int(cr.split('/')[-1]) if '/' in cr and cr.split('/')[-1]!='*' else len(data or [])
    except Exception:total=len(data or [])
    return {"items":data or [],"total":total,"offset":offset,"limit":limit}

AUDIT_KEYS=("prompt","category","difficulty","question_type","context","unit","answer_numeric","answer_text","options","correct_option","explanation","source_url","source_type","source_entity_id","canonical_key","media_query","is_active","deleted_at","delete_reason","photo_disabled","photo_disabled_at","content_locked","image_url","image_alt","image_source_url","image_attribution","image_license","image_license_url","media_provider","media_review_status","media_locked","media_candidate_id")

def _audit_delta(before_data,after_data,after_side=False):
    before=before_data if isinstance(before_data,dict) else {}
    after=after_data if isinstance(after_data,dict) else {}
    src=after if after_side else before
    return {k:src.get(k) for k in AUDIT_KEYS if before.get(k)!=after.get(k) and k in src}

def _audit_direct(question_id,action,before_data,after_data,metadata=None):
    try:
        sb_request('POST','/rest/v1/question_audit_log',body={"question_id":question_id,"action":action,"actor_username":"Content Studio","before_data":_audit_delta(before_data,after_data,False),"after_data":_audit_delta(before_data,after_data,True),"metadata":{"origin":"content_studio_v22","storage_compacted":True,"storage_format":22,**(metadata or {})}},prefer='return=minimal')
    except Exception:pass

def _question_payload_clean(p,creating=False):
    qtype=str(p.get('question_type') or 'numeric').strip()
    if qtype not in ('numeric','multiple_choice','text'):raise ValueError('Invalid question type.')
    prompt=str(p.get('prompt') or '').strip()
    if len(prompt)<4:raise ValueError('Question prompt is required.')
    difficulty=str(p.get('difficulty') or 'medium').lower()
    if difficulty not in ('easy','medium','hard'):raise ValueError('Difficulty must be easy, medium, or hard.')
    category=str(p.get('category') or 'General Knowledge').strip() or 'General Knowledge'
    row={"category":category,"difficulty":difficulty,"question_type":qtype,"prompt":prompt,"context":str(p.get('context') or '').strip() or None,"unit":str(p.get('unit') or '').strip() or None,"explanation":str(p.get('explanation') or '').strip() or None,"source_url":str(p.get('source_url') or '').strip() or None,"media_query":str(p.get('media_query') or '').strip() or None,"content_locked":True,"updated_at":time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
    if qtype=='numeric':
        try:row['answer_numeric']=float(p.get('answer_numeric'))
        except Exception:raise ValueError('Numeric answer is required.')
        row.update({"answer_text":None,"options":None,"correct_option":None})
    elif qtype=='text':
        ans=str(p.get('answer_text') or '').strip()
        if not ans:raise ValueError('Text answer is required.')
        row.update({"answer_text":ans,"answer_numeric":None,"options":None,"correct_option":None})
    else:
        opts=p.get('options') or []
        if isinstance(opts,str):opts=[x.strip() for x in opts.splitlines() if x.strip()]
        if len(opts)<2:raise ValueError('Multiple-choice questions need at least two options.')
        try:correct=int(p.get('correct_option'))
        except Exception:raise ValueError('Choose the correct multiple-choice option.')
        if correct<0 or correct>=len(opts):raise ValueError('Correct option is invalid.')
        row.update({"options":opts,"correct_option":correct,"answer_numeric":None,"answer_text":None})
    if creating:
        row.update({"is_active":True,"source_type":"manual","canonical_key":"manual:"+str(uuid.uuid4())})
    return row

def save_live_question(payload):
    qid=str(payload.get('id') or '').strip();row=_question_payload_clean(payload,creating=not bool(qid))
    if qid:
        before=(sb_request('GET','/rest/v1/questions',query='select=*&id=eq.'+quote(qid,safe='')) or [None])[0]
        if not before:raise ValueError('Question not found.')
        after=sb_request('PATCH','/rest/v1/questions',query='id=eq.'+quote(qid,safe=''),body=row,prefer='return=representation') or []
        q=after[0] if after else {**before,**row};_audit_direct(qid,'edit',before,q)
        return {"created":False,"question":q}
    after=sb_request('POST','/rest/v1/questions',body=row,prefer='return=representation') or []
    q=after[0] if after else row;_audit_direct(q.get('id'),'create',None,q)
    return {"created":True,"question":q}

def set_live_question_active(qid,active):
    qid=str(qid or '').strip()
    before=(sb_request('GET','/rest/v1/questions',query='select=*&id=eq.'+quote(qid,safe='')) or [None])[0]
    if not before:raise ValueError('Question not found.')
    patch={"is_active":bool(active),"updated_at":time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
    if active:patch.update({"photo_disabled":False,"deleted_at":None,"delete_reason":None})
    else:patch.update({"photo_disabled":False,"deleted_at":time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),"delete_reason":"Retired from Content Studio"})
    after=sb_request('PATCH','/rest/v1/questions',query='id=eq.'+quote(qid,safe=''),body=patch,prefer='return=representation') or []
    q=after[0] if after else {**before,**patch};_audit_direct(qid,'restore' if active else 'delete',before,q,{"soft_retire":True})
    return {"question":q,"active":active}

def _selected_media_fields(media):
    sel=(media or {}).get('selected') or {}
    cands=(media or {}).get('candidates') or []
    cand=next((c for c in cands if str(c.get('provider'))==str(sel.get('provider')) and str(c.get('provider_key'))==str(sel.get('provider_key'))),None)
    if not cand:return None
    return {"image_url":cand.get('thumbnail_url') or cand.get('image_url'),"image_alt":cand.get('title') or (media or {}).get('query'),"image_source_url":cand.get('source_url'),"image_attribution":cand.get('creator'),"image_license":cand.get('license'),"image_license_url":cand.get('license_url'),"media_provider":cand.get('provider'),"media_review_status":"auto","media_locked":False,"media_candidate_id":None,"media_updated_at":time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),"media_last_resolved_at":time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}

def publish_current_package():
    package=content_package_payload();items=package.get('questions') or []
    if not items:raise ValueError('The current package is empty.')
    if package.get('package_kind')=='media_only':
        updated=0;missing=0
        for item in items:
            qid=str(item.get('id') or '')
            fields=_selected_media_fields(item.get('media') or {})
            if not qid or not fields:missing+=1;continue
            sb_request('PATCH','/rest/v1/questions',query='id=eq.'+quote(qid,safe=''),body=fields,prefer='return=minimal');updated+=1
        return {"package_kind":"media_only","created":0,"updated":updated,"skipped":missing,"media_published":updated,"total":len(items)}
    existing=_fetch_all('questions','id,canonical_key,content_locked,is_active,media_locked,category,difficulty,question_type,prompt,context,unit,options,answer_numeric,answer_text,correct_option,explanation,source_url,media_query')
    exmap={str(x.get('canonical_key')):x for x in existing if x.get('canonical_key')}
    created=updated=skipped=media_published=0
    for item in items:
        canonical=str(item.get('canonical_key') or '').strip()
        if not canonical:skipped+=1;continue
        core={k:item.get(k) for k in ('category','difficulty','question_type','prompt','context','unit','options','answer_numeric','answer_text','correct_option','explanation','source_url','source_type','source_entity_id','canonical_key','media_query')}
        core['updated_at']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
        before=exmap.get(canonical)
        if before:
            qid=before.get('id')
            if not before.get('is_active') or before.get('content_locked'):
                skipped+=1
            else:
                arr=sb_request('PATCH','/rest/v1/questions',query='id=eq.'+quote(str(qid),safe=''),body=core,prefer='return=representation') or []
                after=arr[0] if arr else {**before,**core};updated+=1;_audit_direct(qid,'edit',before,after,{"package_id":package.get('package_id'),"automated_sync":True})
        else:
            core.update({"is_active":True,"content_locked":False})
            arr=sb_request('POST','/rest/v1/questions',body=core,prefer='return=representation') or []
            after=arr[0] if arr else core;qid=after.get('id');created+=1;exmap[canonical]=after;_audit_direct(qid,'create',None,after,{"package_id":package.get('package_id')})
        fields=_selected_media_fields(item.get('media') or {})
        if fields and qid and not bool((exmap.get(canonical) or {}).get('media_locked')):
            sb_request('PATCH','/rest/v1/questions',query='id=eq.'+quote(str(qid),safe=''),body=fields,prefer='return=minimal');media_published+=1
    return {"package_kind":"content","created":created,"updated":updated,"skipped":skipped,"media_published":media_published,"total":len(items)}


LOCAL_STATE=load_local_state()
LOCAL_STATE.setdefault("offsets",{})
LOCAL_STATE.setdefault("custom_topics",[])
LOCAL_STATE.setdefault("category_topic_offsets",{})
ACQUIRE={
  "running":False,"cancel":False,"total_templates":0,"completed_templates":0,"questions":[],"errors":[],
  "events":[],"started_at":None,"finished_at":None,"per_template":100,"selected":[],"offset_mode":"continue",
  "workers":3,"active":{},"audience":"mainstream"
}

TOPIC_PREVIEWS={}

CATEGORY_RUN={"running":False,"cancel":False,"stage":"idle","category":None,"requested":0,"acquired":0,"message":"Ready.","started_at":None,"finished_at":None,"error":None,"difficulty_focus":"smart"}
STARTER_TOPIC_PACKS=[
  {"id":"starter-brainrot","name":"Brainrot","category":"Brainrot","terms":["Italian brainrot","brainrot meme","TikTok meme","viral meme","internet meme"],"audience":"balanced","description":"Italian brainrot, meme characters, viral internet culture and adjacent topics."},
  {"id":"starter-gaming","name":"General Gaming Knowledge","category":"General Gaming Knowledge","terms":["Minecraft","Fortnite","Roblox","Grand Theft Auto","Call of Duty","Pokémon","Mario","The Legend of Zelda","Sonic the Hedgehog","PlayStation","Xbox","Nintendo"],"audience":"mainstream","description":"Recognizable games, consoles, franchises and gaming culture."},
  {"id":"starter-internet","name":"Internet Culture","category":"Internet Culture","terms":["YouTube","TikTok","Twitch","Discord","Reddit","internet meme","viral video","social media"],"audience":"mainstream","description":"Major platforms, creators, memes and online culture."},
  {"id":"starter-pop","name":"Pop Culture","category":"Pop Culture","terms":["Marvel","Star Wars","Disney","Netflix","celebrity","superhero","streaming television"],"audience":"mainstream","description":"Widely recognizable entertainment and celebrity topics."},
  {"id":"starter-movies","name":"Movies & TV","category":"Movies & TV","terms":["blockbuster film","television series","animated film","sitcom","movie franchise"],"audience":"mainstream","description":"Mainstream movies, TV series and franchises."},
  {"id":"starter-music","name":"Music","category":"Music","terms":["pop music","hip hop","rock band","singer","album"],"audience":"mainstream","description":"Artists, albums, songs and mainstream music history."},
  {"id":"starter-brands","name":"Food & Brands","category":"Food & Brands","terms":["McDonald's","Coca-Cola","Pepsi","Starbucks","Oreo","Doritos","restaurant chain","food brand"],"audience":"mainstream","description":"Everyday brands, snacks, restaurants and products."},
  {"id":"starter-general","name":"General Knowledge","category":"General Knowledge","terms":["famous landmark","major city","world record","famous person","popular animal","country"],"audience":"mainstream","description":"Broad recognizable trivia for mixed groups."}
]

STATE_LOCK=threading.RLock()
STATE={
  "running":False,"cancel":False,"total":0,"completed":0,"resolved":0,"missing":0,
  "started_at":None,"finished_at":None,"items":[],"job":None,"error":None,
  "concurrency":4,"probe_count":4
}

def clean(v):
    return re.sub(r"\s+"," ",html.unescape(re.sub(r"<[^>]*>"," ",str(v or "")))).strip()

def safe_http(v):
    try:
        s=str(v or "").strip()
        if not s: return None
        u=urlparse(s)
        if u.scheme not in ("http","https"): return None
        if u.scheme=="http":
            s="https://"+u.netloc+u.path+(("?"+u.query) if u.query else "")
        return s
    except Exception:
        return None

def fetch_json(url, timeout=18, attempts=3):
    last=None
    for attempt in range(attempts):
        try:
            req=Request(url,headers={"User-Agent":USER_AGENT,"Accept":"application/json"})
            with urlopen(req,timeout=timeout) as r:
                return json.loads(r.read().decode("utf-8","replace"))
        except HTTPError as e:
            last=e
            if e.code in (429,500,502,503,504):
                time.sleep(min(4,0.6*(2**attempt)))
                continue
            raise
        except Exception as e:
            last=e
            if attempt+1<attempts:
                time.sleep(min(3,0.45*(2**attempt)))
                continue
            raise
    raise last

def tokens(s):
    return {x for x in re.findall(r"[a-z0-9]+",str(s or "").lower()) if len(x)>1}

def overlap_score(query,title):
    q=tokens(query); t=tokens(title)
    if not q or not t:return 0
    return round(42*len(q&t)/max(1,len(q)))

def aspect_bonus(w,h):
    try:
        w=float(w or 0);h=float(h or 0)
        if w<=0 or h<=0:return 0
        r=w/h
        if 1.15<=r<=2.0:return 14
        if .85<=r<=2.3:return 8
        return 0
    except:return 0

def size_bonus(w,h):
    try:
        m=min(float(w or 0),float(h or 0))
        if m>=900:return 10
        if m>=600:return 7
        if m>=350:return 4
        return 0
    except:return 0

def openverse_auto_eligible(license_code):
    s=str(license_code or "").lower().strip().replace("cc ","").replace(" ","-")
    return s in {"cc0","pdm","public-domain","by","by-sa"}

def ext(meta,key):
    try:return clean((meta.get(key) or {}).get("value"))
    except:return ""

def heuristic_query(q):
    mq=clean(q.get("media_query"))
    if mq:return mq
    alt=clean(q.get("image_alt"))
    if alt:return alt
    prompt=clean(q.get("prompt"))
    # Strip common estimation framing without pretending to understand every question.
    prompt=re.sub(r"^(approximately|about|roughly)\s+","",prompt,flags=re.I)
    prompt=re.sub(r"^(how many|how much|in what year did|what year did)\s+","",prompt,flags=re.I)
    prompt=re.sub(r"\?$","",prompt)
    return prompt[:140]

def search_commons(query,per_source=10):
    p={
      "action":"query","format":"json","formatversion":"2","generator":"search",
      "gsrsearch":query,"gsrnamespace":"6","gsrlimit":str(per_source),
      "prop":"imageinfo","iiprop":"url|extmetadata","iiurlwidth":"1200",
      "iiextmetadatafilter":"Artist|Credit|LicenseShortName|LicenseUrl|ImageDescription|ObjectName"
    }
    body=fetch_json(COMMONS_API+"?"+urlencode(p))
    out=[]
    for page in (body.get("query") or {}).get("pages") or []:
        info=(page.get("imageinfo") or [None])[0]
        if not info: continue
        m=info.get("extmetadata") or {}
        image=safe_http(info.get("url"));thumb=safe_http(info.get("thumburl") or info.get("url"));source=safe_http(info.get("descriptionurl"))
        if not(image and thumb and source):continue
        title=ext(m,"ObjectName") or str(page.get("title") or "").replace("File:","")
        creator=ext(m,"Artist") or ext(m,"Credit") or "Wikimedia Commons contributor"
        lic=ext(m,"LicenseShortName") or "Wikimedia Commons license"
        w=info.get("thumbwidth") or info.get("width");h=info.get("thumbheight") or info.get("height")
        out.append({
          "provider":"wikimedia","provider_key":str(page.get("pageid") or page.get("title")),
          "title":clean(title),"image_url":image,"thumbnail_url":thumb,"source_url":source,
          "creator":clean(creator),"creator_url":None,"license":clean(lic),
          "license_url":safe_http((m.get("LicenseUrl") or {}).get("value")),"width":w,"height":h,
          "score":112+overlap_score(query,title)+aspect_bonus(w,h)+size_bonus(w,h),
          "auto_eligible":True,"is_available":True,"metadata":{"commons_title":page.get("title")}
        })
    return out

def search_wikipedia_lead(query,per_source=6):
    p={"action":"query","format":"json","formatversion":"2","generator":"search","gsrsearch":query,
       "gsrnamespace":"0","gsrlimit":str(min(per_source,6)),"prop":"pageimages","piprop":"name|thumbnail","pithumbsize":"1200"}
    body=fetch_json(WIKIPEDIA_API+"?"+urlencode(p))
    leads=[]
    for page in (body.get("query") or {}).get("pages") or []:
        if page.get("pageimage"):
            leads.append({"article":page.get("title"),"file":"File:"+page["pageimage"]})
    if not leads:return []
    cp={"action":"query","format":"json","formatversion":"2","prop":"imageinfo","iiprop":"url|extmetadata","iiurlwidth":"1200",
        "iiextmetadatafilter":"Artist|Credit|LicenseShortName|LicenseUrl|ObjectName","titles":"|".join(x["file"] for x in leads)}
    cb=fetch_json(COMMONS_API+"?"+urlencode(cp))
    amap={x["file"].replace("_"," "):x["article"] for x in leads}
    out=[]
    for page in (cb.get("query") or {}).get("pages") or []:
        info=(page.get("imageinfo") or [None])[0]
        if not info:continue
        m=info.get("extmetadata") or {}
        image=safe_http(info.get("url"));thumb=safe_http(info.get("thumburl") or info.get("url"));source=safe_http(info.get("descriptionurl"))
        if not(image and thumb and source):continue
        article=amap.get(str(page.get("title") or "").replace("_"," "),query)
        title=ext(m,"ObjectName") or str(page.get("title") or "").replace("File:","")
        creator=ext(m,"Artist") or ext(m,"Credit") or "Wikimedia Commons contributor"
        lic=ext(m,"LicenseShortName") or "Wikimedia Commons license"
        w=info.get("thumbwidth") or info.get("width");h=info.get("thumbheight") or info.get("height")
        out.append({
          "provider":"wikipedia","provider_key":str(page.get("pageid") or page.get("title")),
          "title":clean(title),"image_url":image,"thumbnail_url":thumb,"source_url":source,
          "creator":clean(creator),"creator_url":None,"license":clean(lic),
          "license_url":safe_http((m.get("LicenseUrl") or {}).get("value")),"width":w,"height":h,
          "score":132+overlap_score(query,article)+aspect_bonus(w,h)+size_bonus(w,h),
          "auto_eligible":True,"is_available":True,
          "metadata":{"wikipedia_article":article,"commons_title":page.get("title")}
        })
    return out

def search_openverse(query,per_source=10):
    body=fetch_json(OPENVERSE_API+"?"+urlencode({"q":query,"page_size":str(per_source)}))
    out=[]
    for item in body.get("results") or []:
        if item.get("is_sensitive") or item.get("sensitivity"):continue
        image=safe_http(item.get("url"));thumb=safe_http(item.get("thumbnail") or item.get("url"));source=safe_http(item.get("foreign_landing_url") or item.get("detail_url"))
        if not(image and thumb and source):continue
        lic=clean(" ".join(str(x) for x in [item.get("license"),item.get("license_version")] if x))
        eligible=openverse_auto_eligible(item.get("license"))
        w=item.get("width");h=item.get("height")
        score=88+overlap_score(query,item.get("title") or "")+aspect_bonus(w,h)+size_bonus(w,h)+(10 if eligible else -35)-(50 if item.get("watermarked") else 0)
        out.append({
          "provider":"openverse","provider_key":str(item.get("id") or item.get("foreign_identifier") or item.get("url")),
          "title":clean(item.get("title") or query),"image_url":image,"thumbnail_url":thumb,"source_url":source,
          "creator":clean(item.get("creator") or "Unknown creator"),"creator_url":safe_http(item.get("creator_url")),
          "license":lic or None,"license_url":safe_http(item.get("license_url") or (item.get("meta_data") or {}).get("license_url")),
          "width":w,"height":h,"score":score,"auto_eligible":eligible,"is_available":True,
          "metadata":{"source":item.get("source"),"provider":item.get("provider"),"openverse_id":item.get("id"),"watermarked":bool(item.get("watermarked"))}
        })
    return out

def legacy_candidate(q,query):
    image=safe_http(q.get("image_url"))
    if not image:return None
    source=safe_http(q.get("image_source_url"))
    provider=q.get("media_provider") or ("wikimedia" if source and "commons.wikimedia.org" in source else "legacy")
    commons=provider=="wikimedia" or (source and "commons.wikimedia.org" in source)
    return {
      "provider":provider,"provider_key":"current:"+str(q.get("id")),"title":clean(q.get("image_alt") or query or q.get("prompt")),
      "image_url":image,"thumbnail_url":image,"source_url":source,"creator":clean(q.get("image_attribution")) or None,
      "creator_url":None,"license":clean(q.get("image_license")) or None,"license_url":safe_http(q.get("image_license_url")),
      "width":None,"height":None,"score":145 if commons else 100,
      "auto_eligible":bool(commons or openverse_auto_eligible(q.get("image_license"))),"is_available":True,"metadata":{"legacy":True}
    }

def probe(candidate):
    url=candidate.get("thumbnail_url") or candidate.get("image_url")
    if not url:return False
    try:
        req=Request(url,headers={"User-Agent":USER_AGENT,"Accept":"image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8","Range":"bytes=0-32767"})
        with urlopen(req,timeout=10) as r:
            typ=(r.headers.get("content-type") or "").lower()
            final=urlparse(r.geturl()).path.lower()
            return (200<=getattr(r,"status",200)<400) and (typ.startswith("image/") or re.search(r"\.(jpg|jpeg|png|webp|gif|svg)$",final))
    except Exception:
        return False

def resolve_one(q,probe_count=4):
    query=heuristic_query(q)
    errors=[]
    candidates=[]
    legacy=legacy_candidate(q,query)
    if legacy:candidates.append(legacy)
    with ThreadPoolExecutor(max_workers=3) as ex:
        futs={
          ex.submit(search_wikipedia_lead,query):"Wikipedia",
          ex.submit(search_commons,query):"Commons",
          ex.submit(search_openverse,query):"Openverse"
        }
        for fut,label in list(futs.items()):
            try:candidates.extend(fut.result())
            except Exception as e:errors.append(f"{label}: {e}")
    rejected={(str(x.get("provider")),str(x.get("provider_key"))) for x in (q.get("rejected_candidates") or [])}
    dedup={}
    for c in candidates:
        key=(str(c.get("provider")),str(c.get("provider_key")))
        if key in rejected:continue
        old=dedup.get(key)
        if old is None or float(c.get("score") or 0)>float(old.get("score") or 0):dedup[key]=c
    compact=sorted(dedup.values(),key=lambda x:float(x.get("score") or 0),reverse=True)[:5]
    top=compact[:max(1,min(int(probe_count or 4),8))]
    with ThreadPoolExecutor(max_workers=min(8,len(top) or 1)) as ex:
        probe_futs={ex.submit(probe,c):c for c in top}
        for fut,c in probe_futs.items():
            try:c["is_available"]=bool(fut.result())
            except:c["is_available"]=False
            if not c["is_available"]:c["score"]=float(c.get("score") or 0)-120
    for c in compact[len(top):]:
        c["is_available"]=False
    compact=sorted(compact,key=lambda x:float(x.get("score") or 0),reverse=True)
    selected=next((c for c in compact if c.get("auto_eligible") and c.get("is_available")),None)
    return {
      "id":q.get("id"),"prompt":q.get("prompt"),"query":query,
      "status":"resolved" if selected else "missing","selection_mode":"auto",
      "selected":{"provider":selected.get("provider"),"provider_key":selected.get("provider_key")} if selected else None,
      "candidates":compact,"errors":errors
    }

def acquire_cancelled():
    with STATE_LOCK:return bool(ACQUIRE["cancel"])

def acquire_progress(done,total,event):
    with STATE_LOCK:
        if isinstance(done,int) and done >= 0:
            ACQUIRE["completed_templates"]=max(int(ACQUIRE.get("completed_templates") or 0),done)
        tid=str((event or {}).get("template") or "")
        if tid:
            ACQUIRE.setdefault("active",{})[tid]=dict(event or {})
        ACQUIRE["events"].append(dict(event or {}))
        ACQUIRE["events"]=ACQUIRE["events"][-80:]

def run_acquisition(selected,per_template,offset_mode,custom_offset=0,workers=3,audience="mainstream"):
    try:
        with STATE_LOCK:
            ACQUIRE.update({"running":True,"cancel":False,"total_templates":len(selected),"completed_templates":0,"questions":[],"errors":[],"events":[],"started_at":time.time(),"finished_at":None,"per_template":per_template,"selected":selected,"offset_mode":offset_mode,"workers":workers,"active":{},"audience":audience})
        if offset_mode=="zero":offsets={tid:0 for tid in selected}
        elif offset_mode=="custom":offsets={tid:max(0,int(custom_offset or 0)) for tid in selected}
        else:offsets={tid:int((LOCAL_STATE.get("offsets") or {}).get(tid,0) or 0) for tid in selected}
        questions,new_offsets,errors=acquire_questions(selected,per_template,offsets,progress=acquire_progress,cancel=acquire_cancelled,max_workers=workers,audience=audience)
        with STATE_LOCK:
            ACQUIRE["questions"]=questions;ACQUIRE["errors"]=errors;ACQUIRE["running"]=False;ACQUIRE["finished_at"]=time.time()
            if not ACQUIRE["cancel"] and offset_mode=="continue":
                LOCAL_STATE["offsets"].update({k:int(v) for k,v in new_offsets.items()});save_local_state(LOCAL_STATE)
    except Exception as e:
        with STATE_LOCK:
            ACQUIRE["running"]=False;ACQUIRE["finished_at"]=time.time();ACQUIRE["errors"].append({"error":str(e)})

def acquire_status():
    with STATE_LOCK:
        return {
          "running":ACQUIRE["running"],"cancel":ACQUIRE["cancel"],"total_templates":ACQUIRE["total_templates"],
          "completed_templates":ACQUIRE["completed_templates"],"question_count":len(ACQUIRE["questions"]),
          "errors":list(ACQUIRE["errors"]),"events":list(ACQUIRE["events"]),"started_at":ACQUIRE["started_at"],
          "finished_at":ACQUIRE["finished_at"],"selected":list(ACQUIRE["selected"]),"per_template":ACQUIRE["per_template"],
          "workers":ACQUIRE.get("workers",3),"audience":ACQUIRE.get("audience","mainstream"),"active":dict(ACQUIRE.get("active") or {}),
          "elapsed":((time.time()-(ACQUIRE["started_at"] or time.time())) if ACQUIRE["started_at"] else 0)
        }

def template_payload():
    offsets=LOCAL_STATE.get("offsets") or {}
    categories={}
    rows=[]
    for t in TEMPLATES:
        row={"id":t["id"],"name":t["name"],"category":t["category"],"difficulty":t["difficulty"],
             "offset":int(offsets.get(t["id"],0) or 0),"recommended":bool(t.get("recommended")),"note":str(t.get("note") or "")}
        rows.append(row);categories[row["category"]]=categories.get(row["category"],0)+1
    return {"templates":rows,"categories":categories,"count":len(rows),"provider":"Wikidata Action API"}

def topic_pack_payload():
    saved=[]
    for x in (LOCAL_STATE.get("custom_topics") or []):
        row=dict(x);row["index"]=sum(int(v or 0) for v in (row.get("offsets") or {}).values());saved.append(row)
    return {"starters":STARTER_TOPIC_PACKS,"saved":saved}

def _append_questions(rows):
    with STATE_LOCK:
        existing={str(q.get("canonical_key") or q.get("id")):q for q in (ACQUIRE.get("questions") or [])}
        before=len(existing)
        for q in rows:
            existing[str(q.get("canonical_key") or q.get("id"))]=q
        ACQUIRE["questions"]=list(existing.values())
        ACQUIRE["errors"]=[]
        ACQUIRE["finished_at"]=time.time()
        return len(existing)-before,len(existing)

def _save_topic_pack(preview,spec,acquired):
    topics=list(LOCAL_STATE.get("custom_topics") or [])
    tid=preview["topic_id"]
    old=next((x for x in topics if x.get("id")==tid),None)
    row={
      "id":tid,"name":spec.get("name") or preview["category"],"category":preview["category"],"terms":preview["terms"],
      "audience":preview["audience"],"include_numeric":bool(spec.get("include_numeric",True)),"include_identify":bool(spec.get("include_identify",True)),
      "offsets":preview.get("next_offsets") or {},"acquired_total":int((old or {}).get("acquired_total") or 0)+int(acquired or 0),
      "updated_at":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime())
    }
    topics=[x for x in topics if x.get("id")!=tid]+[row]
    LOCAL_STATE["custom_topics"]=topics;save_local_state(LOCAL_STATE)
    return row

def topic_preview_payload(spec):
    terms=normalize_terms(spec.get("terms") or [])
    category=str(spec.get("category") or "General Knowledge").strip()[:60] or "General Knowledge"
    audience=str(spec.get("audience") or "mainstream").lower()
    if audience not in ("mainstream","balanced","deep"):audience="mainstream"
    depth=max(10,min(250,int(spec.get("depth") or 100)))
    result=preview_topic(terms,category,depth,audience,bool(spec.get("include_numeric",True)),bool(spec.get("include_identify",True)),spec.get("offsets") or {})
    pid=str(uuid.uuid4());TOPIC_PREVIEWS[pid]={"result":result,"spec":{**spec,"terms":terms,"category":category,"audience":audience}}
    return {
      "preview_id":pid,"topic_id":result["topic_id"],"category":result["category"],"terms":result["terms"],"audience":result["audience"],
      "question_count":result["question_count"],"numeric_count":result["numeric_count"],"identify_count":result["identify_count"],
      "entity_count":result["entity_count"],"entities_scanned":result["entities_scanned"],"has_more":result["has_more"],
      "term_meta":result["term_meta"],"questions":[{k:q.get(k) for k in ("prompt","category","difficulty","question_type","answer_numeric","unit","options","correct_option","source_url","media_query")} for q in result["questions"][:20]]
    }


def starter_terms_for_category(category):
    for p in STARTER_TOPIC_PACKS:
        if str(p.get("category") or "").lower()==str(category or "").lower():
            return list(p.get("terms") or [])
    return [str(category or "General Knowledge")]

def category_run_status():
    with STATE_LOCK:
        row=dict(CATEGORY_RUN)
        row["acquire"]=acquire_status()
        row["media"]=status_payload()
        return row

def _reset_content_for_category():
    with STATE_LOCK:
        ACQUIRE.update({"running":False,"cancel":False,"total_templates":0,"completed_templates":0,"questions":[],"errors":[],"events":[],"started_at":None,"finished_at":None,"per_template":100,"selected":[],"offset_mode":"continue","workers":3,"active":{},"audience":"mainstream"})
        STATE.update({"running":False,"cancel":False,"total":0,"completed":0,"resolved":0,"missing":0,"started_at":None,"finished_at":None,"items":[],"job":None,"error":None,"concurrency":4,"probe_count":4})

def run_category_pipeline(category,requested,audience="mainstream",difficulty_focus="smart",acquire_workers=3,media_workers=4,probe_count=4,current=None,terms=None):
    try:
        category=str(category or "").strip()
        if not category: raise ValueError("Category is required.")
        requested=max(5,min(1000,int(requested or 100)))
        current=current or {}
        with STATE_LOCK:
            CATEGORY_RUN.update({"running":True,"cancel":False,"stage":"acquiring","category":category,"requested":requested,"acquired":0,"message":f"Acquiring {category} questions…","started_at":time.time(),"finished_at":None,"error":None,"difficulty_focus":difficulty_focus})
        _reset_content_for_category()
        available=[t for t in TEMPLATES if t.get("category")==category]
        focus=str(difficulty_focus or "smart").lower()
        if focus=="smart":
            diff_counts={d:int(current.get(f"{d}_count") or 0) for d in ("easy","medium","hard")}
            focus=min(diff_counts,key=diff_counts.get) if any(diff_counts.values()) else "balanced"
        selected=[t["id"] for t in available if focus not in ("balanced","smart") and t.get("difficulty")==focus]
        if not selected:selected=[t["id"] for t in available]
        questions=[];errors=[]
        if selected:
            per=max(5,min(250,math.ceil(requested/max(1,len(selected)))))
            with STATE_LOCK:
                ACQUIRE.update({"running":True,"cancel":False,"total_templates":len(selected),"completed_templates":0,"questions":[],"errors":[],"events":[],"started_at":time.time(),"finished_at":None,"per_template":per,"selected":selected,"offset_mode":"continue","workers":acquire_workers,"active":{},"audience":audience})
            offsets={tid:int((LOCAL_STATE.get("offsets") or {}).get(tid,0) or 0) for tid in selected}
            def progress(done,total,event):
                acquire_progress(done,total,event)
                with STATE_LOCK:CATEGORY_RUN["message"]=(event or {}).get("message") or f"Acquiring {category}…"
            rows,new_offsets,errors=acquire_questions(selected,per,offsets,progress=progress,cancel=lambda: bool(CATEGORY_RUN.get("cancel")),max_workers=acquire_workers,audience=audience)
            questions.extend(rows)
            if not CATEGORY_RUN.get("cancel"):
                LOCAL_STATE["offsets"].update({k:int(v) for k,v in new_offsets.items()});save_local_state(LOCAL_STATE)
        # Topic discovery supplements categories with no fixed generators, and tops up thin generator runs.
        if len(questions)<requested and not CATEGORY_RUN.get("cancel"):
            search_terms=normalize_terms(terms or starter_terms_for_category(category))
            cat_offsets=dict((LOCAL_STATE.get("category_topic_offsets") or {}).get(category) or {})
            depth=max(50,min(250,requested-len(questions)+50))
            with STATE_LOCK:CATEGORY_RUN["message"]=f"Searching broader {category} sources…"
            result=preview_topic(search_terms,category,depth,audience,True,True,cat_offsets)
            questions.extend(result.get("questions") or [])
            LOCAL_STATE.setdefault("category_topic_offsets",{})[category]=result.get("next_offsets") or cat_offsets
            save_local_state(LOCAL_STATE)
        # Dedupe and enforce category/request size.
        seen={};trimmed=[]
        for q in questions:
            key=str(q.get("canonical_key") or q.get("id") or "")
            if not key or key in seen:continue
            seen[key]=1;q=dict(q);q["category"]=category;trimmed.append(q)
            if len(trimmed)>=requested:break
        with STATE_LOCK:
            ACQUIRE.update({"running":False,"cancel":False,"total_templates":len(selected),"completed_templates":len(selected),"questions":trimmed,"errors":errors,"finished_at":time.time(),"selected":selected,"audience":audience})
            CATEGORY_RUN["acquired"]=len(trimmed)
        if CATEGORY_RUN.get("cancel"):
            with STATE_LOCK:CATEGORY_RUN.update({"running":False,"stage":"cancelled","message":"Category run cancelled.","finished_at":time.time()})
            return
        if not trimmed:raise ValueError(f"No usable {category} questions were found in this slice.")
        with STATE_LOCK:CATEGORY_RUN.update({"stage":"media","message":f"Resolving media for {len(trimmed)} {category} questions…"})
        run_job(content_media_job(),media_workers,probe_count)
        if CATEGORY_RUN.get("cancel") or STATE.get("cancel"):
            with STATE_LOCK:CATEGORY_RUN.update({"running":False,"stage":"cancelled","message":"Category run cancelled during media resolution.","finished_at":time.time()})
            return
        with STATE_LOCK:
            CATEGORY_RUN.update({"running":False,"stage":"ready","message":f"Ready: {len(trimmed)} {category} questions with media pass complete.","finished_at":time.time()})
    except Exception as e:
        with STATE_LOCK:CATEGORY_RUN.update({"running":False,"stage":"error","message":str(e),"error":str(e),"finished_at":time.time()})

def content_media_job():
    with STATE_LOCK:
        questions=[dict(q) for q in ACQUIRE.get("questions") or []]
    return {"format":"whatmod-trivia-media-job","version":1,"job_id":str(uuid.uuid4()),"scope":"local-acquired","exported_at":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),"question_count":len(questions),"questions":questions}

def content_package_payload():
    with STATE_LOCK:
        questions=[dict(q) for q in ACQUIRE.get("questions") or []]
        media_items=list(STATE.get("items") or [])
        media_job=dict(STATE.get("job") or {})
    by_id={str(x.get("id")):x for x in media_items}
    # Normal content-acquisition package.
    if questions:
        packed=[]
        for q in questions:
            row=dict(q);media=by_id.get(str(q.get("id")))
            row["media"]=media if media else {"id":q.get("id"),"query":heuristic_query(q),"status":"not_resolved","selection_mode":"auto","selected":None,"candidates":[],"errors":[]}
            row.pop("id",None)
            packed.append(row)
        return {
          "format":"whatmod-trivia-content-package","version":1,"package_kind":"content","package_id":str(uuid.uuid4()),
          "generated_at":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),"question_count":len(packed),
          "media_resolved":sum(1 for q in packed if (q.get("media") or {}).get("selected")),
          "source":"WhatMod Trivia Content Studio","questions":packed
        }
    # Media-only jobs exported from Trivia Admin do not contain answers/canonical facts.
    # They can still be exported through the unified Content Package button; Trivia Admin
    # recognizes package_kind=media_only and routes them through the safe media importer.
    if media_items and media_job.get("format")=="whatmod-trivia-media-job":
        packed=[]
        job_by_id={str(q.get("id")):dict(q) for q in (media_job.get("questions") or [])}
        for item in media_items:
            q=job_by_id.get(str(item.get("id")),{})
            packed.append({
              "id":item.get("id"),"prompt":q.get("prompt") or item.get("prompt"),"category":q.get("category"),
              "difficulty":q.get("difficulty"),"media":item
            })
        return {
          "format":"whatmod-trivia-content-package","version":1,"package_kind":"media_only","package_id":str(uuid.uuid4()),
          "source_job_id":media_job.get("job_id"),"generated_at":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),
          "question_count":len(packed),"media_resolved":sum(1 for q in packed if (q.get("media") or {}).get("selected")),
          "source":"WhatMod Trivia Content Studio · media-only","questions":packed
        }
    return {
      "format":"whatmod-trivia-content-package","version":1,"package_kind":"content","package_id":str(uuid.uuid4()),
      "generated_at":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),"question_count":0,"media_resolved":0,
      "source":"WhatMod Trivia Content Studio","questions":[]
    }

def reset_state(job,concurrency,probe_count):
    with STATE_LOCK:
        STATE.update({
          "running":True,"cancel":False,"total":len(job.get("questions") or []),"completed":0,"resolved":0,"missing":0,
          "started_at":time.time(),"finished_at":None,"items":[],"job":job,"error":None,
          "concurrency":concurrency,"probe_count":probe_count
        })

def run_job(job,concurrency,probe_count):
    try:
        questions=job.get("questions") or []
        reset_state(job,concurrency,probe_count)
        with ThreadPoolExecutor(max_workers=concurrency) as ex:
            futs={ex.submit(resolve_one,q,probe_count):q for q in questions}
            for fut in as_completed(futs):
                with STATE_LOCK:
                    if STATE["cancel"]:break
                q=futs[fut]
                try:res=fut.result()
                except Exception as e:
                    res={"id":q.get("id"),"prompt":q.get("prompt"),"query":heuristic_query(q),"status":"error","selection_mode":"auto","selected":None,"candidates":[],"errors":[str(e)]}
                with STATE_LOCK:
                    STATE["items"].append(res)
                    STATE["completed"]+=1
                    if res.get("status")=="resolved":STATE["resolved"]+=1
                    else:STATE["missing"]+=1
        with STATE_LOCK:
            STATE["running"]=False;STATE["finished_at"]=time.time()
    except Exception as e:
        with STATE_LOCK:
            STATE["running"]=False;STATE["finished_at"]=time.time();STATE["error"]=str(e)

def status_payload():
    with STATE_LOCK:
        items=STATE["items"][-250:]
        elapsed=(time.time()-(STATE["started_at"] or time.time())) if STATE["started_at"] else 0
        rate=(STATE["completed"]/elapsed) if elapsed>0 else 0
        return {
          "running":STATE["running"],"cancel":STATE["cancel"],"total":STATE["total"],"completed":STATE["completed"],
          "resolved":STATE["resolved"],"missing":STATE["missing"],"error":STATE["error"],"elapsed":elapsed,
          "rate":rate,"items":items
        }

def result_payload():
    with STATE_LOCK:
        job=STATE.get("job") or {}
        items=list(STATE.get("items") or [])
        return {
          "format":"whatmod-trivia-media-results","version":1,
          "source_job_id":job.get("job_id"),"resolved_at":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),
          "question_count":len(items),
          "stats":{"resolved":sum(1 for x in items if x.get("selected")),"missing":sum(1 for x in items if not x.get("selected"))},
          "questions":items
        }

class Handler(SimpleHTTPRequestHandler):
    def translate_path(self,path):
        raw=path.split("?",1)[0]
        if raw=="/":raw="/index.html"
        return str(WEB/raw.lstrip("/"))
    def log_message(self,fmt,*args):pass
    def send_json(self,obj,status=200):
        data=json.dumps(obj).encode()
        self.send_response(status);self.send_header("Content-Type","application/json");self.send_header("Content-Length",str(len(data)));self.end_headers();self.wfile.write(data)
    def read_json(self):
        n=int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n).decode("utf-8")) if n else {}
    def do_GET(self):
        parsed=urlparse(self.path);params=parse_qs(parsed.query)
        if parsed.path=="/api/version":return self.send_json({"name":"WhatMod Trivia Content Studio","version":STUDIO_VERSION,"capabilities":STUDIO_CAPABILITIES})
        if parsed.path=="/api/settings":return self.send_json(settings_payload())
        if parsed.path=="/api/live/dashboard":
            try:return self.send_json(live_dashboard_payload())
            except Exception as e:return self.send_json({"error":str(e)},400)
        if parsed.path=="/api/live/questions":
            try:return self.send_json(live_questions_payload(params))
            except Exception as e:return self.send_json({"error":str(e)},400)
        if parsed.path=="/api/live/question":
            try:
                qid=_qs_value(params,'id','')
                rows=sb_request('GET','/rest/v1/questions',query='select=*&id=eq.'+quote(str(qid),safe='')) or []
                if not rows:return self.send_json({"error":"Question not found."},404)
                return self.send_json({"question":rows[0]})
            except Exception as e:return self.send_json({"error":str(e)},400)
        if self.path.startswith("/api/status"):return self.send_json(status_payload())
        if self.path.startswith("/api/results"):return self.send_json(result_payload())
        if self.path.startswith("/api/templates"):return self.send_json(template_payload())
        if self.path.startswith("/api/category/status"):return self.send_json(category_run_status())
        if self.path.startswith("/api/topic/packs"):return self.send_json(topic_pack_payload())
        if self.path.startswith("/api/acquire/status"):return self.send_json(acquire_status())
        if self.path.startswith("/api/acquire/questions"):
            with STATE_LOCK:return self.send_json({"questions":list(ACQUIRE.get("questions") or [])[:500]})
        if self.path.startswith("/api/content/package"):return self.send_json(content_package_payload())
        return super().do_GET()
    def do_POST(self):
        try:
            body=self.read_json()
            if self.path=="/api/settings/save":
                return self.send_json(save_live_settings(body.get('supabase_url'),body.get('secret_key')))
            if self.path=="/api/settings/test":
                return self.send_json(test_live_connection())
            if self.path=="/api/settings/clear":
                try:SETTINGS_FILE.unlink(missing_ok=True)
                except TypeError:
                    if SETTINGS_FILE.exists():SETTINGS_FILE.unlink()
                return self.send_json(settings_payload())
            if self.path=="/api/live/question/save":
                return self.send_json(save_live_question(body))
            if self.path=="/api/live/question/active":
                return self.send_json(set_live_question_active(body.get('id'),bool(body.get('active'))))
            if self.path=="/api/live/publish-current":
                return self.send_json(publish_current_package())
            if self.path=="/api/category/start":
                category=str(body.get("category") or "").strip()
                if not category:return self.send_json({"error":"Category is required."},400)
                with STATE_LOCK:
                    if CATEGORY_RUN["running"] or ACQUIRE["running"] or STATE["running"]:return self.send_json({"error":"A Content Studio job is already running."},409)
                requested=max(5,min(1000,int(body.get("requested") or 100)))
                audience=str(body.get("audience") or "mainstream").lower()
                if audience not in ("mainstream","balanced","deep"):audience="mainstream"
                focus=str(body.get("difficulty_focus") or "smart").lower()
                if focus not in ("smart","balanced","easy","medium","hard"):focus="smart"
                aw=max(1,min(4,int(body.get("acquire_workers") or 3)));mw=max(1,min(MAX_QUESTION_WORKERS,int(body.get("media_workers") or 4)));probes=max(1,min(8,int(body.get("probe_count") or 4)))
                threading.Thread(target=run_category_pipeline,args=(category,requested,audience,focus,aw,mw,probes,body.get("current") or {},body.get("terms") or []),daemon=True).start()
                return self.send_json({"ok":True,"category":category,"requested":requested})
            if self.path=="/api/category/cancel":
                with STATE_LOCK:CATEGORY_RUN["cancel"]=True;ACQUIRE["cancel"]=True;STATE["cancel"]=True
                return self.send_json({"ok":True})
            if self.path=="/api/acquire/start":
                selected=[str(x) for x in (body.get("templates") or [])]
                allowed={t["id"] for t in TEMPLATES};selected=[x for x in selected if x in allowed]
                if not selected:return self.send_json({"error":"Select at least one question template."},400)
                with STATE_LOCK:
                    if ACQUIRE["running"]:return self.send_json({"error":"Question acquisition is already running."},409)
                per=max(5,min(250,int(body.get("per_template") or 100)))
                mode=str(body.get("offset_mode") or "continue")
                if mode not in ("continue","zero","custom"):mode="continue"
                custom=max(0,int(body.get("custom_offset") or 0))
                workers=max(1,min(4,int(body.get("workers") or 3)))
                audience=str(body.get("audience") or "mainstream").lower()
                if audience not in ("mainstream","balanced","deep"):audience="mainstream"
                threading.Thread(target=run_acquisition,args=(selected,per,mode,custom,workers,audience),daemon=True).start()
                return self.send_json({"ok":True,"templates":len(selected),"requested":len(selected)*per,"workers":workers,"audience":audience})
            if self.path=="/api/acquire/cancel":
                with STATE_LOCK:ACQUIRE["cancel"]=True
                return self.send_json({"ok":True})
            if self.path=="/api/topic/preview":
                with STATE_LOCK:
                    if ACQUIRE["running"]:return self.send_json({"error":"Wait for the current acquisition run to finish first."},409)
                return self.send_json(topic_preview_payload(body))
            if self.path=="/api/topic/acquire":
                pid=str(body.get("preview_id") or "");cached=TOPIC_PREVIEWS.get(pid)
                if not cached:return self.send_json({"error":"Topic preview expired. Search again."},404)
                result=cached["result"];spec=cached["spec"]
                count=max(1,min(len(result.get("questions") or []),int(body.get("count") or len(result.get("questions") or []))))
                rows=(result.get("questions") or [])[:count];added,total=_append_questions(rows)
                pack=_save_topic_pack(result,{**spec,"name":body.get("name") or spec.get("name")},added)
                return self.send_json({"ok":True,"added":added,"package_total":total,"pack":pack})
            if self.path=="/api/topic/acquire-saved":
                tid=str(body.get("topic_id") or "")
                pack=next((x for x in (LOCAL_STATE.get("custom_topics") or []) if x.get("id")==tid),None)
                if not pack:return self.send_json({"error":"Saved topic pack not found."},404)
                depth=max(10,min(250,int(body.get("depth") or 100)))
                result=preview_topic(pack.get("terms") or [],pack.get("category") or "General Knowledge",depth,pack.get("audience") or "mainstream",bool(pack.get("include_numeric",True)),bool(pack.get("include_identify",True)),pack.get("offsets") or {})
                count=max(1,min(len(result.get("questions") or []),int(body.get("count") or min(100,len(result.get("questions") or []))))) if result.get("questions") else 0
                rows=(result.get("questions") or [])[:count];added,total=_append_questions(rows)
                saved=_save_topic_pack(result,pack,added)
                return self.send_json({"ok":True,"added":added,"found":result.get("question_count",0),"package_total":total,"pack":saved,"has_more":result.get("has_more",False)})
            if self.path=="/api/topic/delete-saved":
                tid=str(body.get("topic_id") or "")
                LOCAL_STATE["custom_topics"]=[x for x in (LOCAL_STATE.get("custom_topics") or []) if x.get("id")!=tid];save_local_state(LOCAL_STATE)
                return self.send_json({"ok":True})
            if self.path=="/api/content/derive-fun":
                with STATE_LOCK:
                    if ACQUIRE["running"]:return self.send_json({"error":"Wait for acquisition to finish first."},409)
                    base=[dict(q) for q in (ACQUIRE.get("questions") or [])]
                if not base:return self.send_json({"error":"Acquire questions first."},400)
                count=max(1,min(500,int(body.get("count") or 50)))
                style=str(body.get("style") or "mixed")
                rows=derive_fun_questions(base,count,style)
                added,total=_append_questions(rows)
                return self.send_json({"ok":True,"generated":len(rows),"added":added,"package_total":total,"compatible_sources":len(rows)})
            if self.path=="/api/content/clear-package":
                with STATE_LOCK:
                    ACQUIRE["questions"]=[];ACQUIRE["errors"]=[];ACQUIRE["events"]=[];ACQUIRE["finished_at"]=None
                    STATE.update({"running":False,"cancel":False,"total":0,"completed":0,"resolved":0,"missing":0,"started_at":None,"finished_at":None,"items":[],"job":None,"error":None})
                return self.send_json({"ok":True})
            if self.path=="/api/content/resolve":
                with STATE_LOCK:
                    if STATE["running"]:return self.send_json({"error":"Media resolution is already running."},409)
                    if not ACQUIRE.get("questions"):return self.send_json({"error":"Acquire questions first."},400)
                job=content_media_job()
                concurrency=max(1,min(MAX_QUESTION_WORKERS,int(body.get("concurrency") or 4)))
                probes=max(1,min(8,int(body.get("probe_count") or 4)))
                threading.Thread(target=run_job,args=(job,concurrency,probes),daemon=True).start()
                return self.send_json({"ok":True,"total":len(job.get("questions") or [])})
            if self.path=="/api/content/reset-offsets":
                LOCAL_STATE["offsets"]={};save_local_state(LOCAL_STATE)
                return self.send_json({"ok":True})
            if self.path=="/api/start":
                job=body.get("job") or {}
                if job.get("format")!="whatmod-trivia-media-job" or int(job.get("version") or 0)!=1:
                    return self.send_json({"error":"Invalid WhatMod Trivia media job file."},400)
                with STATE_LOCK:
                    if STATE["running"]:return self.send_json({"error":"A resolver job is already running."},409)
                concurrency=max(1,min(MAX_QUESTION_WORKERS,int(body.get("concurrency") or 4)))
                probes=max(1,min(8,int(body.get("probe_count") or 4)))
                threading.Thread(target=run_job,args=(job,concurrency,probes),daemon=True).start()
                return self.send_json({"ok":True,"total":len(job.get("questions") or [])})
            if self.path=="/api/cancel":
                with STATE_LOCK:STATE["cancel"]=True
                return self.send_json({"ok":True})
            if self.path=="/api/select":
                qid=str(body.get("question_id") or "");provider=str(body.get("provider") or "");key=str(body.get("provider_key") or "")
                with STATE_LOCK:
                    item=next((x for x in STATE["items"] if str(x.get("id"))==qid),None)
                    if not item:return self.send_json({"error":"Question result not found."},404)
                    cand=next((c for c in item.get("candidates") or [] if str(c.get("provider"))==provider and str(c.get("provider_key"))==key),None)
                    if not cand:return self.send_json({"error":"Candidate not found."},404)
                    item["selected"]={"provider":provider,"provider_key":key};item["selection_mode"]="manual";item["status"]="resolved"
                return self.send_json({"ok":True})
            return self.send_json({"error":"Not found"},404)
        except Exception as e:
            return self.send_json({"error":str(e)},500)

def find_port(preferred):
    for p in range(preferred,preferred+20):
        with socket.socket() as s:
            try:s.bind((HOST,p));return p
            except OSError:pass
    raise RuntimeError("No free local port found.")

if __name__=="__main__":
    port=find_port(PORT)
    server=ThreadingHTTPServer((HOST,port),Handler)
    url=f"http://{HOST}:{port}/"
    print("WhatMod Trivia Local Content Studio")
    print("Acquires questions + resolves media locally. Optional live Supabase management is available from Settings.")
    print("Open:",url)
    threading.Timer(0.8,lambda:webbrowser.open(url)).start()
    try:server.serve_forever()
    except KeyboardInterrupt:pass
