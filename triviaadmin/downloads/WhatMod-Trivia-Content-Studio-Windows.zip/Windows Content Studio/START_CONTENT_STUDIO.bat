@echo off
setlocal
cd /d "%~dp0"

echo Checking for an older WhatMod Trivia Content Studio...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='SilentlyContinue'; $looksLikeTrivia=$false; try { $r=Invoke-RestMethod -Uri 'http://127.0.0.1:8767/api/templates' -TimeoutSec 1; if($r.templates -and $r.provider){$looksLikeTrivia=$true} } catch {}; if($looksLikeTrivia){ $c=Get-NetTCPConnection -LocalAddress 127.0.0.1 -LocalPort 8767 -State Listen | Select-Object -First 1; if($c){ Write-Host 'Stopping previous Content Studio process' $c.OwningProcess; Stop-Process -Id $c.OwningProcess -Force; Start-Sleep -Milliseconds 500 } }"

where py >nul 2>nul
if %errorlevel%==0 (
  py -3 resolver_server.py
) else (
  where python >nul 2>nul
  if %errorlevel%==0 (
    python resolver_server.py
  ) else (
    echo Python 3 was not found.
    echo Install Python 3 from https://www.python.org/downloads/windows/ and try again.
    pause
  )
)
endlocal
