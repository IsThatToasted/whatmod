@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 resolver_server.py
) else (
  where python >nul 2>nul
  if %errorlevel%==0 (
    python resolver_server.py
  ) else (
    echo Python 3 was not found.
    echo Install Python 3 from https://www.python.org/downloads/windows/ and try again.
    pause
  )
)
endlocal
