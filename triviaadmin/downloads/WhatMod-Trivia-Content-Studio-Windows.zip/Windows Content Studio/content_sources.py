import json, re, time, threading, hashlib, random, math
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

API="https://www.wikidata.org/w/api.php"
USER_AGENT="WhatModTriviaContentStudio/3.0 (local admin utility; https://whatmod.com/trivia/)"
REQUEST_TIMEOUT=10
REQUEST_ATTEMPTS=2
SEARCH_PAGE=50
MAX_TEMPLATE_SECONDS=95
UNIT_CACHE={
    "Q11573":"m", "Q828224":"km", "Q174789":"mm", "Q174728":"cm", "Q3710":"ft", "Q218593":"in",
    "Q573":"days", "Q5151":"months", "Q23387":"weeks", "Q577":"years", "Q11574":"seconds",
    "Q21027105":"minutes", "Q25235":"minutes", "Q25224":"hours", "Q11570":"kg", "Q41803":"g",
    "1":""
}

# The acquisition engine deliberately uses broad, recognizable top-level categories that
# already exist in the Trivia UI. Each template is an independent generator and therefore
# has its own local cursor.
def T(id,name,category,difficulty,search,prop,kind,prompt,explanation,*,unit=None,minv=None,maxv=None,recommended=False,scan=7,note=""):
    return {"id":id,"name":name,"category":category,"difficulty":difficulty,"search":search,"prop":prop,"kind":kind,
            "prompt":prompt,"explanation":explanation,"unit":unit,"min":minv,"max":maxv,"recommended":recommended,
            "scan_multiplier":scan,"note":note}

def year_prompt(prefix):
    return lambda label,value,unit: prefix.format(label=label,value=value)

def year_explain(text):
    return lambda label,value,unit: text.format(label=label,value=value)

def metric_prompt(text):
    return lambda label,value,unit: text.format(label=label,value=value,unit=(unit or "units"))

def metric_explain(text):
    return lambda label,value,unit: text.format(label=label,value=format_number(value),unit=(unit or "units"))

TEMPLATES=[
  # ENTERTAINMENT
  T("film-release-year","Film release years","Movies & TV","medium","haswbstatement:P31=Q11424","P577","year",
    year_prompt('In what year was the film “{label}” first released?'),year_explain('The earliest recorded release year for “{label}” is {value}.'),recommended=True),
  T("film-runtime","Film runtimes","Movies & TV","medium","haswbstatement:P31=Q11424","P2047","quantity",
    metric_prompt('Approximately how long is the film “{label}”? (answer in {unit})'),metric_explain('Wikidata records a duration of about {value} {unit} for “{label}”.'),recommended=True),
  T("tv-release-year","TV series debut years","Movies & TV","medium","haswbstatement:P31=Q5398426","P577","year",
    year_prompt('In what year did the television series “{label}” first premiere?'),year_explain('The earliest recorded release year for “{label}” is {value}.'),recommended=True),
  T("tv-episode-count","TV series episode counts","Movies & TV","hard","haswbstatement:P31=Q5398426","P1113","quantity",
    metric_prompt('Approximately how many episodes does “{label}” have?'),metric_explain('Wikidata records about {value} episodes for “{label}”.'),unit="episodes",recommended=True),
  T("album-release-year","Album release years","Music","medium","haswbstatement:P31=Q482994|P31=Q208569","P577","year",
    year_prompt('In what year was the album “{label}” released?'),year_explain('The earliest recorded release year for “{label}” is {value}.'),recommended=True),
  T("song-release-year","Song release years","Music","medium","haswbstatement:P31=Q7366","P577","year",
    year_prompt('In what year was the song “{label}” released?'),year_explain('The earliest recorded release year for “{label}” is {value}.'),recommended=True),
  T("book-publication-year","Book publication years","Entertainment","medium","haswbstatement:P31=Q571","P577","year",
    year_prompt('In what year was “{label}” first published?'),year_explain('The earliest recorded publication year for “{label}” is {value}.')),
  T("book-page-count","Book page counts","Entertainment","hard","haswbstatement:P31=Q571","P1104","quantity",
    metric_prompt('Approximately how many pages are in “{label}”?'),metric_explain('Wikidata records about {value} pages for “{label}”.'),unit="pages"),
  T("actor-birth-year","Actor birth years","Pop Culture","medium","haswbstatement:P31=Q5 haswbstatement:P106=Q33999","P569","year",
    year_prompt('In what year was actor {label} born?'),year_explain('Wikidata records {label}’s birth year as {value}.')),
  T("musician-birth-year","Musician birth years","Music","medium","haswbstatement:P31=Q5 haswbstatement:P106=Q639669","P569","year",
    year_prompt('In what year was musician {label} born?'),year_explain('Wikidata records {label}’s birth year as {value}.')),

  # TECHNOLOGY
  T("video-game-release-year","Video game release years","General Gaming Knowledge","medium","haswbstatement:P31=Q7889","P577","year",
    year_prompt('In what year was the video game “{label}” first released?'),year_explain('The earliest recorded release year for “{label}” is {value}.'),recommended=True),
  T("programming-language-year","Programming language inception years","Technology","hard","haswbstatement:P31=Q9143","P571","year",
    year_prompt('Around what year was the programming language {label} introduced?'),year_explain('Wikidata records {label}’s inception year as {value}.'),recommended=True),
  T("operating-system-release","Operating system release years","Technology","medium","haswbstatement:P31=Q9135","P577","year",
    year_prompt('In what year was the operating system {label} first released?'),year_explain('The earliest recorded release year for {label} is {value}.')),
  T("website-inception","Website launch years","Internet Culture","medium","haswbstatement:P31=Q35127","P571","year",
    year_prompt('In what year was the website {label} established?'),year_explain('Wikidata records {label}’s inception year as {value}.')),
  T("software-release","Software release years","Technology","hard","haswbstatement:P31=Q7397","P577","year",
    year_prompt('In what year was {label} first released?'),year_explain('The earliest recorded release year for {label} is {value}.')),
  T("aircraft-first-flight","Aircraft first-flight years","Technology","hard","haswbstatement:P31=Q11436","P606","year",
    year_prompt('In what year did {label} make its first flight?'),year_explain('Wikidata records {label}’s first-flight year as {value}.'),recommended=True),
  T("aircraft-wingspan","Aircraft wingspans","Technology","hard","haswbstatement:P31=Q11436","P2050","quantity",
    metric_prompt('What is the approximate wingspan of {label}? (answer in {unit})'),metric_explain('Wikidata records a wingspan of about {value} {unit} for {label}.')),
  T("aircraft-length","Aircraft lengths","Technology","hard","haswbstatement:P31=Q11436","P2043","quantity",
    metric_prompt('Approximately how long is {label}? (answer in {unit})'),metric_explain('Wikidata records a length of about {value} {unit} for {label}.')),

  # BUSINESS
  T("business-inception-year","Company founding years","Business","medium","haswbstatement:P31=Q4830453","P571","year",
    year_prompt('In what year was {label} founded or established?'),year_explain('Wikidata records {label}’s inception year as {value}.'),recommended=True),
  T("business-employees","Company employee counts","Business","hard","haswbstatement:P31=Q4830453","P1128","quantity",
    metric_prompt('Approximately how many employees does {label} have?'),metric_explain('Wikidata records approximately {value} employees for {label}.'),unit="employees",recommended=True),
  T("university-inception","University founding years","Business","hard","haswbstatement:P31=Q3918","P571","year",
    year_prompt('In what year was {label} founded?'),year_explain('Wikidata records {label}’s inception year as {value}.')),
  T("museum-inception","Museum founding years","Business","hard","haswbstatement:P31=Q33506","P571","year",
    year_prompt('In what year was {label} established?'),year_explain('Wikidata records {label}’s inception year as {value}.')),
  T("hospital-inception","Hospital founding years","Business","hard","haswbstatement:P31=Q16917","P571","year",
    year_prompt('In what year was {label} established?'),year_explain('Wikidata records {label}’s inception year as {value}.')),
  T("newspaper-inception","Newspaper founding years","Business","hard","haswbstatement:P31=Q11032","P571","year",
    year_prompt('In what year was the newspaper “{label}” established?'),year_explain('Wikidata records “{label}” as beginning in {value}.')),

  # HISTORY
  T("person-birth-year","Notable people birth years","History","medium","haswbstatement:P31=Q5","P569","year",
    year_prompt('In what year was {label} born?'),year_explain('Wikidata records {label}’s birth year as {value}.'),recommended=True),
  T("person-death-year","Notable people death years","History","medium","haswbstatement:P31=Q5","P570","year",
    year_prompt('In what year did {label} die?'),year_explain('Wikidata records {label}’s death year as {value}.')),
  T("scientist-birth-year","Scientists’ birth years","History","hard","haswbstatement:P31=Q5 haswbstatement:P106=Q901","P569","year",
    year_prompt('In what year was scientist {label} born?'),year_explain('Wikidata records {label}’s birth year as {value}.')),
  T("battle-year","Battle dates","History","hard","haswbstatement:P31=Q178561","P585","year",
    year_prompt('In what year did the Battle of {label} occur?'),year_explain('Wikidata records the event year as {value}.'),scan=10),

  # GEOGRAPHY
  T("city-population","City populations","Geography","medium","haswbstatement:P31=Q515","P1082","quantity",
    metric_prompt('Approximately how many people live in {label}?'),metric_explain('Wikidata records a population of about {value} for {label}.'),unit="people",recommended=True),
  T("city-elevation","City elevations","Geography","hard","haswbstatement:P31=Q515","P2044","quantity",
    metric_prompt('Approximately how high above sea level is {label}? (answer in {unit})'),metric_explain('Wikidata records an elevation of about {value} {unit} for {label}.')),
  T("country-population","Country populations","Geography","medium","haswbstatement:P31=Q6256","P1082","quantity",
    metric_prompt('Approximately what is the population of {label}?'),metric_explain('Wikidata records a population of about {value} for {label}.'),unit="people",recommended=True),
  T("country-area","Country land areas","Geography","medium","haswbstatement:P31=Q6256","P2046","quantity",
    metric_prompt('Approximately what area does {label} cover? (answer in {unit})'),metric_explain('Wikidata records an area of about {value} {unit} for {label}.')),
  T("island-area","Island areas","Geography","hard","haswbstatement:P31=Q23442","P2046","quantity",
    metric_prompt('Approximately what area does {label} cover? (answer in {unit})'),metric_explain('Wikidata records an area of about {value} {unit} for {label}.')),
  T("lake-area","Lake areas","Geography","hard","haswbstatement:P31=Q23397","P2046","quantity",
    metric_prompt('Approximately what is the surface area of {label}? (answer in {unit})'),metric_explain('Wikidata records an area of about {value} {unit} for {label}.')),
  T("river-length","River lengths","Geography","medium","haswbstatement:P31=Q4022","P2043","quantity",
    metric_prompt('Approximately how long is {label}? (answer in {unit})'),metric_explain('Wikidata records a length of about {value} {unit} for {label}.'),recommended=True),
  T("mountain-elevation","Mountain elevations","Geography","medium","haswbstatement:P31=Q8502","P2044","quantity",
    metric_prompt('Approximately how high above sea level is {label}? (answer in {unit})'),metric_explain('Wikidata records an elevation of about {value} {unit} for {label}.'),recommended=True),
  T("building-height","Building heights","Geography","hard","haswbstatement:P31=Q41176","P2048","quantity",
    metric_prompt('Approximately how tall is {label}? (answer in {unit})'),metric_explain('Wikidata records a height of about {value} {unit} for {label}.')),
  T("skyscraper-height","Skyscraper heights","Geography","medium","haswbstatement:P31=Q11303","P2048","quantity",
    metric_prompt('Approximately how tall is {label}? (answer in {unit})'),metric_explain('Wikidata records a height of about {value} {unit} for {label}.'),recommended=True),
  T("bridge-length","Bridge lengths","Geography","hard","haswbstatement:P31=Q12280","P2043","quantity",
    metric_prompt('Approximately how long is {label}? (answer in {unit})'),metric_explain('Wikidata records a length of about {value} {unit} for {label}.')),
  T("airport-elevation","Airport elevations","Geography","hard","haswbstatement:P31=Q1248784","P2044","quantity",
    metric_prompt('Approximately how high above sea level is {label}? (answer in {unit})'),metric_explain('Wikidata records an elevation of about {value} {unit} for {label}.')),

  # SPORTS
  T("stadium-capacity","Stadium capacities","Sports","medium","haswbstatement:P31=Q483110","P1083","quantity",
    metric_prompt('Approximately how many people can {label} hold?'),metric_explain('Wikidata records a maximum capacity of about {value} for {label}.'),unit="people",recommended=True),
  T("sports-club-inception","Sports club founding years","Sports","medium","haswbstatement:P31=Q847017","P571","year",
    year_prompt('In what year was {label} founded?'),year_explain('Wikidata records {label}’s inception year as {value}.')),
  T("football-club-inception","Football club founding years","Sports","medium","haswbstatement:P31=Q476028","P571","year",
    year_prompt('In what year was {label} founded?'),year_explain('Wikidata records {label}’s inception year as {value}.'),recommended=True),
  T("athlete-birth-year","Athlete birth years","Sports","medium","haswbstatement:P31=Q5 haswbstatement:P106=Q2066131","P569","year",
    year_prompt('In what year was athlete {label} born?'),year_explain('Wikidata records {label}’s birth year as {value}.')),

  # SCIENCE
  T("element-atomic-number","Chemical element atomic numbers","Science","easy","haswbstatement:P31=Q11344","P1086","quantity",
    metric_prompt('What is the atomic number of {label}?'),metric_explain('The atomic number of {label} is {value}.'),unit="",recommended=True,scan=4),
  T("element-discovery-year","Chemical element discovery years","Science","hard","haswbstatement:P31=Q11344","P575","year",
    year_prompt('Around what year was {label} discovered?'),year_explain('Wikidata records {label}’s discovery year as {value}.'),scan=6),
  T("element-melting-point","Chemical element melting points","Science","hard","haswbstatement:P31=Q11344","P2101","quantity",
    metric_prompt('Approximately what is the melting point of {label}? (answer in {unit})'),metric_explain('Wikidata records a melting point of about {value} {unit} for {label}.'),scan=6),
  T("element-boiling-point","Chemical element boiling points","Science","hard","haswbstatement:P31=Q11344","P2102","quantity",
    metric_prompt('Approximately what is the boiling point of {label}? (answer in {unit})'),metric_explain('Wikidata records a boiling point of about {value} {unit} for {label}.'),scan=6),

  # SPACE
  T("planet-orbital-period","Planet orbital periods","Space","medium","haswbstatement:P31=Q634","P2146","quantity",
    metric_prompt('Approximately how long is {label}’s orbital period? (answer in {unit})'),metric_explain('Wikidata records an orbital period of about {value} {unit} for {label}.'),recommended=True,scan=5),
  T("planet-diameter","Planet diameters","Space","medium","haswbstatement:P31=Q634","P2386","quantity",
    metric_prompt('Approximately what is the diameter of {label}? (answer in {unit})'),metric_explain('Wikidata records a diameter of about {value} {unit} for {label}.'),scan=5),
  T("exoplanet-discovery-year","Exoplanet discovery years","Space","hard","haswbstatement:P31=Q44559","P575","year",
    year_prompt('In what year was the exoplanet {label} discovered?'),year_explain('Wikidata records {label}’s discovery year as {value}.'),scan=8),
  T("exoplanet-orbital-period","Exoplanet orbital periods","Space","hard","haswbstatement:P31=Q44559","P2146","quantity",
    metric_prompt('Approximately how long is {label}’s orbital period? (answer in {unit})'),metric_explain('Wikidata records an orbital period of about {value} {unit} for {label}.'),scan=8),

  # ANIMALS — sparse on Wikidata, so these are opt-in and aggressively bounded.
  T("animal-body-mass","Animal body masses","Animals","medium","haswbstatement:P31=Q16521 haswbstatement:P2067","P2067","quantity",
    metric_prompt('Approximately how much does an adult {label} weigh? (answer in {unit})'),metric_explain('Wikidata records a representative mass of about {value} {unit} for {label}.'),recommended=True,scan=18,note="Useful for fun comparison questions"),
  T("animal-life-expectancy","Animal life expectancies","Animals","hard","haswbstatement:P31=Q16521","P2250","quantity",
    metric_prompt('Approximately what is the life expectancy of {label}? (answer in {unit})'),metric_explain('Wikidata records a life expectancy of about {value} {unit} for {label}.'),scan=18,note="Sparse data"),
  T("animal-gestation","Animal gestation periods","Animals","hard","haswbstatement:P31=Q16521","P3063","quantity",
    metric_prompt('Approximately how long is the gestation period of {label}? (answer in {unit})'),metric_explain('Wikidata records a gestation period of about {value} {unit} for {label}.'),scan=18,note="Sparse data"),
  T("animal-wingspan","Animal wingspans","Animals","hard","haswbstatement:P31=Q16521","P2050","quantity",
    metric_prompt('Approximately what is the wingspan of {label}? (answer in {unit})'),metric_explain('Wikidata records a wingspan of about {value} {unit} for {label}.'),scan=18,note="Sparse data"),
  T("animal-litter-size","Animal litter sizes","Animals","hard","haswbstatement:P31=Q16521","P7725","quantity",
    metric_prompt('About how many young are typically in a litter for {label}?'),metric_explain('Wikidata records a litter size of about {value} for {label}.'),unit="young",scan=18,note="Sparse data"),
  T("animal-incubation","Animal egg incubation periods","Animals","hard","haswbstatement:P31=Q16521","P7770","quantity",
    metric_prompt('Approximately how long is the egg incubation period for {label}? (answer in {unit})'),metric_explain('Wikidata records an incubation period of about {value} {unit} for {label}.'),scan=18,note="Sparse data"),

  # RELATABLE / INTERNET-FIRST
  T("internet-meme-inception","Internet meme inception years","Brainrot","medium","haswbstatement:P31=Q2927074","P571","year",
    year_prompt('Around what year did the meme “{label}” originate?'),year_explain('Wikidata records “{label}” as originating around {value}.'),recommended=True,scan=12,note="Internet culture"),
  T("internet-meme-publication","Internet meme publication years","Brainrot","medium","haswbstatement:P31=Q2927074","P577","year",
    year_prompt('Around what year was the meme “{label}” first published or released?'),year_explain('The earliest recorded publication year for “{label}” is {value}.'),scan=12,note="Internet culture"),
  T("game-console-release","Game console release years","General Gaming Knowledge","easy","haswbstatement:P31=Q8076","P577","year",
    year_prompt('In what year was the game console {label} first released?'),year_explain('The earliest recorded release year for {label} is {value}.'),recommended=True,note="Mainstream gaming"),
  T("general-city-population","Famous city populations","General Knowledge","easy","haswbstatement:P31=Q515","P1082","quantity",
    metric_prompt('Approximately how many people live in {label}?'),metric_explain('Wikidata records a population of about {value} for {label}.'),unit="people",recommended=True,note="Mainstream general knowledge")
]

TEMPLATE_MAP={x["id"]:x for x in TEMPLATES}

def format_number(v):
    try:
        n=float(v)
        if abs(n)>=1_000_000:return f"{n:,.0f}"
        return f"{n:,.4f}".rstrip("0").rstrip(".")
    except:return str(v)

def api_json(params,timeout=REQUEST_TIMEOUT,attempts=REQUEST_ATTEMPTS):
    params=dict(params);params.setdefault("format","json");params.setdefault("formatversion","2")
    url=API+"?"+urlencode(params)
    last=None
    for attempt in range(attempts):
        try:
            req=Request(url,headers={"Accept":"application/json","User-Agent":USER_AGENT})
            with urlopen(req,timeout=timeout) as r:
                return json.loads(r.read().decode("utf-8","replace"))
        except HTTPError as e:
            last=e
            if e.code in (429,500,502,503,504) and attempt+1<attempts:
                time.sleep(0.8*(2**attempt));continue
            raise
        except (URLError,TimeoutError,OSError,ValueError) as e:
            last=e
            if attempt+1<attempts:
                time.sleep(0.6*(2**attempt));continue
            raise
    raise last

def search_qids(search,offset,limit=SEARCH_PAGE):
    body=api_json({"action":"query","list":"search","srsearch":search,"srnamespace":"0","srlimit":str(min(50,max(1,limit))),"sroffset":str(max(0,offset))})
    rows=(body.get("query") or {}).get("search") or []
    qids=[str(x.get("title") or "") for x in rows if re.fullmatch(r"Q\d+",str(x.get("title") or ""))]
    nxt=(body.get("continue") or {}).get("sroffset")
    return qids,(int(nxt) if nxt is not None else None)

def fetch_entities(qids):
    if not qids:return {}
    out={}
    for i in range(0,len(qids),50):
        ids=qids[i:i+50]
        body=api_json({"action":"wbgetentities","ids":"|".join(ids),"props":"labels|descriptions|claims|sitelinks","languages":"en","languagefallback":"1"})
        out.update(body.get("entities") or {})
    return out

def fetch_unit_labels(qids):
    missing=[q for q in sorted(set(qids)) if q and q not in UNIT_CACHE]
    for i in range(0,len(missing),50):
        ids=missing[i:i+50]
        try:
            body=api_json({"action":"wbgetentities","ids":"|".join(ids),"props":"labels","languages":"en","languagefallback":"1"})
            for qid,ent in (body.get("entities") or {}).items():
                label=((ent.get("labels") or {}).get("en") or {}).get("value")
                if label:UNIT_CACHE[qid]=str(label)
        except Exception:
            pass
    return {q:UNIT_CACHE.get(q,q) for q in qids}

def label_of(ent,qid):
    label=((ent.get("labels") or {}).get("en") or {}).get("value")
    return str(label or qid).strip()

def description_of(ent):
    return str((((ent.get("descriptions") or {}).get("en") or {}).get("value") or "")).strip()

def sitelink_count(ent):
    return len(ent.get("sitelinks") or {})

def passes_audience(ent,audience="mainstream"):
    links=sitelink_count(ent)
    if "enwiki" not in (ent.get("sitelinks") or {}): return False
    mode=str(audience or "mainstream").lower()
    if mode=="mainstream": return links>=12
    if mode=="balanced": return links>=4
    return links>=1

def qualifier_year(statement):
    qs=statement.get("qualifiers") or {}
    for prop in ("P585","P580","P577","P571"):
        vals=qs.get(prop) or []
        for s in vals:
            val=(s.get("datavalue") or {}).get("value")
            if isinstance(val,dict) and val.get("time"):
                m=re.match(r"^([+-]?\d+)-",str(val["time"]))
                if m:
                    try:return int(m.group(1))
                    except:pass
    return -999999

def claim_candidates(ent,prop):
    claims=(ent.get("claims") or {}).get(prop) or []
    claims=[x for x in claims if x.get("rank")!="deprecated" and ((x.get("mainsnak") or {}).get("snaktype")=="value")]
    return sorted(claims,key=lambda s:(2 if s.get("rank")=="preferred" else 1,qualifier_year(s)),reverse=True)

def parse_time(statement):
    val=((statement.get("mainsnak") or {}).get("datavalue") or {}).get("value")
    if not isinstance(val,dict):return None
    m=re.match(r"^([+-]?\d+)-",str(val.get("time") or ""))
    if not m:return None
    try:return int(m.group(1))
    except:return None

def parse_quantity(statement):
    val=((statement.get("mainsnak") or {}).get("datavalue") or {}).get("value")
    if isinstance(val,dict) and "amount" in val:
        try:amount=float(str(val.get("amount")).replace("+",""))
        except:return None,None
        unit=str(val.get("unit") or "1")
        m=re.search(r"/(Q\d+)$",unit)
        return amount,(m.group(1) if m else ("1" if unit=="1" else None))
    if isinstance(val,(int,float)):return float(val),"1"
    try:return float(val),"1"
    except:return None,None

def choose_value(template,ent):
    claims=claim_candidates(ent,template["prop"])
    if not claims:return None,None
    if template["kind"]=="year":
        years=[parse_time(c) for c in claims];years=[y for y in years if y is not None]
        if not years:return None,None
        # Release/inception/discovery questions are most useful with the earliest recorded date.
        v=min(years)
        if v<1 or v>3000:return None,None
        return v,"year"
    for c in claims:
        v,u=parse_quantity(c)
        if v is None:continue
        if template.get("min") is not None and v<float(template["min"]):continue
        if template.get("max") is not None and v>float(template["max"]):continue
        return v,u
    return None,None

def make_question(template,qid,ent,value,unit_label):
    label=label_of(ent,qid)
    unit=template.get("unit") if template.get("unit") is not None else unit_label
    unit=str(unit or "")
    canonical=f"wikidata:{template['id']}:{qid}"
    return {
      "id":canonical,"canonical_key":canonical,"category":template["category"],"difficulty":template["difficulty"],
      "question_type":"numeric","prompt":template["prompt"](label,value,unit),"context":None,"unit":unit,
      "options":None,"answer_numeric":value,"answer_text":None,"correct_option":None,
      "explanation":template["explanation"](label,value,unit),"source_url":f"https://www.wikidata.org/wiki/{qid}",
      "source_type":"wikidata","source_entity_id":qid,"media_query":label
    }

def fetch_template(template_id,limit,offset,progress=None,cancel=None,audience="mainstream"):
    template=TEMPLATE_MAP[template_id]
    target=max(1,int(limit));cursor=max(0,int(offset));out=[];seen=set();scanned=0
    max_scan=max(150,target*int(template.get("scan_multiplier") or 7))
    started=time.monotonic();exhausted=False
    while len(out)<target and scanned<max_scan and not exhausted:
        if cancel and cancel():break
        if time.monotonic()-started>MAX_TEMPLATE_SECONDS:
            raise TimeoutError(f"Template exceeded {MAX_TEMPLATE_SECONDS}s safety limit after scanning {scanned} Wikidata items")
        want=min(SEARCH_PAGE,max_scan-scanned)
        if progress:progress({"stage":"search","template":template_id,"name":template["name"],"count":len(out),"scanned":scanned,"offset":cursor,"message":f"Searching {template['name']} · {len(out)}/{target} ready"})
        qids,next_cursor=search_qids(template["search"],cursor,want)
        if not qids:
            exhausted=True;break
        entities=fetch_entities(qids)
        unit_ids=set();pending=[]
        for qid in qids:
            if cancel and cancel():break
            ent=entities.get(qid) or {}
            # Familiarity gate: Mainstream requires much broader Wikipedia coverage,
            # which removes a large share of niche/placeholder entities.
            if not passes_audience(ent,audience): continue
            value,unit_qid=choose_value(template,ent)
            if value is None:continue
            canonical=f"wikidata:{template_id}:{qid}"
            if canonical in seen:continue
            seen.add(canonical);pending.append((qid,ent,value,unit_qid))
            if unit_qid and unit_qid!="1":unit_ids.add(unit_qid)
        labels=fetch_unit_labels(unit_ids) if unit_ids else {}
        for qid,ent,value,unit_qid in pending:
            unit_label=labels.get(unit_qid,UNIT_CACHE.get(unit_qid,"")) if unit_qid else ""
            out.append(make_question(template,qid,ent,value,unit_label))
            if len(out)>=target:break
        scanned+=len(qids)
        if progress:progress({"stage":"scan","template":template_id,"name":template["name"],"count":len(out),"scanned":scanned,"offset":cursor,"message":f"{template['name']}: {len(out)}/{target} usable from {scanned} scanned"})
        if next_cursor is None or next_cursor<=cursor:exhausted=True
        else:cursor=next_cursor
    return out,cursor,scanned

def acquire(selected,per_template,offsets,progress=None,cancel=None,max_workers=3,audience="mainstream"):
    selected=[x for x in selected if x in TEMPLATE_MAP]
    jobs=[(tid,max(0,int(offsets.get(tid,0)))) for tid in selected]
    results=[];errors=[];new_offsets=dict(offsets);lock=threading.Lock();completed=0

    def emit(done,total,event):
        if progress:progress(done,total,event)

    def one(job):
        tid,offset=job;tmpl=TEMPLATE_MAP[tid];t0=time.monotonic()
        emit(0,len(jobs),{"stage":"start","template":tid,"name":tmpl["name"],"count":0,"scanned":0,"offset":offset,"message":f"Starting {tmpl['name']}"})
        rows,next_offset,scanned=fetch_template(tid,per_template,offset,
            progress=lambda ev: emit(-1,len(jobs),ev),cancel=cancel,audience=audience)
        return tid,offset,rows,next_offset,scanned,time.monotonic()-t0

    with ThreadPoolExecutor(max_workers=max(1,min(int(max_workers or 3),4,len(jobs) or 1))) as ex:
        futures={ex.submit(one,j):j for j in jobs}
        for fut in as_completed(futures):
            tid,offset=futures[fut];tmpl=TEMPLATE_MAP[tid]
            try:
                _,_,rows,next_offset,scanned,duration=fut.result()
                results.extend(rows);new_offsets[tid]=max(offset+1,int(next_offset or offset+per_template))
                event={"stage":"done","template":tid,"name":tmpl["name"],"ok":True,"count":len(rows),"scanned":scanned,"offset":offset,"seconds":round(duration,1),"message":f"{tmpl['name']}: {len(rows)} acquired from {scanned} scanned"}
            except Exception as e:
                errors.append({"template":tid,"name":tmpl["name"],"error":str(e)})
                event={"stage":"error","template":tid,"name":tmpl["name"],"ok":False,"count":0,"offset":offset,"error":str(e),"message":f"{tmpl['name']} failed: {e}"}
            with lock:completed+=1;done=completed
            emit(done,len(jobs),event)
            if cancel and cancel():
                for f in futures:f.cancel()
                break
    dedup={q["canonical_key"]:q for q in results}
    return list(dedup.values()),new_offsets,errors


# ---------------------------------------------------------------------------
# Topic Discovery / Build-a-Category
# ---------------------------------------------------------------------------
TOPIC_FACTS=[
  {"id":"release-year","prop":"P577","kind":"year","unit":"year","prompt":"In what year was {label} released or published?","explain":"The earliest recorded release/publication year for {label} is {value}."},
  {"id":"inception-year","prop":"P571","kind":"year","unit":"year","prompt":"In what year was {label} founded, launched, or created?","explain":"Wikidata records {label} as beginning in {value}."},
  {"id":"birth-year","prop":"P569","kind":"year","unit":"year","prompt":"In what year was {label} born?","explain":"Wikidata records {label}’s birth year as {value}."},
  {"id":"death-year","prop":"P570","kind":"year","unit":"year","prompt":"In what year did {label} die?","explain":"Wikidata records {label}’s death year as {value}."},
  {"id":"population","prop":"P1082","kind":"quantity","unit":"people","prompt":"Approximately how many people are associated with {label}?","explain":"Wikidata records a population of about {value} for {label}."},
  {"id":"mass","prop":"P2067","kind":"quantity","unit":None,"prompt":"Approximately how much does {label} weigh? (answer in {unit})","explain":"Wikidata records a mass of about {value} {unit} for {label}."},
  {"id":"duration","prop":"P2047","kind":"quantity","unit":None,"prompt":"Approximately how long is {label}? (answer in {unit})","explain":"Wikidata records a duration of about {value} {unit} for {label}."},
  {"id":"height","prop":"P2048","kind":"quantity","unit":None,"prompt":"Approximately how tall is {label}? (answer in {unit})","explain":"Wikidata records a height of about {value} {unit} for {label}."},
  {"id":"elevation","prop":"P2044","kind":"quantity","unit":None,"prompt":"Approximately what is the elevation of {label}? (answer in {unit})","explain":"Wikidata records an elevation of about {value} {unit} for {label}."},
  {"id":"area","prop":"P2046","kind":"quantity","unit":None,"prompt":"Approximately what is the area of {label}? (answer in {unit})","explain":"Wikidata records an area of about {value} {unit} for {label}."},
  {"id":"length","prop":"P2043","kind":"quantity","unit":None,"prompt":"Approximately how long is {label}? (answer in {unit})","explain":"Wikidata records a length of about {value} {unit} for {label}."},
  {"id":"employees","prop":"P1128","kind":"quantity","unit":"employees","prompt":"Approximately how many employees does {label} have?","explain":"Wikidata records about {value} employees for {label}."},
  {"id":"episodes","prop":"P1113","kind":"quantity","unit":"episodes","prompt":"Approximately how many episodes does {label} have?","explain":"Wikidata records about {value} episodes for {label}."},
  {"id":"pages","prop":"P1104","kind":"quantity","unit":"pages","prompt":"Approximately how many pages are in {label}?","explain":"Wikidata records about {value} pages for {label}."},
  {"id":"wingspan","prop":"P2050","kind":"quantity","unit":None,"prompt":"Approximately what is the wingspan of {label}? (answer in {unit})","explain":"Wikidata records a wingspan of about {value} {unit} for {label}."},
  {"id":"life-expectancy","prop":"P2250","kind":"quantity","unit":None,"prompt":"Approximately what is the life expectancy associated with {label}? (answer in {unit})","explain":"Wikidata records a life expectancy of about {value} {unit} for {label}."},
]

def normalize_terms(value):
    if isinstance(value,(list,tuple)): raw=[str(x) for x in value]
    else: raw=re.split(r"[,;\n]+",str(value or ""))
    out=[]
    for x in raw:
        x=re.sub(r"\s+"," ",x).strip()
        if x and x.lower() not in {y.lower() for y in out}: out.append(x)
    return out[:20]

def topic_id_for(category,terms):
    seed=(str(category or "Custom").strip().lower()+"|"+"|".join(x.lower() for x in normalize_terms(terms))).encode()
    return "topic-"+hashlib.sha1(seed).hexdigest()[:12]

def _generic_fact_value(fact,ent):
    claims=claim_candidates(ent,fact["prop"])
    if not claims:return None,None
    if fact["kind"]=="year":
        vals=[parse_time(c) for c in claims];vals=[v for v in vals if v is not None and 1<=v<=3000]
        return (min(vals),"year") if vals else (None,None)
    for c in claims:
        v,u=parse_quantity(c)
        if v is not None:return v,u
    return None,None

def _stable_options(correct,others,seed):
    pool=[]
    for x in others:
        if x and x!=correct and x not in pool: pool.append(x)
    rnd=random.Random(int(hashlib.sha1(seed.encode()).hexdigest()[:12],16))
    rnd.shuffle(pool)
    opts=[correct]+pool[:3]
    if len(opts)<4:return None,None
    rnd.shuffle(opts)
    return opts,opts.index(correct)

def preview_topic(terms,category="General Knowledge",depth=100,audience="mainstream",include_numeric=True,include_identify=True,offsets=None):
    terms=normalize_terms(terms)
    if not terms: raise ValueError("Enter at least one topic or search phrase.")
    category=re.sub(r"\s+"," ",str(category or "General Knowledge")).strip()[:60] or "General Knowledge"
    depth=max(10,min(250,int(depth or 100)))
    offsets={str(k):max(0,int(v or 0)) for k,v in (offsets or {}).items()}
    all_qids=[];next_offsets={};term_meta=[]
    for term in terms:
        cursor=offsets.get(term,0);remaining=depth;found=[];more=False
        while remaining>0:
            qids,nxt=search_qids(term,cursor,min(SEARCH_PAGE,remaining))
            if not qids:break
            found.extend(qids);remaining-=len(qids)
            if nxt is None or nxt<=cursor:cursor+=len(qids);break
            cursor=nxt;more=True
        next_offsets[term]=cursor
        term_meta.append({"term":term,"entities_scanned":len(found),"next_offset":cursor,"has_more":more})
        all_qids.extend(found)
    qids=[]
    for q in all_qids:
        if q not in qids:qids.append(q)
    entities=fetch_entities(qids)
    eligible=[]
    for qid in qids:
        ent=entities.get(qid) or {}
        if passes_audience(ent,audience):eligible.append((qid,ent))
    unit_ids=set();numeric_pending=[]
    if include_numeric:
        for qid,ent in eligible:
            for fact in TOPIC_FACTS:
                value,unit_qid=_generic_fact_value(fact,ent)
                if value is None:continue
                numeric_pending.append((qid,ent,fact,value,unit_qid))
                if unit_qid and unit_qid not in ("1","year") and fact.get("unit") is None:unit_ids.add(unit_qid)
    unit_labels=fetch_unit_labels(unit_ids) if unit_ids else {}
    tid=topic_id_for(category,terms);questions=[]
    for qid,ent,fact,value,unit_qid in numeric_pending:
        label=label_of(ent,qid);unit=fact.get("unit") or unit_labels.get(unit_qid,UNIT_CACHE.get(unit_qid,"")) or ""
        canonical=f"wikidata:{tid}:{fact['id']}:{qid}"
        questions.append({
          "id":canonical,"canonical_key":canonical,"category":category,"difficulty":"medium","question_type":"numeric",
          "prompt":fact["prompt"].format(label=label,value=value,unit=unit or "units"),"context":None,"unit":unit,
          "options":None,"answer_numeric":value,"answer_text":None,"correct_option":None,
          "explanation":fact["explain"].format(label=label,value=format_number(value),unit=unit or "units"),
          "source_url":f"https://www.wikidata.org/wiki/{qid}","source_type":"wikidata_topic","source_entity_id":qid,"media_query":label,
          "topic_pack_id":tid,"topic_terms":terms,"source_popularity":sitelink_count(ent)
        })
    if include_identify and len(eligible)>=4:
        labels=[label_of(ent,qid) for qid,ent in eligible]
        for qid,ent in eligible:
            desc=description_of(ent)
            if len(desc)<12:continue
            correct=label_of(ent,qid)
            options,idx=_stable_options(correct,[x for x in labels if x!=correct],f"{tid}:{qid}:identify")
            if not options:continue
            canonical=f"wikidata:{tid}:identify:{qid}"
            questions.append({
              "id":canonical,"canonical_key":canonical,"category":category,"difficulty":"easy" if audience=="mainstream" else "medium",
              "question_type":"multiple_choice","prompt":f"Which of these best matches this description: “{desc}”?","context":None,"unit":"",
              "options":options,"answer_numeric":None,"answer_text":None,"correct_option":idx,
              "explanation":f"Wikidata describes {correct} as {desc}.","source_url":f"https://www.wikidata.org/wiki/{qid}",
              "source_type":"wikidata_topic","source_entity_id":qid,"media_query":correct,
              "topic_pack_id":tid,"topic_terms":terms,"source_popularity":sitelink_count(ent)
            })
    dedup={q["canonical_key"]:q for q in questions};questions=list(dedup.values())
    questions.sort(key=lambda q:(-int(q.get("source_popularity") or 0),q.get("question_type")!="multiple_choice",q.get("prompt") or ""))
    numeric=sum(1 for q in questions if q["question_type"]=="numeric")
    identify=sum(1 for q in questions if q["question_type"]=="multiple_choice")
    return {
      "topic_id":tid,"category":category,"terms":terms,"audience":audience,"depth":depth,
      "questions":questions,"question_count":len(questions),"numeric_count":numeric,"identify_count":identify,
      "entity_count":len(eligible),"entities_scanned":len(qids),"next_offsets":next_offsets,"term_meta":term_meta,
      "has_more":any(x.get("has_more") for x in term_meta)
    }


# ---------------------------------------------------------------------------
# Fun derived questions
# ---------------------------------------------------------------------------
# These questions are never invented from thin air. They are calculated from an
# already-sourced numeric question plus either an authoritative published
# specification or an explicit reference quantity stated in the prompt.
# Base units: kilograms, metres, seconds, or raw counts.
FUN_REFERENCES = {
  "mass": [
    {
      "id":"tennis-ball","label":"regulation tennis balls","value":0.0577,
      "prompt":"About how many regulation tennis balls would weigh the same as {label}?",
      "source_url":"https://www.itftennis.com/media/4572/2021-wta-rulebook.pdf",
      "source_note":"ITF rules specify a tennis-ball mass of 56.0–59.4 g; this calculation uses the midpoint, 57.7 g."
    },
    {
      "id":"soccer-ball","label":"regulation footballs","value":0.430,
      "prompt":"About how many regulation footballs (soccer balls) would weigh the same as {label}?",
      "source_url":"https://backup.theifab.com/laws/latest/the-ball/",
      "source_note":"IFAB Law 2 specifies 410–450 g; this calculation uses the midpoint, 430 g."
    },
    {
      "id":"us-quarter","label":"U.S. quarters","value":0.005670,
      "prompt":"About how many U.S. quarters would weigh the same as {label}?",
      "source_url":"https://www.usmint.gov/learn/coins-and-medals/circulating-coins/quarter",
      "source_note":"The U.S. Mint lists a circulating quarter at 5.670 g."
    },
    {
      "id":"iphone-15-pro-max-mass","label":"iPhone 15 Pro Max phones","value":0.221,
      "prompt":"About how many iPhone 15 Pro Max phones would weigh the same as {label}?",
      "source_url":"https://support.apple.com/en-ie/111828",
      "source_note":"Apple lists the iPhone 15 Pro Max at 221 g."
    },
  ],
  "length": [
    {
      "id":"iphone-15-pro-max-height","label":"iPhone 15 Pro Max phones","value":0.1599,
      "prompt":"Placed end-to-end, about how many iPhone 15 Pro Max phones would match the {measure} of {label}?",
      "source_url":"https://support.apple.com/en-ie/111828",
      "source_note":"Apple lists the iPhone 15 Pro Max height as 159.9 mm."
    },
    {
      "id":"basketball-hoop-height","label":"basketball-hoop heights","value":3.05,
      "prompt":"About how many regulation basketball-hoop heights equal the {measure} of {label}?",
      "source_url":"https://refereeing.fiba.basketball/images/docs/doc/5ebfbbb5a9f17da0f62ab2174cebaa85/FIBABasketballEquipment2018.pdf",
      "source_note":"FIBA specifies the top edge of the ring at 3.050 m above the playing floor."
    },
  ],
  "distance": [
    {
      "id":"standard-track","label":"400 m track laps","value":400.0,
      "prompt":"About how many laps of a 400 m standard track equal the length of {label}?",
      "source_url":"https://worldathletics.org/about-iaaf/documents/technical-information",
      "source_note":"World Athletics defines the nominal standard outdoor track length as 400 m."
    },
  ],
  "duration": [
    {
      "id":"60-second-clip","label":"60-second clips","value":60.0,
      "prompt":"About how many 60-second clips would fit into the measured duration for {label}?",
      "source_url":None,
      "source_note":"A 60-second clip is an explicit reference quantity defined in the question."
    },
    {
      "id":"one-hour","label":"hours","value":3600.0,
      "prompt":"About how many one-hour blocks fit into the measured duration for {label}?",
      "source_url":None,
      "source_note":"One hour is defined as 3,600 seconds."
    },
  ],
  "people": [
    {
      "id":"70k-stadium","label":"70,000-seat stadiums","value":70000.0,
      "prompt":"About how many 70,000-seat stadiums would it take to seat the population of {label}?",
      "source_url":None,
      "source_note":"70,000 seats is an explicit hypothetical reference quantity defined in the question."
    },
  ],
  "employees": [
    {
      "id":"70k-stadium-employees","label":"70,000-seat stadiums","value":70000.0,
      "prompt":"About how many 70,000-seat stadiums would it take to seat all of {label}’s employees?",
      "source_url":None,
      "source_note":"70,000 seats is an explicit hypothetical reference quantity defined in the question."
    },
  ],
  "episodes": [
    {
      "id":"ten-episode-season","label":"10-episode seasons","value":10.0,
      "prompt":"About how many 10-episode seasons is {label}’s episode count?",
      "source_url":None,
      "source_note":"A 10-episode season is an explicit reference quantity defined in the question."
    },
  ],
  "pages": [
    {
      "id":"500-page-novel","label":"500-page novels","value":500.0,
      "prompt":"About how many 500-page novels worth of pages are in {label}?",
      "source_url":None,
      "source_note":"500 pages is an explicit reference quantity defined in the question."
    },
  ],
}

_UNIT_DIMENSIONS = {
  # mass -> kg
  "kg":("mass",1.0),"kilogram":("mass",1.0),"kilograms":("mass",1.0),
  "g":("mass",0.001),"gram":("mass",0.001),"grams":("mass",0.001),
  "lb":("mass",0.45359237),"lbs":("mass",0.45359237),"pound":("mass",0.45359237),"pounds":("mass",0.45359237),
  "oz":("mass",0.028349523125),"ounce":("mass",0.028349523125),"ounces":("mass",0.028349523125),
  # length -> m
  "m":("length",1.0),"meter":("length",1.0),"meters":("length",1.0),"metre":("length",1.0),"metres":("length",1.0),
  "km":("length",1000.0),"kilometer":("length",1000.0),"kilometers":("length",1000.0),"kilometre":("length",1000.0),"kilometres":("length",1000.0),
  "cm":("length",0.01),"centimeter":("length",0.01),"centimeters":("length",0.01),"centimetre":("length",0.01),"centimetres":("length",0.01),
  "mm":("length",0.001),"millimeter":("length",0.001),"millimeters":("length",0.001),"millimetre":("length",0.001),"millimetres":("length",0.001),
  "ft":("length",0.3048),"foot":("length",0.3048),"feet":("length",0.3048),
  "in":("length",0.0254),"inch":("length",0.0254),"inches":("length",0.0254),
  "mi":("length",1609.344),"mile":("length",1609.344),"miles":("length",1609.344),
  # duration -> seconds
  "second":("duration",1.0),"seconds":("duration",1.0),"s":("duration",1.0),
  "minute":("duration",60.0),"minutes":("duration",60.0),"min":("duration",60.0),
  "hour":("duration",3600.0),"hours":("duration",3600.0),"hr":("duration",3600.0),
  "day":("duration",86400.0),"days":("duration",86400.0),
  "week":("duration",604800.0),"weeks":("duration",604800.0),
  "month":("duration",2629800.0),"months":("duration",2629800.0),
  "year":("duration",31557600.0),"years":("duration",31557600.0),
  # explicit counts
  "people":("people",1.0),"person":("people",1.0),
  "employees":("employees",1.0),"employee":("employees",1.0),
  "episodes":("episodes",1.0),"episode":("episodes",1.0),
  "pages":("pages",1.0),"page":("pages",1.0),
}

def _normalize_unit(unit):
    return re.sub(r"[^a-z0-9]+"," ",str(unit or "").lower()).strip()

def _unit_dimension(unit):
    u=_normalize_unit(unit)
    if u in _UNIT_DIMENSIONS:return _UNIT_DIMENSIONS[u]
    # Unit labels from Wikidata sometimes contain longer phrases.
    for key,val in sorted(_UNIT_DIMENSIONS.items(),key=lambda kv:-len(kv[0])):
        if re.search(rf"(^|\\s){re.escape(key)}($|\\s)",u):return val
    return None,None

def _measure_word(prompt):
    p=str(prompt or "").lower()
    if "wingspan" in p:return "wingspan"
    if "diameter" in p:return "diameter"
    if "elevation" in p or "above sea level" in p:return "elevation"
    if "height" in p or "tall" in p:return "height"
    if "length" in p or "how long" in p:return "length"
    return "measurement"

def _derived_difficulty(ratio):
    if ratio < 20:return "easy"
    if ratio < 500:return "medium"
    return "hard"

def derive_fun_questions(questions,limit=50,style="mixed"):
    """Create source-backed comparison questions from already sourced numeric facts.

    A derived question is emitted only when:
      * the original question is numeric and has a finite positive answer;
      * its unit can be normalized to a known physical/count dimension;
      * the comparison reference is authoritative or explicitly defined in the prompt;
      * the resulting ratio is useful (not effectively zero or astronomically huge).
    """
    limit=max(1,min(500,int(limit or 50)))
    pool=[]
    for q in questions or []:
        if str(q.get("question_type") or "")!="numeric":continue
        try:value=float(q.get("answer_numeric"))
        except:continue
        if not math.isfinite(value) or value<=0:continue
        dim,scale=_unit_dimension(q.get("unit"))
        if not dim:continue
        base=value*scale
        label=str(q.get("media_query") or q.get("source_entity_id") or "this subject").strip() or "this subject"
        refs=list(FUN_REFERENCES.get(dim) or [])
        # Long geographic distances are better compared to track laps than phones/hoops.
        if dim=="length" and base>=1000 and _measure_word(q.get("prompt"))=="length":refs += FUN_REFERENCES.get("distance") or []
        seed=str(q.get("canonical_key") or q.get("id") or q.get("prompt") or "")
        rnd=random.Random(int(hashlib.sha1(seed.encode()).hexdigest()[:12],16))
        # Animal-weight comparisons read especially well with the classic tennis-ball framing.
        if dim=="mass" and str(q.get("category") or "").lower()=="animals":
            refs.sort(key=lambda r:0 if r.get("id")=="tennis-ball" else 1)
        else:
            rnd.shuffle(refs)
        for ref in refs:
            ratio=base/float(ref["value"])
            if not math.isfinite(ratio) or ratio<0.75 or ratio>10_000_000:continue
            # Avoid comically unhelpful track-lap comparisons for short objects.
            if ref["id"]=="standard-track" and ratio<0.25:continue
            answer=round(ratio,2 if ratio<20 else (1 if ratio<100 else 0))
            prompt=ref["prompt"].format(label=label,measure=_measure_word(q.get("prompt")))
            original_display=f"{format_number(value)} {q.get('unit') or ''}".strip()
            ref_display=f"{format_number(ref['value'])} base-unit"
            calculation=f"{format_number(base)} ÷ {format_number(ref['value'])} ≈ {format_number(answer)}"
            ref_source=ref.get("source_url")
            explanation=(
              f"Derived from the sourced fact that {label} is about {original_display}. "
              f"{ref['source_note']} Calculation in normalized units: {calculation}. "
              f"The result is approximate and rounded for gameplay."
            )
            canonical=f"derived:v1:{q.get('canonical_key') or q.get('id')}:{ref['id']}"
            row={
              "id":canonical,"canonical_key":canonical,"category":q.get("category") or "General Knowledge",
              "difficulty":_derived_difficulty(ratio),"question_type":"numeric","prompt":prompt,
              "context":"Source-backed derived comparison · approximate answer","unit":ref["label"],
              "options":None,"answer_numeric":answer,"answer_text":None,"correct_option":None,
              "explanation":explanation,"source_url":q.get("source_url"),"source_type":"derived_verified",
              "source_entity_id":q.get("source_entity_id"),"media_query":label,
              "derived_from":q.get("canonical_key") or q.get("id"),"reference_id":ref["id"],
              "reference_source_url":ref_source,"reference_note":ref["source_note"],
              "derivation":{"original_value":value,"original_unit":q.get("unit"),"normalized_value":base,"reference_value":ref["value"],"ratio":ratio}
            }
            pool.append(row)
            break
    # Deterministic shuffle spreads categories/entities instead of clustering by acquisition order.
    pool.sort(key=lambda q:hashlib.sha1(str(q["canonical_key"]).encode()).hexdigest())
    return pool[:limit]
