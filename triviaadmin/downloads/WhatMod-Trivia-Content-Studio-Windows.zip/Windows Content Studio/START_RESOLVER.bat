@echo off
call "%~dp0START_CONTENT_STUDIO.bat"
