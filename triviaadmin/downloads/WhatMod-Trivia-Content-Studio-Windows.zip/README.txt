WHATMOD TRIVIA - LOCAL CONTENT STUDIO (V16.1)
===========================================

Purpose
-------
This Windows utility replaces GitHub Actions as the normal content-acquisition pipeline.
It can:
  1. Acquire new question candidates from Wikidata.
  2. Resolve reusable media through Wikipedia / Wikimedia Commons / Openverse.
  3. Let you review and override image selections locally.
  4. Export ONE content-package JSON file.
  5. That one file is uploaded in https://whatmod.com/triviaadmin/ and imported into Supabase.

No Supabase URL, publishable key, secret key, or service-role key is stored in this tool.

Start
-----
Double-click START_CONTENT_STUDIO.bat.
Python 3 is required. No pip packages are required.

Question offsets
----------------
"Continue where I left off" stores offsets locally in content_studio_state.json.
This file is only local state; deleting it resets the local Wikidata cursors to 0.

Recommended first run
---------------------
- Select all templates.
- 100 questions per template.
- Continue where I left off.
- Acquire questions.
- Media: 4-6 workers, 4 image probes per question.
- Review any media you care about.
- Export Content Package.
- In /triviaadmin -> Questions -> Local Content Studio, upload the package.

The admin importer deduplicates by canonical_key. Uploading the same package again does not create duplicate question rows.
Admin-edited questions are content-locked so future automated imports do not overwrite your factual edits.


V12.1 ACQUISITION ENGINE
-------------------------
- 50+ question generators across all Trivia categories.
- Uses the Wikidata Action/Search API for discovery instead of long-running SPARQL as the primary path.
- Each network request has a hard timeout + retry/backoff.
- Slow/failed generators are isolated so the rest of a run continues.
- The UI reports page-by-page progress, scanned items, per-generator errors, and elapsed time.
- Recommended Mix selects a balanced starter set; Select All is available for larger local runs.
- Animal generators are intentionally tagged as sparse because Wikidata has fewer numeric biological statements.


V16 TOPIC DISCOVERY
-------------------
- New relatable categories: Brainrot, General Gaming Knowledge, Internet Culture, Pop Culture, Movies & TV, Music, Food & Brands, and General Knowledge.
- Audience familiarity filter: Mainstream, Balanced, Deep cuts.
- Topic Search lets you enter one or multiple phrases, preview available sourced questions, choose how many to acquire, and save the topic as a reusable category pack with its own local search index.
- Topic discovery can generate sourced numeric questions and identification multiple-choice questions from Wikidata.

V16.1 EXPORT + FUN FORMAT LAB
-----------------------------
- Fixed media-only jobs exported from Trivia Admin: once resolution finishes, "Export media-only results" is enabled correctly.
- The main "Export Content Package" button can also export a unified media-only package; Trivia Admin recognizes that package and routes it through the media importer without trying to create/overwrite question facts.
- Added Fun Format Lab. It creates extra source-backed comparison questions from numeric facts already in the current package.
- Derived questions use normalized unit math and only compatible dimensions. Examples include regulation tennis-ball mass, regulation football mass, U.S. quarter mass, iPhone dimensions/weight, basketball-hoop height, a 400 m track, and explicit hypothetical capacities.
- Authoritative comparison specifications are recorded in the derivation metadata/explanation. Approximate questions clearly say they are approximate and show the calculation used.
- Added animal body-mass acquisition (Wikidata P2067) and mass as a Topic Discovery fact so animal-weight comparisons can be generated when sourced data exists.
