WHATMOD TRIVIA - CONNECTED CONTENT STUDIO (V22)
===========================================

Purpose
-------
This Windows utility replaces GitHub Actions as the normal content-acquisition pipeline.
It can:
  1. Acquire new question candidates from Wikidata.
  2. Resolve reusable media through Wikipedia / Wikimedia Commons / Openverse.
  3. Let you review and override image selections locally.
  4. Optionally connect directly to the live Supabase bank.
  5. View category populations and live questions.
  6. Add, edit, retire, and restore questions without leaving the Studio.
  7. Publish a resolved content package directly to Supabase, with JSON export still available as a backup.

V22 stores live credentials only when you choose to enable Live Mode. On Windows, the secret key is encrypted with Windows DPAPI for the current Windows user. The key is never returned to the browser UI and is not written into exported content packages.

Start
-----
Double-click START_CONTENT_STUDIO.bat.
Python 3 is required. No pip packages are required.

Question offsets
----------------
"Continue where I left off" stores offsets locally in content_studio_state.json.
This file is only local state; deleting it resets the local Wikidata cursors to 0.

Recommended first run
---------------------
- Select all templates.
- 100 questions per template.
- Continue where I left off.
- Acquire questions.
- Media: 4-6 workers, 4 image probes per question.
- Review any media you care about.
- Export Content Package.
- In /triviaadmin -> Questions -> Local Content Studio, upload the package.

The admin importer deduplicates by canonical_key. Uploading the same package again does not create duplicate question rows.
Admin-edited questions are content-locked so future automated imports do not overwrite your factual edits.


V12.1 ACQUISITION ENGINE
-------------------------
- 50+ question generators across all Trivia categories.
- Uses the Wikidata Action/Search API for discovery instead of long-running SPARQL as the primary path.
- Each network request has a hard timeout + retry/backoff.
- Slow/failed generators are isolated so the rest of a run continues.
- The UI reports page-by-page progress, scanned items, per-generator errors, and elapsed time.
- Recommended Mix selects a balanced starter set; Select All is available for larger local runs.
- Animal generators are intentionally tagged as sparse because Wikidata has fewer numeric biological statements.


V16 TOPIC DISCOVERY
-------------------
- New relatable categories: Brainrot, General Gaming Knowledge, Internet Culture, Pop Culture, Movies & TV, Music, Food & Brands, and General Knowledge.
- Audience familiarity filter: Mainstream, Balanced, Deep cuts.
- Topic Search lets you enter one or multiple phrases, preview available sourced questions, choose how many to acquire, and save the topic as a reusable category pack with its own local search index.
- Topic discovery can generate sourced numeric questions and identification multiple-choice questions from Wikidata.

V16.1 EXPORT + FUN FORMAT LAB
-----------------------------
- Fixed media-only jobs exported from Trivia Admin: once resolution finishes, "Export media-only results" is enabled correctly.
- The main "Export Content Package" button can also export a unified media-only package; Trivia Admin recognizes that package and routes it through the media importer without trying to create/overwrite question facts.
- Added Fun Format Lab. It creates extra source-backed comparison questions from numeric facts already in the current package.
- Derived questions use normalized unit math and only compatible dimensions. Examples include regulation tennis-ball mass, regulation football mass, U.S. quarter mass, iPhone dimensions/weight, basketball-hoop height, a 400 m track, and explicit hypothetical capacities.
- Authoritative comparison specifications are recorded in the derivation metadata/explanation. Approximate questions clearly say they are approximate and show the calculation used.
- Added animal body-mass acquisition (Wikidata P2067) and mass as a Topic Discovery fact so animal-weight comparisons can be generated when sourced data exists.


V19 CATEGORY COMMAND CENTER
---------------------------
In Trivia Admin > Questions, export the Category Dashboard or click Add Questions on a category. Load that JSON in Content Studio. Each category shows its live bank population, difficulty mix, and photo coverage. Press Acquire + Resolve Media to refill one category and resolve media in a single local run, then Export Content Package and import it back into Trivia Admin.

V20 CATEGORY CATALOG + STALE BACKEND FIX
---------------------------------------
- All player-facing categories are shown in Category Command Center, even when the live bank count is 0.
- Empty categories can be hydrated directly. Categories without fixed generators automatically use Topic Discovery.
- Category snapshots/jobs can be dragged directly onto the Category Command Center upload area.
- The backend exposes /api/version. If an old Python server is still serving the new frontend, category acquisition falls back to compatibility mode instead of only showing "Not found".
- START_CONTENT_STUDIO.bat checks port 8767 for an older WhatMod Content Studio and stops that old local process before launching the current one.


V21 CONNECTED LIVE BANK
-----------------------
- New Live Bank / Build Content / Settings navigation.
- Settings accepts the Supabase Project URL plus a server-side Secret key (sb_secret_...) or legacy service_role key. Do NOT use the publishable/anon key.
- The local Python server binds to 127.0.0.1 and performs all privileged Supabase requests. The browser never receives the saved secret.
- On Windows, the saved key is encrypted with DPAPI and can only be decrypted by the same Windows user account.
- Live Bank shows every category and its active/easy/medium/hard/photo counts directly from Supabase.
- Live Questions supports search/filter, full question editing, new manual questions, and reversible retirement/restoration.
- Build Content can publish the current acquired/resolved package directly to the live bank. Existing content-locked or retired questions are preserved.
- JSON export remains available for backups and handoffs.
- Added a universal JSON drop inbox and global Windows drag/drop fallback for category snapshots/jobs and media-only jobs.

FIRST LIVE CONNECTION
---------------------
1. Open Settings in Content Studio.
2. Enter the Supabase Project URL.
3. Enter a Secret key (recommended) or legacy service_role key.
4. Click Save + Test Connection.
5. Open Live Bank.

Because a Supabase Secret/service_role key bypasses Row Level Security, treat it like an administrator password. Keep the Content Studio folder on your own PC and do not copy content_studio_settings.json to GitHub or send it to anyone.


V22 FREE-PLAN HYGIENE
----------------------
- Media resolution keeps only the five strongest local candidates per question instead of twelve.
- When the V22 database migration is installed, Live Bank category counts use one compact aggregate RPC instead of downloading the full question bank just to count categories.
- Content Studio audit writes are changed-field diffs rather than full before/after question copies.
- Direct Live Bank editing/publishing behavior is otherwise unchanged.
