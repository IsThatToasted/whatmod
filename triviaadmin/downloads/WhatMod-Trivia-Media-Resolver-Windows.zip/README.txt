WHATMOD TRIVIA - LOCAL MEDIA RESOLVER

1. In https://whatmod.com/triviaadmin/ choose "Export media job".
2. Download the JSON file.
3. Double-click START_RESOLVER.bat.
4. Drag the exported JSON into the browser window.
5. Choose concurrency (4-6 is a good starting point) and click Resolve.
6. Review the resulting thumbnails. You can click another candidate to make it the selected image.
7. Click Export Results.
8. Return to /triviaadmin and choose Import resolver results.

The local resolver:
- DOES NOT need your Supabase URL or secret key.
- DOES NOT write directly to your database.
- Searches Wikipedia/Wikimedia Commons/Openverse.
- Auto-selects only reuse-safe candidates.
- Runs several questions concurrently for much higher throughput than the old GitHub workflow.

Keep the resolver window open while a job is running.
