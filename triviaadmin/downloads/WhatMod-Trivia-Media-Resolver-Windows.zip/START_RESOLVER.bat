@echo off
setlocal
cd /d "%~dp0"
title WhatMod Trivia Media Resolver
where py >nul 2>&1
if %errorlevel%==0 (
  py -3 resolver_server.py
  goto :eof
)
where python >nul 2>&1
if %errorlevel%==0 (
  python resolver_server.py
  goto :eof
)
echo.
echo Python 3 was not found.
echo Install Python 3 from python.org and make sure "Add Python to PATH" is enabled.
echo Then run this file again.
echo.
pause
