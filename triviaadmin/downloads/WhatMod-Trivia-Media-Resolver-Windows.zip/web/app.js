const $=s=>document.querySelector(s);
let job=null, pollTimer=null, latestItems=[];
function toast(msg){const n=document.createElement('div');n.className='toast';n.textContent=msg;$('#toast-root').appendChild(n);setTimeout(()=>n.remove(),3000)}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}
async function api(path,opts={}){const r=await fetch(path,{...opts,headers:{'Content-Type':'application/json',...(opts.headers||{})}});const b=await r.json();if(!r.ok)throw new Error(b.error||`Request failed ${r.status}`);return b}
function loadJobText(text,name='job.json'){
  try{
    const data=JSON.parse(text);
    if(data.format!=='whatmod-trivia-media-job'||Number(data.version)!==1||!Array.isArray(data.questions))throw new Error('Not a WhatMod Trivia media job.');
    job=data;$('#job-count').textContent=`${data.questions.length.toLocaleString()} questions`;
    $('#job-meta').textContent=`${name} · Scope: ${data.scope||'unknown'} · Exported: ${data.exported_at?new Date(data.exported_at).toLocaleString():'unknown'}`;
    $('#start').disabled=!data.questions.length;toast(`Loaded ${data.questions.length} questions`);
  }catch(e){job=null;$('#start').disabled=true;toast(e.message)}
}
$('#job-file').addEventListener('change',async e=>{const f=e.target.files?.[0];if(f)loadJobText(await f.text(),f.name)});
const dz=$('#drop-zone');
['dragenter','dragover'].forEach(x=>dz.addEventListener(x,e=>{e.preventDefault();dz.classList.add('over')}));
['dragleave','drop'].forEach(x=>dz.addEventListener(x,e=>{e.preventDefault();dz.classList.remove('over')}));
dz.addEventListener('drop',async e=>{const f=e.dataTransfer.files?.[0];if(f)loadJobText(await f.text(),f.name)});
$('#start').onclick=async()=>{
  if(!job)return;
  try{
    await api('/api/start',{method:'POST',body:JSON.stringify({job,concurrency:Number($('#concurrency').value),probe_count:Number($('#probe-count').value)})});
    $('#start').disabled=true;$('#cancel').disabled=false;$('#export').disabled=true;startPolling();
  }catch(e){toast(e.message)}
};
$('#cancel').onclick=async()=>{try{await api('/api/cancel',{method:'POST',body:'{}'});toast('Stop requested.')}catch(e){toast(e.message)}};
$('#export').onclick=async()=>{
  try{
    const data=await api('/api/results');
    const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});
    const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`whatmod-trivia-media-results-${data.question_count}-${new Date().toISOString().replace(/[:.]/g,'-')}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);
  }catch(e){toast(e.message)}
};
function startPolling(){clearInterval(pollTimer);pollTimer=setInterval(updateStatus,650);updateStatus()}
async function updateStatus(){
  try{
    const s=await api('/api/status');
    const pct=s.total?Math.round(s.completed/s.total*100):0;
    $('#progress-bar').style.width=`${pct}%`;$('#done').textContent=`${s.completed}/${s.total}`;$('#resolved').textContent=s.resolved;$('#missing').textContent=s.missing;$('#speed').textContent=`${Math.round((s.rate||0)*60)}/m`;
    $('#run-state').textContent=s.running?'RUNNING':(s.completed?'COMPLETE':'IDLE');$('#run-state').className=`pill ${s.running?'':'muted'}`;
    $('#run-message').textContent=s.error?`Error: ${s.error}`:s.running?`Resolving ${s.completed+1} of ${s.total} · ${pct}% complete`:`${s.completed} questions processed. Review selections, then export the result file.`;
    $('#cancel').disabled=!s.running;$('#export').disabled=s.running||!s.completed;$('#start').disabled=s.running||!job;
    latestItems=s.items||[];renderResults();
    if(!s.running&&s.completed){clearInterval(pollTimer);pollTimer=null}
  }catch(e){console.error(e)}
}
function renderResults(){
  const box=$('#result-list');
  if(!latestItems.length){box.innerHTML='<div class="empty">Results will appear here while the resolver runs.</div>';return}
  box.innerHTML=[...latestItems].reverse().map(item=>{
    const selected=item.selected?`${item.selected.provider}:${item.selected.provider_key}`:'';
    const cands=(item.candidates||[]).slice(0,8);
    return `<article class="result"><div class="result-head"><div><h3>${esc(item.prompt||item.query)}</h3><small>${esc(item.query||'')}</small></div><span class="status ${selected?'ok':'miss'}">${selected?'RESOLVED':'NO SAFE IMAGE'}</span></div><div class="candidates">${cands.map(c=>{
      const key=`${c.provider}:${c.provider_key}`,sel=key===selected,src=c.thumbnail_url||c.image_url;
      return `<div class="candidate ${sel?'selected':''}" data-q="${esc(item.id)}" data-provider="${esc(c.provider)}" data-key="${esc(c.provider_key)}">${src?`<img src="${esc(src)}" alt="" referrerpolicy="no-referrer" onerror="this.outerHTML='<div class=&quot;fallback&quot;>Image failed</div>'">`:'<div class="fallback">No preview</div>'}<em>${sel?'SELECTED':c.auto_eligible?'SAFE':'REVIEW'}</em><div class="candidate-copy"><b>${esc(c.title||c.provider)}</b><small>${esc(c.license||'License unknown')}</small></div></div>`}).join('')}</div></article>`;
  }).join('');
  document.querySelectorAll('.candidate').forEach(el=>el.onclick=async()=>{
    try{
      await api('/api/select',{method:'POST',body:JSON.stringify({question_id:el.dataset.q,provider:el.dataset.provider,provider_key:el.dataset.key})});
      await updateStatus();toast('Selection changed for export.');
    }catch(e){toast(e.message)}
  });
}
updateStatus();
